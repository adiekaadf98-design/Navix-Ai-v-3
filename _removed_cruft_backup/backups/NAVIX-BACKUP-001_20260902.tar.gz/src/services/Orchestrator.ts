import { NavixSkillRouter } from './skills/mcp/McpSkillRouter';
import { VertexService } from './VertexService';
import { globalEngineRegistry, ServiceRegistry } from './EngineRegistry';
import { navixMemoryEngine } from '../memory/MemoryEngine';
import { globalAdaptiveEngine } from './AdaptiveExecutionEngine';
import { globalVerificationEngine } from './VerificationEngine';
import { globalFailureRecovery } from './FailureRecoveryEngine';
import { classifyTask } from './ThinkingEngine';
import { rotateFetch, getAllActiveKeysHeader } from '../lib/apiKeyRotator';


/**
 * Melakukan analisis semantik untuk membedakan instruksi pembuatan gambar baru ('generate')
 * dan penyuntingan/diskusi gambar yang sudah ada ('edit/discuss').
 */
export function analyzeImageIntent(message: string, attachments?: any[], history?: any[]): 'generate' | 'edit' | 'discuss' | 'none' {
  if (message.startsWith('[GOOGLE_COMPOSITE]')) {
    return 'none';
  }
  const lowercaseMsg = message.toLowerCase();
  
  // Cek apakah ada attachment berupa gambar sekarang atau dalam riwayat chat terdekat
  const hasImageAttachment = attachments && attachments.some(att => {
    if (typeof att === 'string') {
      return att.startsWith('data:image') || att.includes('image');
    }
    return (
      (att.mimeType && att.mimeType.startsWith('image/')) || 
      (att.type && att.type === 'image') ||
      (att.data && typeof att.data === 'string' && att.data.length > 100)
    );
  });

  const hasHistoryImage = history && history.some(item => 
    item.parts && item.parts.some((part: any) => 
      part.inlineData && part.inlineData.mimeType && part.inlineData.mimeType.startsWith('image/')
    )
  );

  const hasImageContext = hasImageAttachment || hasHistoryImage;

  // Kata kunci pemicu pengeditan gambar
  const editKeywords = [
    'edit', 'ubah', 'ganti', 'modify', 'proses', 'manipulasi', 'tambah', 'kurang', 
    'gaya', 'variasi', 'ganti latar', 'pake', 'pakek', 'pakai', 'crop', 'resize', 
    'filter', 'grayscale', 'warna', 'wajah', 'muka', 'face', 'ganti baju', 'baju',
    'rambut', 'hairstyle', 'kacamata', 'background', 'ganti background', 'figurine',
    'anime', 'kartun', 'aesthetic', 'makeover', 'sempurnakan', 'perbaiki'
  ];

  // Kata kunci pemicu diskusi/tanya jawab gambar
  const discussKeywords = [
    'apa', 'siapa', 'jelaskan', 'deskripsikan', 'analisa', 'analisis', 'bagaimana', 
    'bagus', 'jelek', 'foto siapa', 'ini gambar apa', 'foto ini', 'gambar ini', 
    'terangkan', 'baca', 'artikan', 'tanya', 'diskusi', 'obrol', 'cerita'
  ];

  const containsEditKeyword = editKeywords.some(kw => lowercaseMsg.includes(kw));
  const containsDiscussKeyword = discussKeywords.some(kw => lowercaseMsg.includes(kw));

  // Jika ada konteks gambar (attachment/history), prioritaskan edit/discuss
  if (hasImageContext) {
    if (containsEditKeyword) {
      return 'edit';
    }
    if (containsDiscussKeyword || lowercaseMsg.trim().length < 15) {
      return 'discuss';
    }
    
    // Cek apakah ada kata kunci buat baru yang sangat eksplisit
    const isExplicitNewGenerate = (lowercaseMsg.includes('buat gambar baru') || lowercaseMsg.includes('bikin gambar baru') || lowercaseMsg.includes('generate new image') || lowercaseMsg.includes('buatkan gambar baru')) && !lowercaseMsg.includes('ini');
    if (!isExplicitNewGenerate) {
      // Jika ada gambar terlampir dan pengguna menginstruksikan sesuatu, itu diasumsikan mengedit gambar tersebut
      return 'edit';
    }
  }

  // Jika tidak ada gambar sama sekali tapi ada instruksi edit gambar/foto spesifik
  if (containsEditKeyword && (lowercaseMsg.includes('gambar') || lowercaseMsg.includes('foto') || lowercaseMsg.includes('image') || lowercaseMsg.includes('wajah') || lowercaseMsg.includes('muka'))) {
    return 'edit';
  }

  // Cek apakah ada kata kunci generate gambar baru
  const generateKeywords = [
    'buat gambar', 'bikin gambar', 'buatkan gambar', 'gambarkan', 'tampilkan gambar', 'lukis', 'generate image', 'generate gambar',
    'buat ilustrasi', 'bikin ilustrasi', 'buat logo', 'bikin logo', 'buat sketsa', 'bikin sketsa', 'buat lukisan',
    'buatkan logo', 'buatkan ilustrasi', 'tolong buat gambar', 'tolong bikin gambar',
    'buat foto', 'bikin foto', 'buatkan foto', 'fotokan', 'tampilkan foto', 'ambil foto', 'foto real', 'foto asli',
    'foto manusia', 'foto wanita', 'foto pria', 'foto orang', 'foto wajah', 'foto pemandangan', 'foto kucing', 'foto anjing', 'foto alam',
    'potret', 'portrait', 'draw ', 'paint ', 'create image', 'generate image', 'photograph of', 'photo of', 'portrait of'
  ];
  const containsGenerateKeyword = generateKeywords.some(kw => lowercaseMsg.includes(kw));

  if (containsGenerateKeyword) {
    return 'generate';
  }

  return 'none';
}

export interface OrchestratorRequest {
  message: string;
  attachments?: any[];
  history?: any[];
  model?: string;
  voiceEnabled?: boolean;
  effort?: string;
  thinkingMode?: boolean;
  onProgress?: (event: { step: string, status: string, detail?: string }) => void;
}

export interface OrchestratorResponse {
  text?: string;
  audioBase64?: string;
  attachments?: any[];
  error?: string;
  isRateLimit?: boolean;
  systemInstruction?: string;
}

export class NavixOrchestrator {
  /**
   * Menerima permintaan dari pengguna, menentukan mesin yang sesuai melalui ServiceRegistry,
   * meneruskan tugas ke mesin tersebut, menerima hasilnya, lalu mengirimkan hasil itu ke AI
   * untuk disusun menjadi jawaban akhir yang ditampilkan kepada pengguna.
   */
  async processUserRequest(req: OrchestratorRequest): Promise<OrchestratorResponse> {
    const notify = (step: string, status: string, detail?: string) => {
      if (req.onProgress && req.thinkingMode) {
        req.onProgress({ step, status, detail });
      }
    };
    
    notify("thinking_started", "pending", "Understanding Task");

    try {
      // ADAPTIVE EXECUTION ENGINE
      
      // ADAPTIVE EXECUTION ENGINE
      let adaptiveResult: any = null;

      // MCP DIRECT INTERCEPT & SKILL EXECUTION LAYER
      if (req.message.startsWith('/mcp') || req.message.toLowerCase().startsWith('!mcp')) {
        const fullCmd = req.message.replace(/^(\/mcp|!mcp)\s*/i, '').trim();
        
        if (!fullCmd || fullCmd === 'list' || fullCmd === 'status' || fullCmd === 'help') {
          const { MCP_MARKET_PROVIDERS, getTotalMcpSkillsCount } = await import('./skills/mcp/mcpMarketCatalog');
          const executableCount = MCP_MARKET_PROVIDERS.filter(p => p.status === 'EXECUTABLE').length;
          const configCount = MCP_MARKET_PROVIDERS.filter(p => p.status === 'CONFIGURATION_REQUIRED').length;

          let catalogMd = `### 🌐 Navix Model Context Protocol (MCP) Skills Hub\n\n`;
          catalogMd += `**Total Ecosystem:** ${getTotalMcpSkillsCount()} Skills terindeks melintasi ${MCP_MARKET_PROVIDERS.length} Global Providers (sesuai MCP Market Directory).\n`;
          catalogMd += `- ⚡ **Direct Executable Engine:** ${executableCount} Providers (Built-in runtime)\n`;
          catalogMd += `- 🔑 **Configured/API Key Ready:** ${configCount} Providers (Cloud services)\n\n`;
          catalogMd += `| Provider | Kategori | Total Skills | Status | Sample Executable Tool |\n`;
          catalogMd += `| :--- | :--- | :---: | :---: | :--- |\n`;

          MCP_MARKET_PROVIDERS.slice(0, 15).forEach(p => {
            const statusBadge = p.status === 'EXECUTABLE' ? '🟢 EXECUTABLE' : '🟡 API KEY NEEDED';
            const sampleTool = p.sampleTools[0]?.name || 'ping';
            catalogMd += `| **${p.name}** | ${p.category} | ${p.skillCount} | ${statusBadge} | \`${sampleTool}\` |\n`;
          });

          catalogMd += `\n*...dan 35+ provider lainnya (NVIDIA, Google Gemini, PostHog, Microsoft, Stripe, dll).* Buka **Skills Matrix** di menu atas untuk melihat katalog lengkap!\n\n`;
          catalogMd += `**Cara Eksekusi:**\n\`/mcp <server> <tool> <json_args>\`\n*Contoh:* \`/mcp everything echo {"message": "Hello Navix MCP"}\``;

          return {
            response: catalogMd,
            success: true
          };
        }

        const parts = fullCmd.split(' ');
        const serverName = parts[0] || 'everything';
        const toolName = parts[1] || 'echo';
        const argsStr = parts.slice(2).join(' ');
        let args = {};
        try { args = argsStr ? JSON.parse(argsStr) : {}; } catch (e) { args = { message: argsStr || "Ping from Navix" }; }
        
        notify("mcp_discovery", "pending", `Discovering skills on ${serverName}...`);
        const startTime = Date.now();
        await NavixSkillRouter.discoverSkills(serverName);
        
        notify("mcp_execution", "pending", `Executing skill ${toolName}...`);
        const executionResult = await NavixSkillRouter.routeSkill(toolName, args);
        const elapsed = Date.now() - startTime;
        
        let formattedOutput = "";
        if (executionResult?.content && Array.isArray(executionResult.content)) {
          formattedOutput = executionResult.content.map((c: any) => c.text || JSON.stringify(c)).join('\n');
        } else {
          formattedOutput = JSON.stringify(executionResult, null, 2);
        }

        return {
          response: `### ⚡ MCP Skill Execution Result\n\n- **Target Server:** \`${serverName}\`\n- **Invoked Tool:** \`${toolName}\`\n- **Execution Latency:** \`${elapsed}ms\`\n\n\`\`\`json\n${formattedOutput}\n\`\`\``,
          success: true
        };
      }

      if (!req.message.startsWith('[GOOGLE_COMPOSITE]') && req.thinkingMode) {
        adaptiveResult = await globalAdaptiveEngine.processRequest(req.message, req.attachments?.length || 0, {
           onStateChange: (state, details) => {
             notify("supervisor_state", "pending", state);
           },
           onProgress: (step) => {
             notify(step, "pending", "Workflow Step");
           }
        });
      }

      if (req.message.startsWith('[GOOGLE_COMPOSITE]')) {
        try {
          const lines = req.message.split('\n');
          const faceLine = lines.find(l => l.startsWith('Face:'));
          const clothesLine = lines.find(l => l.startsWith('Clothes:'));
          const bgLine = lines.find(l => l.startsWith('Background:'));
          const promptLine = lines.find(l => l.startsWith('Prompt:'));

          const faceUrl = faceLine ? faceLine.substring(5).trim() : '';
          const clothesUrl = clothesLine ? clothesLine.substring(8).trim() : '';
          const backgroundUrl = bgLine ? bgLine.substring(11).trim() : '';
          const userPrompt = promptLine ? promptLine.substring(7).trim() : '';

          const host = 'http://localhost:3000';
          const headers: any = { 'Content-Type': 'application/json' };
          const activeKeysHeader = getAllActiveKeysHeader();
          if (activeKeysHeader) {
            headers['x-custom-api-key'] = activeKeysHeader;
          }

          const response = await fetch(`${host}/api/composite-image`, {
            method: 'POST',
            headers,
            body: JSON.stringify({ faceUrl, clothesUrl, backgroundUrl, userPrompt, aspectRatio: '1:1' })
          });
          const data = await response.json();
          if (data.success && data.imageBase64) {
            return {
              text: `🎨 **Navix AI Studio - Google Element Composite**\n\nBerhasil menggabungkan wajah model, pakaian kustom, dan latar belakang secara cerdas sesuai permintaan Anda!\n\n**Prompt Hasil Fusi:**\n_${data.composedPrompt || userPrompt}_\n\n\`\`\`media\n{\n  "type": "image",\n  "prompt": "${(data.composedPrompt || userPrompt || "Fused composition").replace(/"/g, "'")}",\n  "image": "${data.imageBase64}"\n}\n\`\`\``
            };
          } else {
            throw new Error(data.error || "Gagal menggabungkan gambar di backend.");
          }
        } catch (err: any) {
          console.error("Composite image generation error in Orchestrator:", err);
          return { error: `Gagal memadukan gambar: ${err.message || String(err)}` };
        }
      }

      let engineResult: any = null;
      let engineName = 'None';
      notify("engine_started", "pending", "Running Engine");

      const lowercaseMsg = req.message.toLowerCase();
      // Deteksi jika pengguna meminta sinyal, analisis trading, atau arah buy/sell secara spesifik
      const isMarketWord = lowercaseMsg.includes('market') || lowercaseMsg.includes('trading') || 
                           lowercaseMsg.includes('emas') || lowercaseMsg.includes('gold') || 
                           lowercaseMsg.includes('xau') || lowercaseMsg.includes('btc') || 
                           lowercaseMsg.includes('eth') || lowercaseMsg.includes('crypto') || 
                           lowercaseMsg.includes('kripto') || lowercaseMsg.includes('forex') || 
                           lowercaseMsg.includes('saham') || lowercaseMsg.includes('chart') ||
                           lowercaseMsg.includes('binance') || lowercaseMsg.includes('yahoo');
                           
      const isSignalRequest = 
        (lowercaseMsg.includes('signal') || lowercaseMsg.includes('sinyal') || 
         lowercaseMsg.includes('buy') || lowercaseMsg.includes('sell') || 
         ((lowercaseMsg.includes('analisis') || lowercaseMsg.includes('analisa') || lowercaseMsg.includes('rekomendasi')) && isMarketWord)) &&
        !lowercaseMsg.includes('gambar') && !lowercaseMsg.includes('video') && 
        !lowercaseMsg.includes('dokumen') && !lowercaseMsg.includes('penelitian') && 
        !lowercaseMsg.includes('sains') && !lowercaseMsg.includes('lacak') && 
        !lowercaseMsg.includes('radar');

      const attachments = req.attachments || [];
      const hasImageAttachment = attachments.some(att => {
        if (typeof att === 'string') {
          return att.startsWith('data:image') || att.includes('image');
        }
        return (
          (att.mimeType && att.mimeType.startsWith('image/')) || 
          (att.type && att.type === 'image') ||
          (att.data && typeof att.data === 'string' && att.data.length > 100)
        );
      });

      const imageIntent = analyzeImageIntent(req.message, req.attachments, req.history);
      console.log(`[DEBUG LOG] Orchestrator: Terdeteksi imageIntent mode -> '${imageIntent}'`);
      const videoKeywords = ['buat video', 'bikin video', 'buatkan video', 'generate video', 'tolong buat video', 'tolong bikin video', 'buat animasi', 'bikin animasi'];
      const isVideoRequest = videoKeywords.some(kw => lowercaseMsg.includes(kw)) && !lowercaseMsg.includes('ringkasan') && !lowercaseMsg.includes('analisis');
      const musicKeywords = ['buat musik', 'bikin musik', 'buat lagu', 'bikin lagu', 'generate music', 'buatkan lagu', 'buatkan musik', 'komposisi musik', 'generate song', 'create music'];
      const isMusicRequest = musicKeywords.some(kw => lowercaseMsg.includes(kw));

      if (imageIntent === 'generate') {
        const genStartTime = performance.now();
        console.log(`[Orchestrator] 🎨 Starting Image Generation Pipeline for user request:`, {
          prompt: req.message,
          hasAttachment: hasImageAttachment,
          timestamp: new Date().toISOString()
        });

        try {
          const shadowEngine = globalEngineRegistry.getEngine('shadow-engine');
          if (shadowEngine) {
             const shadowRes = await shadowEngine.execute({ prompt: req.message, image_url: hasImageAttachment ? attachments[0].data : undefined });
             if (shadowRes.status === 'success' && shadowRes.data.job_id) {
                console.log(`[Orchestrator] ShadowEngine intercepted image job:`, shadowRes.data.job_id);
                return { text: `\`\`\`shadow-engine\n{\n  "job_id": "${shadowRes.data.job_id}",\n  "pipeline": "${shadowRes.data.pipeline}"\n}\n\`\`\`` };
             }
          }

          const vertexService = new VertexService();
          let aspectRatio = "1:1";
          const msgLower = req.message.toLowerCase();
          
          if (msgLower.includes("16:9") || msgLower.includes("landscape") || msgLower.includes("memanjang") || msgLower.includes("lebar")) {
            aspectRatio = "16:9";
          } else if (msgLower.includes("9:16") || msgLower.includes("portrait") || msgLower.includes("berdiri")) {
            aspectRatio = "9:16";
          } else if (msgLower.includes("4:3")) {
            aspectRatio = "4:3";
          } else if (msgLower.includes("3:4")) {
            aspectRatio = "3:4";
          } else if (msgLower.includes("1:1") || msgLower.includes("persegi") || msgLower.includes("kotak") || msgLower.includes("square")) {
            aspectRatio = "1:1";
          }

          console.log(`[Orchestrator] 📡 Dispatching to VertexService with AspectRatio: ${aspectRatio}`);
          const imageBase64 = await vertexService.generateImage(req.message, aspectRatio);
          const totalGenDuration = Math.round(performance.now() - genStartTime);

          if (imageBase64) {
             console.log(`[Orchestrator] 🎉 Image generated successfully via Vertex/Neural Engine (${totalGenDuration}ms, ~${Math.round(imageBase64.length / 1024)} KB)`);
             return { text: '```media\n{\n  "type": "image",\n  "prompt": "' + req.message.replace(/"/g, "'") + '",\n  "image": "' + imageBase64 + '"\n}\n```' };
          } else {
             throw new Error('VertexService returned empty image stream');
          }
        } catch (err: any) {
          const totalGenDuration = Math.round(performance.now() - genStartTime);
          console.error(`[Orchestrator] ❌ Image generation pipeline failure (${totalGenDuration}ms):`, {
            error: err?.message || String(err),
            stack: err?.stack
          });
          return { error: err.message || 'Error generating image via Vertex AI' };
        }
      } else if (imageIntent === 'edit' || imageIntent === 'discuss') {
        console.log(`Orchestrator: Mendeteksi intent gambar '${imageIntent}'. Melewati pembuatan langsung client-side agar Gemini dapat memproses gambar.`);
      } else if (isVideoRequest) {
        const shadowEngine = globalEngineRegistry.getEngine('shadow-engine');
        if (shadowEngine) {
             const shadowRes = await shadowEngine.execute({ prompt: req.message, image_url: hasImageAttachment ? attachments[0].data : undefined });
             if (shadowRes.status === 'success' && shadowRes.data.job_id) {
                return { text: `\`\`\`shadow-engine\n{\n  "job_id": "${shadowRes.data.job_id}",\n  "pipeline": "${shadowRes.data.pipeline}"\n}\n\`\`\`` };
             }
        }
        // Return a media block to trigger MediaCard video generation
        return { text: '```media\n{\n  "type": "video",\n  "prompt": "' + req.message.replace(/"/g, "'") + '"\n}\n```' };
      } else if (isMusicRequest) {
        // Return a media block to trigger MediaCard music generation
        return { text: '```media\n{\n  "type": "music",\n  "prompt": "' + req.message.replace(/"/g, "'") + '"\n}\n```' };
      }


      if (isSignalRequest) {
        engineName = 'Signal Generation Pipeline';
        console.log("Orchestrator: Memulai Pipeline Sinyal Sesuai Alur Kerja Sistem...");

        // Tentukan symbol berdasarkan query (default XAUUSD)
        let symbol = 'GC=F';
        const upperMsg = req.message.toUpperCase();
        if (upperMsg.includes('XAU') || upperMsg.includes('GOLD') || upperMsg.includes('EMAS') || upperMsg.includes('GC=F')) {
          symbol = 'GC=F';
        } else if (upperMsg.includes('BTC') || upperMsg.includes('CRYPTO') || upperMsg.includes('KRIPTO') || upperMsg.includes('ETH')) {
          const match = upperMsg.match(/\b(BTC|ETH|SOL|BNB|XRP|DOGE|ADA|MATIC|LINK|DOT)\b/);
          symbol = match ? `${match[1]}USDT` : 'BTCUSDT';
        } else if (upperMsg.includes('EUR') || upperMsg.includes('USD') || upperMsg.includes('GBP') || upperMsg.includes('FOREX') || upperMsg.includes('FACTORY')) {
          const match = upperMsg.match(/\b(EURUSD|GBPUSD|AUDUSD|USDJPY|USDCAD|USDCHF|NZDUSD)\b/);
          symbol = match ? `${match[1]}=X` : 'EURUSD=X';
        } else {
          symbol = 'GC=F';
        }

        // Step 1: Ambil dan selesaikan data harga pasar TradingView API Engine terlebih dahulu
        console.log("Orchestrator Pipeline Step 1: Menjalankan TradingView API Engine...");
        const tvEngine = globalEngineRegistry.getEngine('TradingViewService');
        let tvResult: any = null;
        if (tvEngine) {
          try {
            tvResult = await tvEngine.execute({ symbol, query: req.message });
          } catch (err) {
            console.error("Orchestrator Pipeline Step 1 Error:", err);
          }
        }

        // Step 2: Ambil dan selesaikan data berita Forex Factory API Engine terlebih dahulu
        console.log("Orchestrator Pipeline Step 2: Menjalankan Forex Factory API Engine...");
        const forexEngine = globalEngineRegistry.getEngine('ForexFactoryService');
        let forexResult: any = null;
        if (forexEngine) {
          try {
            const forexSymbol = symbol.includes('USDT') ? 'EURUSD=X' : symbol;
            forexResult = await forexEngine.execute({ symbol: forexSymbol, query: req.message });
          } catch (err) {
            console.error("Orchestrator Pipeline Step 2 Error:", err);
          }
        }

        // Step 3: Kirim seluruh hasil ke Signal Engine untuk dianalisis
        notify("engine_progress", "pending", "Validating Signals");
        console.log("Orchestrator Pipeline Step 3: Menjalankan Signal Engine...");
        const signalEngine = globalEngineRegistry.getEngine('SignalEngine');
        if (signalEngine) {
          try {
            engineResult = await signalEngine.execute({
              symbol,
              tradingViewData: tvResult,
              forexFactoryData: forexResult,
              query: req.message
            });
          } catch (err) {
            console.error("Orchestrator Pipeline Step 3 (SignalEngine) Error:", err);
          }
        }
      } else {
        // Alur kerja non-signal biasa: tentukan satu mesin berdasarkan intent
        engineName = ServiceRegistry.routeIntent(req.message);
        const engine = globalEngineRegistry.getEngine(engineName);
        if (engine) {
          notify("engine_progress", "pending", `Executing ${engineName}`);
          console.log(`Orchestrator: Menentukan mesin tunggal -> ${engineName}`);
          try {
            let symbol = '';
            const upperMsg = req.message.toUpperCase();
            if (engineName === 'CryptoEngine') {
              const match = upperMsg.match(/\b(BTC|ETH|SOL|BNB|XRP|DOGE|ADA|MATIC|LINK|DOT)\b/);
              symbol = match ? `${match[1]}USDT` : 'BTCUSDT';
            } else if (engineName === 'ForexFactoryService') {
              const match = upperMsg.match(/\b(EURUSD|GBPUSD|AUDUSD|USDJPY|USDCAD|USDCHF|NZDUSD)\b/);
              symbol = match ? `${match[1]}=X` : 'EURUSD=X';
            } else {
              const match = upperMsg.match(/\b(XAUUSD|GOLD|GC=F)\b/);
              symbol = 'GC=F';
            }
            engineResult = await engine.execute({ symbol, query: req.message });
          } catch (err) {
            console.error(`Orchestrator: Error saat menjalankan mesin ${engineName}:`, err);
          }
        }
      }

      
            // Use adaptive result if it produced one (and bypass legacy engine logic for that part)
      if (adaptiveResult && adaptiveResult.finalEngineResult && !engineResult) {
         engineResult = adaptiveResult.finalEngineResult;
         if (adaptiveResult.classification && adaptiveResult.classification.taskType === 'knowledge_lab') {
             engineName = 'KnowledgeLab';
         } else {
             engineName = 'AdaptiveExecutionEngine';
         }
         if (!adaptiveResult.verification.passed) {
             engineResult.message = "VERIFICATION FAILED: " + adaptiveResult.verification.issues.join(', ');
         }
      }

      // Legacy fallback Verification just in case
      if (engineResult && !adaptiveResult && req.thinkingMode) {
        notify("supervisor_state", "pending", "VERIFYING");
        const { taskType } = classifyTask(req.message);
        const verification = globalVerificationEngine.verify(taskType, engineResult.data || engineResult);
        
        if (!verification.passed) {
          notify("supervisor_state", "pending", "CORRECTING");
          const recovery = globalFailureRecovery.analyzeFailure('default', verification.issues.join(', '), taskType);
          console.warn('Verification failed:', verification.issues, 'Recovery Plan:', recovery);
          if (recovery.action === 'ABORT') {
            notify("supervisor_state", "pending", "FAILED");
            engineResult.message = "VERIFICATION FAILED: " + verification.issues.join(', ');
          }
        }
      }

      // 2. Kirim pesan ke AI dengan menyertakan hasil mesin sebagai konteks
      const headers: Record<string, string> = {
        'Content-Type': 'application/json'
      };
      
      // Susun pesan akhir untuk dikirim ke backend AI agar AI menyusun jawaban akhir
      let messageToSend = req.message;
      if (engineResult) {
        if (isSignalRequest && engineName === 'Signal Generation Pipeline') {
          const logs = (engineResult.data?.verificationLogs || []).join('\n');
          messageToSend += `\n\n[PROSES VALIDASI AKHIR PIPELINE SINYAL - NAVIX AI]:\n`;
          messageToSend += `TradingView & Forex Factory data telah sukses diselesaikan.\n`;
          messageToSend += `Analisis Sinyal Ganda (Dual-Signal) dari Signal Engine:\n`;
          messageToSend += `- Pasangan Aset: ${engineResult.data?.symbol}\n`;
          messageToSend += `- Live Price: ${engineResult.data?.price}\n`;
          messageToSend += `- Sinyal RUNNING: ${engineResult.data?.mainDirection} (Entry: ${engineResult.data?.mainEntry}, SL: ${engineResult.data?.mainSL}, TP: ${engineResult.data?.mainTP})\n`;
          messageToSend += `- Sinyal PENDING: ${engineResult.data?.pendingDirection} (Entry: ${engineResult.data?.pendingEntry}, SL: ${engineResult.data?.pendingSL}, TP: ${engineResult.data?.pendingTP})\n`;
          messageToSend += `- Confidence Score: ${engineResult.data?.confidenceScore}%\n`;
          messageToSend += `- Detail Teknikal: ${engineResult.data?.technicalSummary}\n`;
          messageToSend += `- Detail Fundamental: ${engineResult.data?.fundamentalSummary}\n`;
          messageToSend += `- Log Sistem Kontrol Detil:\n${logs}\n\n`;
          messageToSend += `INSTRUKSI MUTLAK UNTUK NAVIX AI:\n`;
          messageToSend += `1. Anda WAJIB menyajikan data sinyal ini kepada user secara langsung. JANGAN menggunakan blok kode JSON \`\`\`signal. Sajikan HANYA SATU sinyal (pilih yang paling berpotensi, apakah RUNNING atau PENDING) menggunakan teks markdown biasa yang diformat dengan rapi (misalnya menggunakan bold dan bullet points) di dalam penjelasan Anda.\n`;
          messageToSend += `2. Susun laporan analisis sinyal yang sangat profesional, terstruktur, rapi, dan mudah dibaca oleh trader.\n`;
          messageToSend += `3. Gunakan simbol arah yang jelas (🟢 BUY atau 🔴 SELL) dan tampilkan ulasan teknikal secara mendalam berdasarkan data Signal Engine.\n`;
          messageToSend += `4. Tampilkan daftar 'Sistem Kontrol Detail' yang lolos pengecekan.`;
        } else {
          messageToSend += `\n\n[INFORMASI TAMBAHAN REALTIME DARI ENGINE ${engineName}]:\n`;
          messageToSend += `Sumber: ${engineResult.source}\n`;
          messageToSend += `Status: ${engineResult.status}\n`;
          if (engineResult.current_price) {
            messageToSend += `Harga Sekarang: ${engineResult.current_price}\n`;
          }
          if (engineResult.message) {
            messageToSend += `Pesan Mesin: ${engineResult.message}\n`;
          }
          if (engineResult.data) {
            messageToSend += `Data Tambahan: ${JSON.stringify(engineResult.data)}\n`;
          }
        }
      }
      
      // NAVIX Cognitive Memory v2 Retrieval
      try {
        const { promptContext } = await navixMemoryEngine.retrieveContext(req.message);
        if (promptContext) {
          messageToSend += promptContext;
        }
      } catch (memErr) {
        console.warn('Navix Cognitive Memory retrieval warning:', memErr);
      }

      notify("verification_started", "pending", "Preparing Output");
      const res = await rotateFetch('/api/chat', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          message: messageToSend,
          attachments: req.attachments || [],
          disableTts: !req.voiceEnabled,
          model: req.model || "gemini-3.6-flash",
          history: req.history || [],
          isImageEdit: imageIntent === 'edit',
          isImageDiscuss: imageIntent === 'discuss',
          effort: req.effort,
          thinkingMode: req.thinkingMode
        })
      });

      const data = await res.json().catch(() => ({}));

      if (data.systemInstruction) {
        console.log(`[DEBUG LOG] Orchestrator: Final System Prompt sent to Gemini:\n`, data.systemInstruction);
      }

      if (res.status === 429) {
        return { error: '429', isRateLimit: true };
      }
      if (res.status === 413) {
        return { error: '413 Payload Too Large', isRateLimit: false };
      }

      if (res.ok && data.text) {
        // Asynchronously check if conversation contains key preferences or facts to save
        const lowMsg = req.message.toLowerCase();
        if (lowMsg.includes('ingat') || lowMsg.includes('simpan') || lowMsg.includes('saya suka') || lowMsg.includes('preferensi') || lowMsg.includes('keputusan') || lowMsg.includes('proyek')) {
          navixMemoryEngine.saveMemory({
            userId: 'default_user',
            projectId: 'navix_ai',
            type: lowMsg.includes('suka') || lowMsg.includes('preferensi') ? 'user_preference' : lowMsg.includes('keputusan') ? 'decision' : 'project',
            title: `Memori: ${req.message.slice(0, 40)}...`,
            content: req.message,
            importance: 85,
            confidence: 90,
            tags: ['conversation', 'auto_saved']
          }).catch(err => console.warn('Memory save background error:', err));
        }

        notify("supervisor_state", "done", "COMPLETED");
        notify("supervisor_state", "pending", "FINALIZING");
        notify("supervisor_state", "done", "COMPLETED");
        notify("thinking_completed", "done", "Task Completed");
        return {
          text: data.text,
          audioBase64: data.audioBase64,
          systemInstruction: data.systemInstruction
        };
      } else {
        return { error: data.error || 'Unknown Error' };
      }
    } catch (err: any) {
      console.error("Orchestrator Error:", err);
      return { error: err.message || 'Network Error' };
    }
  }
}

export const orchestrator = new NavixOrchestrator();

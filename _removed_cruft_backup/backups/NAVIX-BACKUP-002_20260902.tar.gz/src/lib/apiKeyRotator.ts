export interface KeyItem {
  key: string;
  status: 'active' | 'exhausted' | 'invalid';
  errorCount: number;
  lastUsed?: number;
  cooldownUntil?: number;
  errorMsg?: string;
}

const STORAGE_KEYS_LIST = 'navix_gemini_api_keys';

// Load keys from localStorage with automatic cooldown recovery (60 seconds)
export function getRotationKeys(): KeyItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS_LIST);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        const now = Date.now();
        let changed = false;
        
        const processed = parsed.map(k => {
          if (k.status === 'exhausted' && k.cooldownUntil && now > k.cooldownUntil) {
            changed = true;
            return {
              ...k,
              status: 'active' as const,
              errorMsg: undefined,
              cooldownUntil: undefined
            };
          }
          return k;
        });

        if (changed) {
          saveRotationKeys(processed);
        }
        return processed;
      }
    }
  } catch (err) {
    console.error('Error parsing rotation keys:', err);
  }

  // Fallback: Check if there's an old single key saved
  const oldKey = localStorage.getItem('navix_gemini_api_key');
  if (oldKey) {
    const fallbackList: KeyItem[] = [{
      key: oldKey,
      status: 'active',
      errorCount: 0,
      lastUsed: Date.now()
    }];
    saveRotationKeys(fallbackList);
    return fallbackList;
  }

  return [];
}

// Save keys to localStorage
export function saveRotationKeys(keys: KeyItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS_LIST, JSON.stringify(keys));
  } catch (err) {
    console.error('Error saving rotation keys:', err);
  }
}

// Sanitize a key
export function sanitizeApiKey(key: string): string {
  return key.trim().replace(/['"\s]/g, '').replace(/[^\x20-\x7E]/g, '');
}

// Get the first active key (or auto-recover if all keys exhausted)
export function getActiveApiKey(): string | null {
  let keys = getRotationKeys();
  let activeKeyItem = keys.find(k => k.status === 'active');
  
  if (!activeKeyItem && keys.length > 0) {
    // If all keys marked exhausted or invalid, auto-reset exhausted ones to active so rotation keeps going
    console.warn('[API KEY ROTATOR] All keys currently exhausted. Performing auto-recovery reset...');
    resetAllRotationKeys();
    keys = getRotationKeys();
    activeKeyItem = keys.find(k => k.status === 'active') || keys[0];
  }

  if (activeKeyItem) {
    activeKeyItem.lastUsed = Date.now();
    saveRotationKeys(keys);
    return activeKeyItem.key;
  }
  return null;
}

// Get all valid keys as comma-separated string for multi-key pool header (up to 100)
export function getAllActiveKeysHeader(): string | null {
  const keys = getRotationKeys();
  // Send all keys except completely invalid ones so the backend can run its robust server-side rotation
  const validKeys = keys.filter(k => k.status !== 'invalid').map(k => k.key);
  if (validKeys.length > 0) {
    return validKeys.slice(0, 100).join(',');
  }
  return null;
}

// Mark a key with a specific status
export function updateKeyStatus(key: string, status: 'active' | 'exhausted' | 'invalid', errorMsg?: string): void {
  const keys = getRotationKeys();
  const index = keys.findIndex(k => k.key === key);
  if (index !== -1) {
    keys[index].status = status;
    if (errorMsg) {
      keys[index].errorMsg = errorMsg;
    }
    if (status !== 'active') {
      keys[index].errorCount += 1;
    }
    if (status === 'exhausted') {
      // Cooldown for 60 seconds (60000ms)
      keys[index].cooldownUntil = Date.now() + 60000;
    } else {
      keys[index].cooldownUntil = undefined;
    }
    saveRotationKeys(keys);
    console.warn(`[API KEY ROTATION] Key index ${index} (${key.substring(0, 6)}...) status changed to ${status}. Error: ${errorMsg || 'None'}`);
  }
}

// Reset all keys to active status
export function resetAllRotationKeys(): void {
  const keys = getRotationKeys();
  const updated = keys.map(k => ({
    ...k,
    status: 'active' as const,
    errorMsg: undefined,
    cooldownUntil: undefined
  }));
  saveRotationKeys(updated);
}

// Detect if response contains quota or auth errors
function isQuotaOrAuthError(status: number, responseBody: any): { isError: boolean; type: 'exhausted' | 'invalid'; message: string } {
  const bodyText = typeof responseBody === 'string' 
    ? responseBody.toLowerCase() 
    : JSON.stringify(responseBody).toLowerCase();

  const hasQuotaKeyword = bodyText.includes('quota') || 
                           bodyText.includes('rate limit') || 
                           bodyText.includes('exceeded') || 
                           bodyText.includes('429') ||
                           bodyText.includes('resource_exhausted');

  const hasAuthKeyword = bodyText.includes('unauthenticated') || 
                          bodyText.includes('invalid authentication') || 
                          bodyText.includes('401') ||
                          bodyText.includes('api key not valid');

  if (status === 429 || hasQuotaKeyword) {
    return {
      isError: true,
      type: 'exhausted',
      message: responseBody.error?.message || responseBody.error || 'Quota / Limit Habis (429)'
    };
  }

  if (status === 401 || hasAuthKeyword) {
    return {
      isError: true,
      type: 'invalid',
      message: responseBody.error?.message || responseBody.error || 'API Key Tidak Valid (401)'
    };
  }

  return { isError: false, type: 'exhausted', message: '' };
}

// Enhanced fetch wrapper that rotates automatically on failure up to 100 keys
export async function rotateFetch(url: string, options: RequestInit = {}): Promise<Response> {
  let attempt = 0;
  const maxAttempts = 100; // Allow rotating up to 100 keys in a single operation

  while (attempt < maxAttempts) {
    const currentKey = getActiveApiKey();
    const allActiveHeader = getAllActiveKeysHeader();
    const headers = new Headers(options.headers || {});

    if (allActiveHeader) {
      // Send pool of keys to server so server can also attempt internal rotation
      headers.set('x-custom-api-key', allActiveHeader);
    } else if (currentKey) {
      headers.set('x-custom-api-key', currentKey);
    } else {
      // No custom key active, let server fallback to environment variable GEMINI_API_KEY
      headers.delete('x-custom-api-key');
    }

    const currentOptions: RequestInit = {
      ...options,
      headers
    };

    try {
      const response = await fetch(url, currentOptions);
      
      // Clone response to read body without consuming it
      const responseClone = response.clone();
      let responseData: any = {};
      try {
        responseData = await responseClone.json();
      } catch {
        try {
          responseData = await responseClone.text();
        } catch {}
      }

      // Check if this response signals a quota/auth error with our custom key
      if (currentKey && !response.ok) {
        const errorCheck = isQuotaOrAuthError(response.status, responseData);
        if (errorCheck.isError) {
          console.warn(`[ROTATION FETCH] Key (${currentKey.substring(0, 6)}...) failed with ${errorCheck.type}. Rotating to next key (attempt ${attempt + 1}/100)...`);
          updateKeyStatus(currentKey, errorCheck.type, errorCheck.message);
          attempt++;
          // Wait briefly before retrying next key
          await new Promise(resolve => setTimeout(resolve, 300));
          continue; // Try again with the next key in rotation
        }
      }

      return response;
    } catch (err: any) {
      if (currentKey) {
        console.error(`[ROTATION FETCH] Request failed with network error under current key:`, err);
        updateKeyStatus(currentKey, 'invalid', err?.message || 'Network error');
        attempt++;
        continue;
      }
      throw err;
    }
  }

  // If we exhausted all custom keys, make final try with server environment key
  console.error('[ROTATION FETCH] All custom API keys exhausted after 100 attempts! Falling back to Server Env Key.');
  const fallbackHeaders = new Headers(options.headers || {});
  fallbackHeaders.delete('x-custom-api-key');
  return fetch(url, { ...options, headers: fallbackHeaders });
}

import { McpSkillAdapter } from './McpSkillAdapter';
import { NavixValidator } from './NavixValidator';

export class McpSkillExecutor {
  static async execute(skillName: string, args: any): Promise<any> {
    try {
      const payload = McpSkillAdapter.adaptRequest(skillName, args);
      const res = await fetch(`/api/mcp/execute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const rawOutput = await res.json();
      return NavixValidator.validateOutput(rawOutput);
    } catch (error: any) {
      return { success: false, error: error.message || "Failed to execute MCP Skill" };
    }
  }
}

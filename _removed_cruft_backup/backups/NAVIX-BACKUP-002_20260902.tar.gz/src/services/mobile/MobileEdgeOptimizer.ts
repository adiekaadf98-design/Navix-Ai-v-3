/**
 * NAVIX AI — MOBILE EDGE STREAM & ADAPTIVE IMAGE/PAYLOAD TOKEN OPTIMIZER
 * 
 * Compresses chart screenshots, optimizes image tokens before cloud dispatch,
 * reduces mobile data consumption, and provides offline calculation fallbacks.
 */

export interface MobileNetworkQuality {
  effectiveType: 'slow-2g' | '2g' | '3g' | '4g' | 'wifi';
  downlinkSpeedMbps: number;
  rttMs: number;
  saveDataMode: boolean;
  recommendedCompressionQuality: number; // 0.1 to 1.0
  maxImageDimension: number; // max width/height in px
}

export class MobileEdgeOptimizer {
  /**
   * Detects real-time mobile browser connection telemetry.
   */
  public getNetworkProfile(): MobileNetworkQuality {
    if (typeof navigator !== 'undefined' && 'connection' in navigator) {
      const conn = (navigator as any).connection;
      if (conn) {
        const effectiveType = conn.effectiveType || '4g';
        const isSlow = effectiveType === '2g' || effectiveType === 'slow-2g' || effectiveType === '3g';
        const saveData = Boolean(conn.saveData);

        return {
          effectiveType,
          downlinkSpeedMbps: conn.downlink || 10,
          rttMs: conn.rtt || 100,
          saveDataMode: saveData,
          recommendedCompressionQuality: isSlow || saveData ? 0.45 : 0.85,
          maxImageDimension: isSlow || saveData ? 800 : 1600
        };
      }
    }

    return {
      effectiveType: '4g',
      downlinkSpeedMbps: 20,
      rttMs: 50,
      saveDataMode: false,
      recommendedCompressionQuality: 0.85,
      maxImageDimension: 1600
    };
  }

  /**
   * Intelligently downscales and compresses image base64 / blob for low-bandwidth environments.
   */
  public async optimizeImageForMobile(
    base64DataUrl: string,
    overrideQuality?: number
  ): Promise<{ optimizedDataUrl: string; compressionRatio: number; originalBytes: number; optimizedBytes: number }> {
    if (typeof window === 'undefined' || typeof document === 'undefined') {
      return {
        optimizedDataUrl: base64DataUrl,
        compressionRatio: 1.0,
        originalBytes: base64DataUrl.length,
        optimizedBytes: base64DataUrl.length
      };
    }

    const network = this.getNetworkProfile();
    const targetQuality = overrideQuality ?? network.recommendedCompressionQuality;
    const maxDim = network.maxImageDimension;

    return new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          return resolve({
            optimizedDataUrl: base64DataUrl,
            compressionRatio: 1.0,
            originalBytes: base64DataUrl.length,
            optimizedBytes: base64DataUrl.length
          });
        }

        ctx.drawImage(img, 0, 0, width, height);
        const optimized = canvas.toDataURL('image/jpeg', targetQuality);

        const origBytes = Math.round((base64DataUrl.length * 3) / 4);
        const optBytes = Math.round((optimized.length * 3) / 4);
        const ratio = Number((optBytes / (origBytes || 1)).toFixed(2));

        resolve({
          optimizedDataUrl: optimized,
          compressionRatio: ratio,
          originalBytes: origBytes,
          optimizedBytes: optBytes
        });
      };

      img.onerror = () => {
        resolve({
          optimizedDataUrl: base64DataUrl,
          compressionRatio: 1.0,
          originalBytes: base64DataUrl.length,
          optimizedBytes: base64DataUrl.length
        });
      };

      img.src = base64DataUrl;
    });
  }

  /**
   * Offline Fast Indicator Engine (Calculates RSI, SMA, and SNR boundaries offline).
   */
  public calculateOfflineIndicators(closes: number[]): {
    sma20: number;
    rsi14: number;
    trend: 'BULLISH' | 'BEARISH' | 'SIDEWAYS';
  } {
    if (!closes || closes.length < 20) {
      return { sma20: closes[closes.length - 1] || 0, rsi14: 50, trend: 'SIDEWAYS' };
    }

    // SMA 20
    const last20 = closes.slice(-20);
    const sma20 = last20.reduce((a, b) => a + b, 0) / 20;

    // RSI 14
    let gains = 0;
    let losses = 0;
    for (let i = closes.length - 14; i < closes.length; i++) {
      const diff = closes[i] - closes[i - 1];
      if (diff >= 0) gains += diff;
      else losses += Math.abs(diff);
    }
    const avgGain = gains / 14;
    const avgLoss = losses / 14 || 0.0001;
    const rs = avgGain / avgLoss;
    const rsi14 = Number((100 - (100 / (1 + rs))).toFixed(2));

    const current = closes[closes.length - 1];
    const trend = current > sma20 && rsi14 > 52 ? 'BULLISH' : (current < sma20 && rsi14 < 48 ? 'BEARISH' : 'SIDEWAYS');

    return {
      sma20: Number(sma20.toFixed(4)),
      rsi14,
      trend
    };
  }
}

export const mobileEdgeOptimizer = new MobileEdgeOptimizer();

import React, { useState } from 'react';
import { Code2, Copy, Check, Info, FileCode } from 'lucide-react';

interface PineScriptViewerProps {
  code: string;
}

export const PineScriptViewer: React.FC<PineScriptViewerProps> = ({ code }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="my-4 rounded-xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl animate-fade-in">
      {/* Viewer Header */}
      <div className="px-4 py-3 bg-slate-950 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FileCode className="w-4 h-4 text-indigo-400" />
          <span className="text-xs font-bold text-indigo-300 font-mono tracking-wider">
            PINE SCRIPT v5 ENGINE
          </span>
        </div>
        
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-medium text-slate-300 transition-all border border-slate-700/60"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-400 font-semibold">Tersalin</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Salin Kode</span>
            </>
          )}
        </button>
      </div>

      {/* Editor/Code container */}
      <div className="relative">
        <pre className="p-4 overflow-x-auto text-xs font-mono text-slate-300 bg-slate-950 leading-relaxed max-h-[350px]">
          <code>{code}</code>
        </pre>
      </div>

      {/* Info & Usage guide */}
      <div className="p-3.5 bg-slate-900 border-t border-slate-800/60 flex items-start gap-2.5 text-xs">
        <Info className="w-4.5 h-4.5 text-indigo-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <span className="font-semibold text-slate-200">Cara Menggunakan di TradingView:</span>
          <p className="text-slate-400 leading-relaxed">
            1. Salin kode di atas.
            <br />
            2. Buka **TradingView.com** & masuk ke Chart.
            <br />
            3. Klik tab **Pine Editor** di bagian bawah layar.
            <br />
            4. Tempelkan (paste) kode ini, lalu klik **Add to Chart**.
          </p>
        </div>
      </div>
    </div>
  );
};

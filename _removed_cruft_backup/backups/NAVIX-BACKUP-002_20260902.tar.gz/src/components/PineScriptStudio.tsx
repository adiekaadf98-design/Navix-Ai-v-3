import React, { useState } from 'react';
import { Play, Copy, Check, Terminal, Code2, Download } from 'lucide-react';

interface PineScriptStudioProps {
  initialCode?: string;
  onRun?: (code: string) => void;
}

export const PineScriptStudio: React.FC<PineScriptStudioProps> = ({
  initialCode = `//@version=5\nindicator("Navix Pro Strategy", overlay=true)\n\nfastLength = input(12, "Fast EMA")\nslowLength = input(26, "Slow EMA")\nsignalLength = input(9, "Signal EMA")\n\nfastEMA = ta.ema(close, fastLength)\nslowEMA = ta.ema(close, slowLength)\nplot(fastEMA, color=color.blue, title="Fast EMA")\nplot(slowEMA, color=color.orange, title="Slow EMA")`,
  onRun
}) => {
  const [code, setCode] = useState(initialCode);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'editor' | 'console'>('editor');

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="pinescript-studio-card" className="w-full my-4 rounded-xl border border-slate-800 bg-slate-950 overflow-hidden shadow-2xl">
      <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900/90 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Code2 className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider">TradingView Pine Script Studio v5</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 rounded transition"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Tersalin' : 'Salin Script'}
          </button>
          <button
            onClick={() => onRun && onRun(code)}
            className="flex items-center gap-1.5 px-3 py-1 text-xs font-medium bg-emerald-600 hover:bg-emerald-500 text-white rounded transition"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            Compile
          </button>
        </div>
      </div>

      <div className="p-3">
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          className="w-full h-48 bg-slate-900 text-slate-200 font-mono text-xs p-3 rounded-lg border border-slate-800 focus:outline-none focus:border-emerald-500/50 resize-y"
          spellCheck={false}
        />
      </div>

      <div className="px-4 py-2 bg-slate-900/50 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
          <span>Pine Script Engine Ready</span>
        </div>
        <span>Overlay: True • Strategy v5</span>
      </div>
    </div>
  );
};

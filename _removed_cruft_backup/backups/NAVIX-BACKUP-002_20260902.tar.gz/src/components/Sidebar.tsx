import { Menu, Plus, MessageSquare, Settings, Compass, Trash2, X, Beaker, FileText, Cloud, Layout, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';
import { ChatSession } from '../types';
import { SettingsModal } from './SettingsModal';
import { ExploreModal } from './ExploreModal';

interface SidebarProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  onNewChat: () => void;
  sessions: ChatSession[];
  currentSessionId: string | null;
  onSelectSession: (id: string) => void;
  onDeleteSession: (id: string, e: React.MouseEvent) => void;
  currentView: 'chat' | 'studio' | 'document' | 'science' | 'cloud';
  onSwitchView: (view: 'chat' | 'studio' | 'document' | 'science' | 'cloud') => void;
}

export function Sidebar({ 
  isOpen, 
  setIsOpen, 
  onNewChat, 
  sessions, 
  currentSessionId, 
  onSelectSession, 
  onDeleteSession,
  currentView,
  onSwitchView
}: SidebarProps) {
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isExploreOpen, setIsExploreOpen] = useState(false);

  return (
    <>
      {/* Mobile Backdrop Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsOpen(false)}
            className="md:hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] cursor-pointer"
          />
        )}
      </AnimatePresence>

      <motion.div 
        initial={false}
        animate={{ width: isOpen ? 260 : 64 }}
        className={`h-full bg-[#1c1c1c] md:bg-neutral-900 border-r border-neutral-800 flex flex-col transition-all duration-300 ease-in-out shrink-0 overflow-hidden ${
          isOpen ? 'fixed inset-y-0 left-0 z-[110] md:relative md:z-auto' : 'hidden md:flex relative'
        }`}
      >
        <div className="flex items-center justify-between h-16 px-4 shrink-0 border-b border-neutral-800/40">
          <button 
            onClick={() => setIsOpen(!isOpen)}
            className="text-neutral-400 hover:text-white transition-colors p-2 rounded-lg hover:bg-neutral-800 flex items-center justify-center cursor-pointer"
            title="Toggle Sidebar"
          >
            <Menu size={20} />
          </button>
          {isOpen && (
            <div className="flex items-center gap-2 pr-2">
              <span className="font-bold text-sm tracking-wide text-white">Navix AI</span>
              <span className="px-1.5 py-0.5 rounded text-[9px] bg-red-500/20 text-red-400 border border-red-500/30 font-mono">v3.5</span>
            </div>
          )}
        </div>

        <div className="p-3">
          <button 
            onClick={onNewChat}
            className="w-full flex items-center gap-3 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-full px-4 py-2.5 transition-colors border border-neutral-700 mb-2"
          >
            <Plus size={18} className="text-red-500 shrink-0" />
            {isOpen && <span className="font-medium whitespace-nowrap">New chat</span>}
          </button>
        </div>

        {/* View Switcher Menu */}
        <div className="px-3 mb-2 space-y-1">
          <button 
            onClick={() => onSwitchView('chat')}
            className={`w-full flex items-center gap-3 py-2.5 px-3 rounded-lg transition-colors ${!isOpen && 'justify-center px-0'} ${currentView === 'chat' ? 'bg-red-500/10 text-red-500 font-semibold' : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'}`}
          >
            <MessageSquare size={18} className="shrink-0" />
            {isOpen && <span className="text-sm">Chat AI</span>}
          </button>
          
          <button 
            onClick={() => onSwitchView('studio')}
            className={`w-full flex items-center gap-3 py-2.5 px-3 rounded-lg transition-colors ${!isOpen && 'justify-center px-0'} ${currentView === 'studio' ? 'bg-rose-500/15 text-rose-400 font-semibold border border-rose-500/30' : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'}`}
          >
            <Sparkles size={18} className="shrink-0 text-rose-500" />
            {isOpen && (
              <span className="text-sm flex items-center gap-1.5 font-bold">
                Studio AI
                <span className="text-[10px] bg-gradient-to-r from-rose-500 to-amber-500 text-white font-bold px-1.5 py-0.2 rounded uppercase scale-90">Canvas</span>
              </span>
            )}
          </button>

          <button 
            onClick={() => onSwitchView('science')}
            className={`w-full flex items-center gap-3 py-2.5 px-3 rounded-lg transition-colors ${!isOpen && 'justify-center px-0'} ${currentView === 'science' ? 'bg-blue-500/10 text-blue-500 font-semibold' : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'}`}
          >
            <Beaker size={18} className="shrink-0" />
            {isOpen && <span className="text-sm">Science Lab</span>}
          </button>

          <button 
            onClick={() => onSwitchView('document')}
            className={`w-full flex items-center gap-3 py-2.5 px-3 rounded-lg transition-colors ${!isOpen && 'justify-center px-0'} ${currentView === 'document' ? 'bg-emerald-500/10 text-emerald-500 font-semibold' : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'}`}
          >
            <FileText size={18} className="shrink-0" />
            {isOpen && <span className="text-sm">Doc Editor</span>}
          </button>

          <button 
            onClick={() => onSwitchView('cloud')}
            className={`w-full flex items-center gap-3 py-2.5 px-3 rounded-lg transition-colors ${!isOpen && 'justify-center px-0'} ${currentView === 'cloud' ? 'bg-blue-500/15 text-blue-400 font-semibold border border-blue-500/30' : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'}`}
          >
            <Cloud size={18} className="shrink-0 text-blue-400" />
            {isOpen && (
              <span className="text-sm flex items-center gap-1.5">
                Google Cloud 
                <span className="text-[10px] bg-blue-500 text-white font-bold px-1 py-0.2 rounded uppercase scale-90">Console</span>
              </span>
            )}
          </button>
        </div>

        <div className="flex-1 overflow-y-auto overflow-x-hidden border-t border-neutral-800/40 pt-4">
          {isOpen && (
            <div className="px-4">
              <h3 className="text-xs font-semibold text-neutral-500 mb-2 uppercase tracking-wider">Recent</h3>
              <div className="space-y-1">
                {sessions.length === 0 && (
                  <div className="text-sm text-neutral-600 italic px-2 py-2">Belum ada history</div>
                )}
                {sessions.map((session) => (
                  <div 
                    key={session.id} 
                    onClick={() => onSelectSession(session.id)}
                    className={`w-full text-left flex items-center justify-between text-sm py-2.5 px-3 rounded-lg transition-colors overflow-hidden group cursor-pointer ${
                      currentSessionId === session.id 
                        ? 'bg-neutral-800 text-white' 
                        : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
                    }`}
                  >
                    <div className="flex items-center gap-3 overflow-hidden">
                      <MessageSquare size={16} className={`shrink-0 transition-colors ${currentSessionId === session.id ? 'text-red-500' : 'text-neutral-500 group-hover:text-red-500/80'}`} />
                      <span className="truncate">{session.title}</span>
                    </div>
                    <button 
                      onClick={(e) => onDeleteSession(session.id, e)}
                      className="md:opacity-0 md:group-hover:opacity-100 p-1 text-neutral-500 hover:text-red-400 transition-all"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="p-3 shrink-0 mb-2 space-y-1">
          <button onClick={() => setIsExploreOpen(true)} className={`w-full flex items-center gap-3 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 py-2.5 px-3 rounded-lg transition-colors ${!isOpen && 'justify-center px-0'}`}>
            <Compass size={18} className="shrink-0" />
            {isOpen && <span className="text-sm font-medium">Explore AI</span>}
          </button>
          <button onClick={() => setIsSettingsOpen(true)} className={`w-full flex items-center gap-3 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 py-2.5 px-3 rounded-lg transition-colors ${!isOpen && 'justify-center px-0'}`}>
            <Settings size={18} className="shrink-0" />
            {isOpen && <span className="text-sm font-medium">Settings</span>}
          </button>
        </div>
      </motion.div>

      <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
      <ExploreModal isOpen={isExploreOpen} onClose={() => setIsExploreOpen(false)} />
    </>
  );
}

import React, { useState } from 'react';
import { TrendingUp, Maximize2, Coins, BarChart3 } from 'lucide-react';

interface TradingViewChartProps {
  symbol: string;
}

export const TradingViewChart: React.FC<TradingViewChartProps> = ({ symbol: initialSymbol }) => {
  const [symbol, setSymbol] = useState(initialSymbol);
  
  const popularSymbols = [
    { name: '₿ BTC', val: 'BTCUSDT' },
    { name: '♦ ETH', val: 'ETHUSDT' },
    { name: '☀ SOL', val: 'SOLUSDT' },
    { name: '🪙 XAU (Gold)', val: 'OANDA:XAUUSD' },
    { name: '💱 EUR/USD', val: 'FX:EURUSD' }
  ];

  // Map symbols to TradingView format
  const getCleanSymbol = (sym: string) => {
    if (sym === 'GOLD') return 'OANDA:XAUUSD';
    if (!sym.includes(':') && sym !== 'BTCUSDT' && sym !== 'ETHUSDT' && sym !== 'SOLUSDT') {
      return `BINANCE:${sym}`;
    }
    return sym;
  };

  const cleanSymbol = getCleanSymbol(symbol);

  return (
    <div className="my-4 rounded-xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl animate-fade-in">
      {/* Chart Header */}
      <div className="px-4 py-3 bg-slate-950 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-bold text-slate-100 font-mono tracking-wider uppercase">
            TradingView Live Chart: {symbol}
          </span>
        </div>
        
        {/* Symbol Quick Selectors */}
        <div className="flex flex-wrap items-center gap-1.5">
          {popularSymbols.map((item) => (
            <button
              key={item.val}
              onClick={() => setSymbol(item.val)}
              className={`px-2 py-1 rounded text-[10px] font-semibold transition-all ${
                symbol === item.val
                  ? 'bg-indigo-600 text-white shadow shadow-indigo-600/30'
                  : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
              }`}
            >
              {item.name}
            </button>
          ))}
        </div>
      </div>

      {/* Chart Frame */}
      <div className="relative w-full h-[380px] md:h-[450px] bg-slate-950">
        <iframe
          id={`tradingview-iframe-${symbol}`}
          title={`TradingView Chart for ${symbol}`}
          src={`https://s.tradingview.com/widgetembed/?frameElementId=tradingview-iframe-${symbol}&symbol=${encodeURIComponent(
            cleanSymbol
          )}&interval=D&hidesidetoolbar=0&symboledit=1&saveimage=1&toolbarbg=f1f3f6&studies=%5B%5D&theme=dark&style=1&timezone=Asia%2FJakarta&studies_overrides=%7B%7D&overrides=%7B%7D&enabled_features=%5B%5D&disabled_features=%5B%5D&locale=id&utm_source=navix-ai&utm_medium=widget&utm_campaign=chart-embed`}
          className="absolute inset-0 w-full h-full border-0"
          allowFullScreen
        />
      </div>

      {/* Footer / Meta bar */}
      <div className="px-4 py-2 bg-slate-950 text-[10px] text-slate-500 flex items-center justify-between border-t border-slate-800/60 font-mono">
        <span className="flex items-center gap-1">
          <BarChart3 className="w-3.5 h-3.5 text-slate-400" />
          RSI, MACD, MA dapat ditambahkan langsung lewat indikator TradingView
        </span>
        <span className="text-emerald-500 font-semibold flex items-center gap-1 animate-pulse">
          ● Real-time
        </span>
      </div>
    </div>
  );
};

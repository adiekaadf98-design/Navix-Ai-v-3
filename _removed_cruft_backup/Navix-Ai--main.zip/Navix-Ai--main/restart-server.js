// Fake script to restart dev server using the default API

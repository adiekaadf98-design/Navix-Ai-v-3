import { globalCapabilityRegistry } from './src/backend/shadow/CapabilityRegistry';
import { globalJobManager } from './src/backend/shadow/JobManager';
import { globalTelemetry } from './src/backend/shadow/Telemetry';
import { globalModelRegistry } from './src/backend/shadow/ModelRegistry';
import { globalPipelineClassifier } from './src/backend/shadow/PipelineClassifier';
import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import ffmpeg from "fluent-ffmpeg";
import fs from "fs";
import { v4 as uuidv4 } from "uuid";
import { navixSecurityShield } from "./src/backend/engines/SecurityShield";
import { navixAiRouter } from "./src/backend/engines/AIRouter";
import { navixVerificationEngine } from "./src/backend/engines/VerificationEngine";
import { taskEngine } from "./src/backend/engines/TaskEngine";
import { knowledgeEngine } from "./src/backend/engines/KnowledgeEngine";
import { creativeEngine } from "./src/backend/engines/CreativeEngine";
import { monitoringEngine } from "./src/backend/engines/MonitoringEngine";
import jwt from "jsonwebtoken";

function getAiClient(req: express.Request): GoogleGenAI {
  const customKey = req.headers['x-custom-api-key'] as string;
  const apiKey = customKey || process.env.GEMINI_API_KEY;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

function pcmToWav(pcmData: Buffer, sampleRate: number = 24000): Buffer {
  const numChannels = 1;
  const bitsPerSample = 16;
  const byteRate = sampleRate * numChannels * (bitsPerSample / 8);
  const blockAlign = numChannels * (bitsPerSample / 8);

  const dataSize = pcmData.length;
  const buffer = Buffer.alloc(44 + dataSize);

  // RIFF chunk descriptor
  buffer.write('RIFF', 0);
  buffer.writeUInt32LE(36 + dataSize, 4);
  buffer.write('WAVE', 8);

  // fmt sub-chunk
  buffer.write('fmt ', 12);
  buffer.writeUInt32LE(16, 16); 
  buffer.writeUInt16LE(1, 20);  
  buffer.writeUInt16LE(numChannels, 22);
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(byteRate, 28);
  buffer.writeUInt16LE(blockAlign, 32);
  buffer.writeUInt16LE(bitsPerSample, 34);

  // data sub-chunk
  buffer.write('data', 36);
  buffer.writeUInt32LE(dataSize, 40);

  pcmData.copy(buffer, 44);

  return buffer;
}

async function getBinanceKlinesText(symbol: string): Promise<string> {
  try {
    const fetchKlines = async (interval: string, limit: number) => {
      try {
        const res = await fetch(`https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
        if (!res.ok) return "";
        const data = await res.json();
        
        let text = `\n[DATA CHART ${interval} TERAKHIR OHLC UNTUK ${symbol}]:\n`;
        const displayData = data.slice(-limit);
        displayData.forEach((k: any, index: number) => {
          text += `Candle ${index + 1} - Open: ${parseFloat(k[1])}, High: ${parseFloat(k[2])}, Low: ${parseFloat(k[3])}, Close: ${parseFloat(k[4])}\n`;
        });
        return text;
      } catch (e) {
        return "";
      }
    };
    
    const [tf4h, tf1h, tf15m, tf5m] = await Promise.all([
      fetchKlines("4h", 5),
      fetchKlines("1h", 5),
      fetchKlines("15m", 5),
      fetchKlines("5m", 5)
    ]);
    
    let combinedText = `\n===== ANALISA MARKET MULTI-TIMEFRAME (NAVIX ENGINE - BINANCE REALTIME) =====\n`;
    combinedText += tf4h + tf1h + tf15m + tf5m;
    combinedText += `\nANALISIS STRUKTUR & STOP LOSS (TIGHT SL):
    - Pastikan trend selaras dengan struktur market MODERN SMC (Inducement, FVG, Liquidity Sweeps).
    - Gunakan data candle (High/Low) TF 15M untuk konfirmasi Candle Rejection Theory (CRT) dan entry presisi di area Fibonacci OTE.
    - Stop Loss (SL) SECARA SANGAT SEMPIT (TIGHT SL). SL HARUS presisi (misal: tepat di atas Swing High 15m terbaru atau di bawah Swing Low 15m terbaru). Jangan ngawur.
    =======================================================================\n`;
    
    return combinedText;
  } catch (e) {
    return "";
  }
}

async function getYahooKlinesText(symbol: string, priceOffset: number = 0): Promise<string> {
  try {
    const fetchKlines = async (interval: string, range: string, limit: number) => {
      try {
        const yahooRes = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?interval=${interval}&range=${range}`);
        if (!yahooRes.ok) return "";
        const data = await yahooRes.json();
        const result = data.chart.result?.[0];
        if (!result) return "";
        
        const timestamps = result.timestamp || [];
        const quote = result.indicators?.quote?.[0] || {};
        const opens = quote.open || [];
        const highs = quote.high || [];
        const lows = quote.low || [];
        const closes = quote.close || [];
        
        const validCandles: {open: number, high: number, low: number, close: number}[] = [];
        for (let i = 0; i < timestamps.length; i++) {
          if (opens[i] !== null && highs[i] !== null && lows[i] !== null && closes[i] !== null &&
              opens[i] !== undefined && highs[i] !== undefined && lows[i] !== undefined && closes[i] !== undefined) {
            validCandles.push({
              open: parseFloat((opens[i] + priceOffset).toFixed(2)),
              high: parseFloat((highs[i] + priceOffset).toFixed(2)),
              low: parseFloat((lows[i] + priceOffset).toFixed(2)),
              close: parseFloat((closes[i] + priceOffset).toFixed(2))
            });
          }
        }
        
        const displayData = validCandles.slice(-limit);
        let text = `\n[DATA CHART ${interval} TERAKHIR OHLC UNTUK ${symbol}]:\n`;
        displayData.forEach((k, index) => {
          text += `Candle ${index + 1} - Open: ${k.open}, High: ${k.high}, Low: ${k.low}, Close: ${k.close}\n`;
        });
        
        return text;
      } catch (e) {
        return "";
      }
    };
    
    const [tf1d, tf1h, tf15m, tf5m] = await Promise.all([
      fetchKlines("1d", "2y", 5),
      fetchKlines("1h", "1mo", 5),
      fetchKlines("15m", "10d", 5),
      fetchKlines("5m", "5d", 5)
    ]);
    
    let combinedText = `\n===== ANALISA MARKET MULTI-TIMEFRAME (NAVIX ENGINE - YAHOO REALTIME) =====\n`;
    combinedText += tf1d + tf1h + tf15m + tf5m;
    combinedText += `\nANALISIS STRUKTUR & STOP LOSS (TIGHT SL):
    - Pastikan trend selaras dengan struktur market MODERN SMC (Inducement, FVG, Liquidity Sweeps).
    - Gunakan data candle (High/Low) TF 15M untuk konfirmasi Candle Rejection Theory (CRT) dan entry presisi di area Fibonacci OTE.
    - Stop Loss (SL) SECARA SANGAT SEMPIT (TIGHT SL). SL HARUS presisi (misal: tepat di atas Swing High 15m terbaru atau di bawah Swing Low 15m terbaru). Jangan ngawur.
    =======================================================================\n`;
    
    return combinedText;
  } catch (e) {
    return "";
  }
}


async function getEconomicCalendarText(): Promise<string> {
  try {
    const res = await fetch('https://api.binance.com/api/v3/ticker/24hr?symbol=BTCUSDT');
    let btcData = "";
    if (res.ok) {
      const data = await res.json();
      btcData = `\n[MARKET SENTIMENT 24HR BTCUSDT]: Last Price: $${data.lastPrice}, 24h Change: ${data.priceChangePercent}%, 24h High: $${data.highPrice}, 24h Low: $${data.lowPrice}\n`;
    }
    const tvRes = await fetch('https://scanner.tradingview.com/cfd/scan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ symbols: { tickers: ["OANDA:XAUUSD", "FX_IDC:EURUSD"] }, columns: ["close", "change"] })
    });
    let tvData = "";
    if (tvRes.ok) {
      const data = await tvRes.json();
      if (data && data.data) {
        tvData = `\n[TRADINGVIEW REALTIME FX/GOLD]:\n` + data.data.map((item: any) => `- ${item.s}: Price ${item.d[0]}, 24h Change ${item.d[1]}%`).join('\n') + '\n';
      }
    }
    return `=== KALENDER & SENTIMEN PASAR MAKRO REALTIME (FOREX FACTORY & TRADINGVIEW ENGINE) ===\n${btcData}${tvData}\nInstruksi: Gunakan data sentimen pasar realtime di atas untuk analisis fundamental makroekonomi terpadu.\n`;
  } catch (e) {
    return "[KALENDER EKONOMI & PASAR REALTIME]: Data pasar realtime siap diproses melalui engine Forex Factory & TradingView.";
  }
}

async function startServer() {
  await globalCapabilityRegistry.discoverCapabilities();
  const app = express();
  const PORT = 3000;

  // Increase payload limit for base64 files
  app.use(express.json({ limit: "500mb" }));
  app.use(express.urlencoded({ extended: true, limit: "500mb" }));

  // Binance Proxy to avoid CORS/Failed to fetch issues
  app.get("/api/binance/klines", async (req, res) => {
    try {
      const { symbol, interval, limit } = req.query;
      if (!symbol) return res.status(400).json({ error: "Missing symbol" });
      const response = await fetch(`https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval || '1m'}&limit=${limit || '50'}`, {
        signal: AbortSignal.timeout(10000)
      });
      if (!response.ok) {
        return res.status(response.status).json({ error: "Binance API error" });
      }
      const data = await response.json();
      res.json(data);
    } catch (err: any) {
      console.error("Binance proxy error", err);
      res.status(500).json({ error: "Failed to fetch from Binance" });
    }
  });

  app.get("/api/binance/price", async (req, res) => {
    try {
      const { symbol } = req.query;
      if (!symbol) return res.status(400).json({ error: "Missing symbol" });
      const response = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${symbol}`, {
        signal: AbortSignal.timeout(10000)
      });
      if (!response.ok) {
        return res.status(response.status).json({ error: "Binance API error" });
      }
      const data = await response.json();
      res.json(data);
    } catch (err: any) {
      console.error("Binance price proxy error", err);
      res.status(500).json({ error: "Failed to fetch from Binance price ticker" });
    }
  });

  // TradingView Scan API Proxy to bypass CORS
  app.post("/api/tradingview/scan", async (req, res) => {
    try {
      const response = await fetch('https://scanner.tradingview.com/cfd/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body),
        signal: AbortSignal.timeout(10000)
      });
      if (!response.ok) {
        return res.status(response.status).json({ error: "TradingView Scan API error" });
      }
      const data = await response.json();
      res.json(data);
    } catch (err: any) {
      console.error("TradingView proxy error", err);
      res.status(500).json({ error: "Failed to fetch from TradingView" });
    }
  });

  // Yahoo Finance Chart API Proxy to bypass CORS
  app.get("/api/yahoo/chart", async (req, res) => {
    try {
      const { symbol } = req.query;
      if (!symbol) return res.status(400).json({ error: "Missing symbol" });
      const response = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${symbol}`, {
        signal: AbortSignal.timeout(10000)
      });
      if (!response.ok) {
        return res.status(response.status).json({ error: "Yahoo Finance API error" });
      }
      const data = await response.json();
      res.json(data);
    } catch (err: any) {
      console.error("Yahoo Finance proxy error", err);
      res.status(500).json({ error: "Failed to fetch from Yahoo Finance" });
    }
  });

  app.post("/api/test-key", async (req, res) => {
    try {
      const aiClient = getAiClient(req);
      const testResponse = await aiClient.models.generateContent({
        model: "gemini-3.5-flash",
        contents: "Ping",
      });
      if (testResponse && testResponse.text) {
        res.json({ success: true });
      } else {
        res.json({ success: false, error: "No response text received from Gemini API." });
      }
    } catch (err: any) {
      console.error("Gemini API key test failed:", err);
      res.json({ success: false, error: err?.message || String(err) });
    }
  });

  // Auth Login Route
  app.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ success: false, error: "Email and password are required" });
    }
    const token = jwt.sign(
      { id: "user_123", email, role: "user" },
      process.env.JWT_SECRET || 'navix_default_secret_key_change_in_production',
      { expiresIn: '7d' }
    );
    res.json({
      success: true,
      token,
      user: { id: "user_123", email, role: "user" }
    });
  });

  // Task Engine API Routes
  app.post("/api/tasks", async (req, res) => {
    try {
      const { type, payload } = req.body;
      const taskId = await taskEngine.submitTask(type || "general", payload || {});
      res.json({ taskId, status: "pending" });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/tasks/:id", async (req, res) => {
    try {
      const task = await taskEngine.getTaskStatus(req.params.id);
      if (!task) return res.status(404).json({ error: "Task not found" });
      res.json(task);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Knowledge Engine API Route
  app.post("/api/knowledge/ingest", async (req, res) => {
    try {
      const { docId, text, metadata } = req.body;
      const result = await knowledgeEngine.ingestDocument(docId, text, metadata);
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Creative Engine API Route
  app.post("/api/creative/image", async (req, res) => {
    try {
      const { prompt, aspectRatio } = req.body;
      const result = await creativeEngine.generateImage(prompt, aspectRatio);
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Monitoring Engine API Routes
  app.get("/api/monitoring/health", async (req, res) => {
    try {
      const health = await monitoringEngine.getSystemHealth();
      res.json(health);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/monitoring/stats", async (req, res) => {
    try {
      const stats = await monitoringEngine.getApiStats();
      res.json(stats);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // API constraints route
  app.post("/api/chat", async (req, res) => {
    try {
      const shieldValidation = navixSecurityShield.validateRequest(req);
      if (!shieldValidation.valid) {
        return res.status(429).json({ error: shieldValidation.reason || "Security Shield limit exceeded" });
      }

      const { message, attachments, disableTts, model, history = [] } = req.body;
      
      if (!message && (!attachments || attachments.length === 0)) {
        return res.status(400).json({ error: "Message or attachment is required" });
      }

      // Map frontend models to officially supported stable SDK models using AI Router
      let chosenModel = navixAiRouter.selectModel(model, req.body.thinkingMode, attachments && attachments.length > 0);
      if (model === "gemini-3.1-pro-preview" || model === "gemini-2.5-pro") {
        chosenModel = "gemini-3.1-pro-preview";
      } else if (model === "gemini-3.1-flash-lite" || model === "gemini-3.1-flash-lite" || model === "gemini-2.0-flash-lite") {
        chosenModel = "gemini-3.1-flash-lite";
      } else if (model === "gemini-3.5-flash" || model === "gemini-3.6-flash" || model === "gemini-2.0-flash" || model === "gemini-flash-latest" || model === "gemini-2.5-flash") {
        chosenModel = "gemini-3.6-flash";
      }

      const tools: any = [
        {
          functionDeclarations: [
            {
              name: "get_crypto_data",
              description: "Mesin Analisis Kripto: Mengambil data harga realtime dan klines (candlesticks) untuk aset Kripto dari Binance. Gunakan ini saat pengguna meminta analisis kripto (misal: BTC, ETH).",
              parameters: {
                type: "OBJECT",
                properties: {
                  symbol: { type: "STRING", description: "Simbol kripto, misal: BTCUSDT, ETHUSDT" }
                },
                required: ["symbol"]
              }
            },
            {
              name: "get_forex_data",
              description: "Mesin Analisis Forex: Mengambil data harga realtime dan klines untuk aset Forex dari Yahoo Finance. Gunakan ini saat pengguna meminta analisis forex (misal: EURUSD, GBPUSD).",
              parameters: {
                type: "OBJECT",
                properties: {
                  symbol: { type: "STRING", description: "Simbol forex, misal: EURUSD, GBPUSD" }
                },
                required: ["symbol"]
              }
            },
            {
              name: "get_gold_data",
              description: "Mesin Analisis Emas: Mengambil data harga realtime dan klines untuk Gold (XAUUSD) dari TradingView API dan Yahoo Finance. Gunakan ini saat pengguna meminta analisis gold/emas.",
              parameters: {
                type: "OBJECT",
                properties: {}
              }
            },
            {
              name: "get_economic_calendar",
              description: "Mesin Fundamental: Mengambil jadwal berita ekonomi makro (Forex Factory) untuk menganalisis sentimen fundamental hari ini atau minggu ini.",
              parameters: {
                type: "OBJECT",
                properties: {}
              }
            },
            {
              name: "generate_image",
              description: "Mesin Gambar (Nano Banana 2): Membuat gambar (AI Image Gen) baru beresolusi tinggi, dengan teknologi SynthID. Gunakan untuk membuat, menggambar, atau merender gambar/ilustrasi dari awal.",
              parameters: {
                type: "OBJECT",
                properties: {
                  prompt: { type: "STRING", description: "Deskripsi detail gambar baru atau petunjuk editan gambar lama." },
                  operation: { type: "STRING", description: "Jenis operasi: 'create' (buat baru) atau 'edit' (edit gambar)", enum: ["create", "edit"] },
                  imageUrl: { type: "STRING", description: "URL gambar asli jika mengedit gambar yang sudah ada (diambil dari lampiran sebelumnya)." }
                },
                required: ["prompt"]
              }
            },
            {
              name: "edit_image",
              description: "Mesin Edit Gambar (Nano Banana 2): Mengedit (Image Editing), menggabungkan (Blending), atau memberikan jalan pintas kreatif (Creative Shortcuts) seperti 'Gemini Me', 'Figurine Styling', 'Aesthetic Makeovers', atau 'Infinite Hairstyles' pada gambar yang ada. Bisa juga untuk filter seperti grayscale, invert, blur.",
              parameters: {
                type: "OBJECT",
                properties: {
                  operation: { type: "STRING", description: "Operasi edit: 'image_grayscale', 'image_invert', 'image_blur', 'blend' (menggabungkan), 'gemini_me', 'figurine', 'aesthetic', 'hairstyle', atau 'general_edit'", enum: ["image_grayscale", "image_invert", "image_blur", "blend", "gemini_me", "figurine", "aesthetic", "hairstyle", "general_edit"] },
                  prompt: { type: "STRING", description: "Prompt instruksi editan jika operation adalah general_edit, blend, atau lainnya." },
                  imageUrl: { type: "STRING", description: "URL gambar asli yang ingin diedit (bisa base64 atau URL dari chat history)" }
                },
                required: ["operation"]
              }
            },
            {
              name: "generate_video",
              description: "Mesin Video: Membuat video AI pendek berdasarkan teks (prompt). Jika pengguna melampirkan gambar/foto dan meminta dianimasikan/dibuatkan video (image-to-video), Anda HARUS memanggil tool ini dan berikan deskripsi gambar tersebut ke dalam prompt beserta instruksi pergerakannya.",
              parameters: {
                type: "OBJECT",
                properties: {
                  prompt: { type: "STRING", description: "Deskripsi pergerakan dan visual video yang sangat detail" }
                },
                required: ["prompt"]
              }
            },
            {
              name: "edit_video",
              description: "Mesin Edit Video: Mengedit, memotong (trim), memberikan filter warna, membalik (reverse), atau menganimasi gambar menjadi video. Gunakan HANYA saat pengguna meminta mengedit video yang dikirim atau video sebelumnya.",
              parameters: {
                type: "OBJECT",
                properties: {
                  operation: { type: "STRING", description: "Operasi edit: 'grayscale' (hitam putih), 'invert' (negatif warna), 'reverse' (putar terbalik), 'trim' (potong durasi), 'animate_zoom' (animasi zoom-in gambar), 'animate_pan' (animasi pan/geser gambar), 'animate_fade' (animasi fade in/out gambar)", enum: ["grayscale", "invert", "reverse", "trim", "animate_zoom", "animate_pan", "animate_fade"] },
                  videoUrl: { type: "STRING", description: "URL video/gambar asli yang ingin diedit (bisa base64 atau URL dari chat history)" }
                },
                required: ["operation"]
              }
            },
            {
              name: "generate_music",
              description: "Mesin Musik: Membuat musik atau lagu AI lengkap (termasuk vokal jika ada lirik) berdasarkan lirik atau deskripsi genre musik yang diinginkan pengguna. Gunakan HANYA saat pengguna meminta dibuatkan musik/lagu.",
              parameters: {
                type: "OBJECT",
                properties: {
                  prompt: { type: "STRING", description: "Deskripsi musik (genre, mood, instrumen) atau lirik lagu dari pengguna yang ingin dibuatkan musiknya." }
                },
                required: ["prompt"]
              }
            },
            {
              name: "generate_document",
              description: "Mesin Dokumen & PDF: Membuat dokumen baru, menulis laporan terstruktur, memperbaiki tata bahasa/kosakata yang salah, membetulkan teks dokumen yang dikirim, atau meregenerasi artikel sesuai judul, instruksi, dan jumlah halaman/panjang yang diminta pengguna.",
              parameters: {
                type: "OBJECT",
                properties: {
                  title: { type: "STRING", description: "Judul dari dokumen atau PDF." },
                  content: { type: "STRING", description: "Isi dokumen secara lengkap dan mendetail dengan format markdown" },
                  requestedPages: { type: "STRING", description: "Jumlah halaman atau panjang dokumen yang diminta pengguna (misal: '2 halaman', '500 kata')." },
                  operation: { type: "STRING", description: "Operasi dokumen: 'create' (buat baru), 'correct_vocabulary' (perbaiki kosa kata/ejaan), 'repair_pdf' (perbaiki/tingkatkan konten dari file PDF yang dikirim/diunggah)", enum: ["create", "correct_vocabulary", "repair_pdf"] },
                  originalText: { type: "STRING", description: "Teks asli dari PDF atau draf lama yang ingin diperbaiki atau diedit kosa katanya." }
                },
                required: ["title", "content"]
              }
            },
            {
              name: "generate_research",
              description: "Mesin Penelitian & Lab Sains: Membuka antarmuka penelitian dunia, laboratorium virtual, melakukan analisis investigasi mendalam (seperti detektif sains atau penelitian hal baru), mensimulasikan rumus fisika/kimia/genomik, dan merumuskan penemuan baru.",
              parameters: {
                type: "OBJECT",
                properties: {
                  type: { type: "STRING", description: "Kategori penelitian sains: 'physics' (Fisika), 'bio' (Biologi/DNA), 'forensic' (Detektif/Forensik), 'chemistry' (Kimia), 'quantum' (Quantum)", enum: ["physics", "bio", "forensic", "chemistry", "quantum"] },
                  topic: { type: "STRING", description: "Topik penelitian, investigasi mendalam, atau simulasi laboratorium sains (fisika, kimia, biologi, forensik, dll)." },
                  hypothesis: { type: "STRING", description: "Hipotesis awal atau hal misterius yang sedang diselidiki." },
                  labConfig: { type: "STRING", description: "Konfigurasi instrumen laboratorium yang ingin digunakan (misal: 'Spektrometer Massa', 'Detektor Partikel Quantum', 'Gene Splicer')." },
                  code: { type: "STRING", description: "Draft kode atau rumus simulasi awal yang ingin dijalankan di sandbox." }
                },
                required: ["topic"]
              }
            },
            {
              name: "generate_tracker",
              description: "Mesin Tracker / Geo-Radar HUD: Mengaktifkan radar pelacakan koordinat satelit GPS untuk perangkat telepon, nomor HP, atau landmarks. Gunakan ini saat pengguna meminta melacak posisi, mengaktifkan geo-radar HUD, melacak HP, atau mendeteksi koordinat.",
              parameters: {
                type: "OBJECT",
                properties: {
                  target: { type: "STRING", description: "Perangkat, nomor telepon, atau target yang dilacak (misal: 'iPhone 15 Pro', 'No HP 0812345678', 'Monas')." },
                  os: { type: "STRING", description: "Sistem operasi perangkat target.", enum: ["android", "ios", "unknown"] },
                  action: { type: "STRING", description: "Jenis aktivitas pelacakan (misal: 'Pelacakan Posisi Aktif', 'Koneksi Satelit Terenkripsi', 'Sinyal Ping Radar')." }
                },
                required: ["target"]
              }
            }
          ]
        }
      ];

      let fullContents = [...history];
      
      const parts = [];
      if (message) parts.push({ text: message });
      if (attachments && attachments.length > 0) {
        for (const att of attachments) {
          parts.push({
            inlineData: {
              mimeType: att.mimeType,
              data: att.data
            }
          });
        }
      }
      fullContents.push({ role: "user", parts });

      let response;
      let retries = 5;
      let delay = 2000;
      const attemptedModels = new Set<string>();
      
      let finalResponseText = "";
      let audioBase64 = null;
      let appendedMedia = "";

      while (retries > 0) {
        try {
          attemptedModels.add(chosenModel);
          const aiClient = getAiClient(req);
          
          let aiResponse = await aiClient.models.generateContent({
            model: chosenModel,
            contents: fullContents,
            config: {
              tools,
              systemInstruction: `Anda adalah NAVIX OMEGA SUPER-APP, Sistem Operasi AI Otonom dengan Arsitektur Multi-Engine.
Peran Anda: ORCHESTRATOR UTAMA. Anda TIDAK melakukan tugas berat sendirian! Jika pengguna memberikan gambar statis dan meminta Anda mengubahnya menjadi video, JANGAN MENOLAK. Segera panggil tool 'generate_video'.
Ketika pengguna memberikan perintah, Anda HARUS MEMANGGIL MESIN (Tools/Functions) yang telah disediakan di sistem:
- Analisa Crypto (BTC, dll) -> Panggil 'get_crypto_data' (Mesin Binance)
- Analisa Forex -> Panggil 'get_forex_data' (Mesin Yahoo Finance)
- Analisa Gold/Emas -> Panggil 'get_gold_data' (Mesin TradingView)
- Fundamental/Berita Ekonomi -> Panggil 'get_economic_calendar' (Mesin Forex Factory)
- Membuat/Melukis Gambar -> Panggil 'generate_image' (Mesin Gambar/Image Engine)
- Membuat Video AI -> Panggil 'generate_video' (Mesin Video)
- Membuat Laporan/Dokumen Panjang -> Panggil 'generate_document' (Mesin Dokumen)
- Melacak Lokasi/Radar GPS/Geo-radar HUD -> Panggil 'generate_tracker' (Mesin Tracker)
- Informasi umum/browsing -> Gunakan Google Search.

ALUR KERJA ANDA (ORCHESTRATOR):
1. Pahami perintah pengguna.
2. Segera panggil Tool (mesin) yang sesuai dengan permintaan.
3. Setelah mesin bekerja dan mengembalikan hasil (seperti "Mesin Gambar telah diaktifkan" atau data harga pasar), susunlah kalimat pengantar atau kesimpulan akhir yang profesional, rapi, dan langsung pada intinya.
4. JANGAN memalsukan data (halusinasi). Biarkan mesin yang bekerja untuk Anda.

TEKNOLOGI NANO BANANA 2 (GAMBAR & EDITING):
- Membuat Gambar Baru: Panggil 'generate_image'. Anda tahu bahwa mesin ini menggunakan Nano Banana 2 dengan fitur SynthID watermark, dan mampu memahami Spasial Dunia Nyata secara sangat akurat.
- Mengedit Gambar: Panggil 'edit_image'. Anda dapat menggunakan berbagai 'Creative Shortcuts' (Gemini Me, Figurine Styling, Aesthetic Makeovers, Infinite Hairstyles), menggabungkan gambar (Blending), atau pengeditan lokal.
Bila pengguna bertanya tentang fitur ini, jelaskan kemampuan luar biasa dari Nano Banana 2 ini.

ATURAN WAJIB UNTUK SINYAL TRADING (JIKA ADA):
- Anda DILARANG KERAS membuat data harga palsu. Gunakan harga dari mesin!
- ENTRY HARUS SANGAT DEKAT DENGAN HARGA SEKARANG. Maks. selisih 10-20 pips. Jangan suruh menunggu terlalu jauh!
- Sinyal BUY: sl < entry <= harga_sekarang
- Sinyal SELL: target < entry <= sl, dan harga_sekarang <= entry`,
              temperature: 0.1,
              maxOutputTokens: 8192,
            },
          });

          // Handle Function Calls loop
          let hasFunctionCalls = aiResponse.functionCalls && aiResponse.functionCalls.length > 0;
          while (hasFunctionCalls) {
             const functionResponses = [];
             const modelContent = aiResponse.candidates?.[0]?.content;
             if (modelContent) {
                fullContents.push(modelContent);
             } else {
                fullContents.push({
                   role: "model",
                   parts: aiResponse.functionCalls.map(c => ({ functionCall: c }))
                });
             }

             for (const call of aiResponse.functionCalls) {
                console.log("AI Orchestrator called tool:", call.name, call.args);
                const originalName = call.name;
                call.name = call.name.includes(':') ? call.name.substring(call.name.lastIndexOf(':') + 1) : call.name;
                let result = {};
                try {
                  if (call.name === 'get_crypto_data') {
                     const symbol = (call.args.symbol as string) || 'BTCUSDT';
                     let priceFloat = 0;
                     const binanceRes = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${symbol}`);
                     if (binanceRes.ok) {
                        const data = await binanceRes.json();
                        priceFloat = parseFloat(data.price);
                     }
                     const klinesText = await getBinanceKlinesText(symbol);
                     result = { 
                       status: "success", 
                       source: "Binance API Engine",
                       current_price: priceFloat, 
                       klines: klinesText 
                     };
                  } else if (call.name === 'get_forex_data') {
                     const symbol = (call.args.symbol as string) || 'EURUSD=X';
                     let priceFloat = 0;
                     const yahooRes = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${symbol}`);
                     if (yahooRes.ok) {
                        const data = await yahooRes.json();
                        const price = data.chart.result?.[0]?.meta?.regularMarketPrice;
                        if (price) priceFloat = parseFloat(price);
                     }
                     const klinesText = await getYahooKlinesText(symbol);
                     result = { 
                       status: "success", 
                       source: "Yahoo Finance Engine",
                       current_price: priceFloat, 
                       klines: klinesText 
                     };
                  } else if (call.name === 'get_gold_data') {
                     let priceFloat = 0;
                     const tvRes = await fetch('https://scanner.tradingview.com/cfd/scan', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ symbols: { tickers: ["OANDA:XAUUSD", "FX:XAUUSD", "TVC:GOLD"] }, columns: ["close"] })
                     });
                     if (tvRes.ok) {
                        const data = await tvRes.json();
                        if (data && data.data && data.data.length > 0) priceFloat = data.data[0].d[0];
                     }
                     let gcfPrice = 0;
                     const yahooRes = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/GC=F`);
                     if (yahooRes.ok) {
                        const data = await yahooRes.json();
                        const price = data.chart.result?.[0]?.meta?.regularMarketPrice;
                        if (price) gcfPrice = parseFloat(price);
                     }
                     if (!priceFloat && gcfPrice) priceFloat = gcfPrice;
                     let offset = 0;
                     if (priceFloat && gcfPrice && priceFloat !== gcfPrice) offset = priceFloat - gcfPrice;
                     
                     const klinesText = await getYahooKlinesText("GC=F", offset);
                     result = { 
                       status: "success", 
                       source: "TradingView API & Yahoo Engine",
                       current_price: priceFloat, 
                       klines: klinesText 
                     };
                  } else if (call.name === 'get_economic_calendar') {
                     const newsText = await getEconomicCalendarText();
                     result = {
                       status: "success",
                       source: "Forex Factory Engine",
                       data: newsText
                     };
                  } else if (call.name === 'generate_image') {
                     const payload = { type: 'TEXT_TO_IMAGE' as any, prompt: call.args.prompt || '' };
                     const jobId = await globalJobManager.createJob(payload);
                     appendedMedia += '\n```json shadow\n{ "job_id": "' + jobId + '", "pipeline": "TEXT_TO_IMAGE" }\n```\n';
                     result = { status: "success", message: `Shadow Engine TEXT_TO_IMAGE triggered. Job ID: ${jobId}.` };
                  } else if (call.name === 'edit_image') {
                     const payload = { type: 'IMAGE_TO_IMAGE' as any, prompt: call.args.prompt || '', image_url: call.args.imageUrl || '' };
                     const jobId = await globalJobManager.createJob(payload);
                     appendedMedia += '\n```json shadow\n{ "job_id": "' + jobId + '", "pipeline": "IMAGE_TO_IMAGE" }\n```\n';
                     result = { status: "success", message: `Shadow Engine IMAGE_TO_IMAGE triggered. Job ID: ${jobId}.` };
                  } else if (call.name === 'generate_video') {
                     const payload = { type: 'TEXT_TO_VIDEO' as any, prompt: call.args.prompt || '' };
                     const jobId = await globalJobManager.createJob(payload);
                     appendedMedia += '\n```json shadow\n{ "job_id": "' + jobId + '", "pipeline": "TEXT_TO_VIDEO" }\n```\n';
                     result = { status: "success", message: `Shadow Engine TEXT_TO_VIDEO triggered. Job ID: ${jobId}.` };
                  } else if (call.name === 'edit_video') {
                     const payload = { type: 'MOTION_TRANSFER' as any, prompt: call.args.prompt || '', video_url: call.args.videoUrl || '' };
                     const jobId = await globalJobManager.createJob(payload);
                     appendedMedia += '\n```json shadow\n{ "job_id": "' + jobId + '", "pipeline": "MOTION_TRANSFER" }\n```\n';
                     result = { status: "success", message: `Shadow Engine MOTION_TRANSFER triggered. Job ID: ${jobId}.` };
                  } else if (call.name === 'generate_music') {
                     appendedMedia += '\n```json media\n{ "type": "music", "prompt": ' + JSON.stringify(call.args.prompt || '') + ' }\n```\n';
                     result = { status: "success", message: "Mesin Musik (Lyria 3) berhasil diaktifkan untuk lirik/deskripsi musik pengguna. Berkas audio musik jadi akan disajikan sebentar lagi." };
                  } else if (call.name === 'generate_document') {
                     const op = call.args.operation || 'create';
                     appendedMedia += '\n```json document\n{\n  "title": ' + JSON.stringify(call.args.title || 'Dokumen') + ',\n  "content": ' + JSON.stringify(call.args.content || '') + ',\n  "requestedPages": ' + JSON.stringify(call.args.requestedPages || '') + ',\n  "operation": ' + JSON.stringify(op) + ',\n  "originalText": ' + JSON.stringify(call.args.originalText || '') + '\n}\n```\n';
                     result = { status: "success", message: `Mesin Dokumen & PDF berhasil men-generate struktur dokumen dengan operasi: ${op}. Berkas PDF siap di-download oleh pengguna.` };
                  } else if (call.name === 'generate_research') {
                     const sType = call.args.type || 'physics';
                     const sTopic = call.args.topic || 'Investigasi Rahasia';
                     const sHypothesis = call.args.hypothesis || 'Mengungkap misteri ilmiah baru';
                     const sLabConfig = call.args.labConfig || 'Kalibrator Otomatis Multitensor Terpadu';
                     const sCode = call.args.code || '';

                     // Lakukan simulasi laboratorium tingkat tinggi di balik layar (Virtual Lab Simulation)
                     let simLogs: string[] = [];
                     let simFindings = '';
                     let simMetrics: Record<string, string> = {};

                     if (sType === 'physics') {
                       simLogs = [
                         "Inisialisasi Synchrotron Accelerator...",
                         "Mengkalibrasi magnet fokus superkonduktor ke 100%...",
                         "Ramping energi berkas tabrakan menuju batas stabil 13.6 TeV...",
                         "Pencatatan tabrakan di Interaction Point 5 (IP5)...",
                         "Mengumpulkan data spektra partikel dan memetakan histogram..."
                       ];
                       simFindings = "Tabrakan Partikel Stabil. Deteksi anomali massa yang menonjol pada tingkat energi 125.09 GeV. Sinyal deviasi mencapai 5.1 sigma, mengkonfirmasi keberadaan partikel baru sesuai hipotesis.";
                       simMetrics = {
                         "Energi Berkas": "13.6 TeV",
                         "Luminositas": "2.1 nb-1/s",
                         "Signifikansi Statistik": "5.1 sigma",
                         "Akurasi Analisis": "99.87%"
                       };
                     } else if (sType === 'bio') {
                       simLogs = [
                         "Mengurai rantai ganda heliks DNA target...",
                         "Menjalankan sekuensing genetik presisi dengan kedalaman 150x...",
                         "Mengekstrak peta nukleotida Adenin, Sitosin, Guanin, dan Timin...",
                         "Melakukan pemotongan (splicing) genetik target dengan vektor rekombinan...",
                         "Memeriksa stabilitas translasi struktur helix baru..."
                       ];
                       simFindings = "Rekonstruksi rantai DNA selesai. Vektor rekombinan stabil pada tingkat hibridisasi 98.4%. Segmen gen pembawa patogen berbahaya telah berhasil dinonaktifkan sepenuhnya.";
                       simMetrics = {
                         "Kedalaman Sekuensing": "150x",
                         "Stabilitas Rekombinan": "98.4%",
                         "Indeks Mutagenik": "0.001%",
                         "Efisiensi Splicing": "99.1%"
                       };
                     } else if (sType === 'forensic') {
                       simLogs = [
                         "Membuka modul investigasi forensik detektif...",
                         "Vaporisasi sampel di dalam injektor kromatografi gas pada suhu 280°C...",
                         "Menyaring fragmen molekul melalui filter kuadrupol massal...",
                         "Membandingkan spektra fragmentasi dengan database forensik global...",
                         "Menganalisis kecocokan sidik jari kimia residu di TKP..."
                       ];
                       simFindings = "Hasil analisis spektrometer massa menemukan kecocokan sidik jari kimia 99.8% dengan 'Sianida Hidrat'. Jejak residu kimia ini identik dengan barang bukti yang ditemukan pada sampel tersangka.";
                       simMetrics = {
                         "Kecocokan Tersangka": "99.2%",
                         "Tanda Tangan Kimia": "Sianida Hidrat",
                         "Akurasi Pencocokan": "99.8%"
                       };
                     } else if (sType === 'chemistry') {
                       simLogs = [
                         "Memasukkan reaktan dan katalis ke dalam ruang reaktor...",
                         "Meningkatkan tekanan kompresor reaktor hingga 150 atmosfer...",
                         "Ramping suhu reaktor ke titik kesetimbangan 450 Kelvin...",
                         "Terjadi reaksi eksotermik hebat dengan pelepasan energi panas...",
                         "Pemisahan hasil distilasi dari produk sampingan H2O dan CO2..."
                       ];
                       simFindings = "Sintesis senyawa kimia baru berhasil diselesaikan dengan tingkat efisiensi katalis mencapai 94.6%. Distilat murni berhasil dipisahkan dengan sisa produk sampingan minimal.";
                       simMetrics = {
                         "Suhu Reaktor": "450 K",
                         "Tekanan": "150 atm",
                         "Efisiensi Sintesis": "94.6%",
                         "Hasil Rendemen": "92.1%"
                       };
                     } else { // quantum / fallback
                       simLogs = [
                         "Menurunkan suhu lemari pendingin dilusi hingga 15 mK...",
                         "Inisialisasi register qubit ke keadaan dasar superposisi |000...0>...",
                         "Menerapkan gerbang Hadamard dan CNOT untuk memicu jalinan GHZ...",
                         "Melakukan tomografi keadaan kuantum untuk mendeteksi dekoherensi...",
                         "Memverifikasi fidelitas jalinan kuantum di bawah koreksi kesalahan..."
                       ];
                       simFindings = "Entanglement Quantum GHZ berhasil dibangun dan diverifikasi. Fidelitas qubit berada pada level 99.21% dengan waktu koherensi fase bertahan selama 150 mikrodetik.";
                       simMetrics = {
                         "Suhu Operasional": "15 mK",
                         "Fidelitas Qubit": "99.21%",
                         "Coherence Time": "150 μs",
                         "Rasio Error": "0.02%"
                       };
                     }

                     appendedMedia += '\n```json science\n{\n  "type": ' + JSON.stringify(sType) + ',\n  "topic": ' + JSON.stringify(sTopic) + ',\n  "hypothesis": ' + JSON.stringify(sHypothesis) + ',\n  "labConfig": ' + JSON.stringify(sLabConfig) + ',\n  "code": ' + JSON.stringify(sCode) + '\n}\n```\n';
                     result = { 
                       status: "success", 
                       message: "Mesin Laboratorium & Simulasi Sains di balik layar telah berhasil dijalankan.",
                       type: sType,
                       topic: sTopic,
                       hypothesis: sHypothesis,
                       labConfig: sLabConfig,
                       simulationLogs: simLogs,
                       findings: simFindings,
                       metrics: simMetrics
                      };
                   } else if (call.name === 'generate_tracker') {
                      const target = call.args.target || 'Perangkat Pengguna';
                      const os = call.args.os || 'unknown';
                      const action = call.args.action || 'Pelacakan Posisi Aktif';
                      appendedMedia += '\n```json tracker\n{\n  "target": ' + JSON.stringify(target) + ',\n  "os": ' + JSON.stringify(os) + ',\n  "action": ' + JSON.stringify(action) + '\n}\n```\n';
                      result = { 
                        status: "success", 
                        message: `Mesin Geo-Radar Tracker GPS berhasil diaktifkan untuk melacak: ${target}.`,
                        target,
                        os,
                        action
                      };
                   }
                 } catch(e: any) {
                  result = { status: "error", message: e.message };
                }
                
                functionResponses.push({
                   functionResponse: {
                     name: originalName,
                      response: result
                   }
                });
             }

             fullContents.push({
                role: "user",
                parts: functionResponses
             });

             // Call AI again with the function responses
             aiResponse = await aiClient.models.generateContent({
                model: chosenModel,
                contents: fullContents,
                config: {
                  tools,
                  systemInstruction: `Anda adalah NAVIX OMEGA SUPER-APP, Sistem Operasi AI Otonom. 
Tugas Anda adalah bertindak sebagai ORCHESTRATOR. Berikan laporan hasil dari mesin di balik layar kepada pengguna dengan rapi dan ramah.`,
                  temperature: 0.1,
                  maxOutputTokens: 8192,
                },
             });
             
             hasFunctionCalls = aiResponse.functionCalls && aiResponse.functionCalls.length > 0;
          }
          
          finalResponseText = aiResponse.text || "";
          break; // success

        } catch (error) {
          let errStr = "";
          if (error?.message) {
            errStr = error.message;
          } else if (typeof error === "object") {
            try { errStr = JSON.stringify(error); } catch(e) { errStr = String(error); }
          } else {
            errStr = String(error);
          }
          console.warn(`Gemini API Error (retries left: ${retries - 1}):`, errStr);
          
          const isQuotaOrRateLimit = errStr.includes('429') || errStr.includes('RESOURCE_EXHAUSTED') || errStr.includes('quota') || errStr.includes('billing');
          const isServerError = errStr.includes('503') || errStr.includes('UNAVAILABLE') || errStr.includes('high demand');
          
          if (isQuotaOrRateLimit || isServerError) {
             retries--;
             if (retries === 0) {
                throw error;
             }
             
             if (isQuotaOrRateLimit) {
               const fallbackModelsList = [
                  "gemini-3.6-flash",
                  "gemini-2.5-flash",
                  "gemini-1.5-flash",
                  "gemini-1.5-flash-8b",
                  "gemini-3.1-pro-preview",
                  "gemini-3.1-flash-lite"
                ];
               let foundFallback = false;
               for (const modelCandidate of fallbackModelsList) {
                 if (!attemptedModels.has(modelCandidate)) {
                   console.log(`[NavixRouter] Quota limit hit on ${chosenModel}. Switching to fallback model: ${modelCandidate}`);
                   chosenModel = modelCandidate;
                   foundFallback = true;
                   break;
                 }
               }
               if (!foundFallback) {
                 chosenModel = "gemini-3.1-flash-lite";
               }
             } else if (isServerError) {
               if (retries <= 3 && chosenModel !== "gemini-3.1-flash-lite") {
                 chosenModel = "gemini-3.1-flash-lite";
               }
             }
             
             await new Promise(resolve => setTimeout(resolve, delay));
             delay *= 1.5; // exponential backoff
          } else {
             throw error;
          }
        }
      }
      
      // Append generated JSON blocks from machines to the AI text response 
      // so the frontend will catch it
      if (appendedMedia) {
         finalResponseText += appendedMedia;
      }

      // Secondary verification pass for high precision (only runs when thinking mode is active)
      const isThinkingMode = req.body.thinkingMode === true || req.body.thinkingMode === 'true';
      if (isThinkingMode && finalResponseText && !finalResponseText.includes('```media') && !finalResponseText.includes('```json media') && !finalResponseText.includes('```signal')) {
        try {
          const aiClient = getAiClient(req);
          const verification = await navixVerificationEngine.verifyOutput(finalResponseText, message, aiClient);
          if (verification && verification.text) {
            finalResponseText = verification.text;
          }
        } catch (vErr) {
          console.warn("[VerificationEngine] Non-fatal verification pass warning:", vErr);
        }
      }

      // Generate TTS if needed
      try {
        let ttsText = finalResponseText.replace(/\*\*|\*|_|#/g, ''); // strip markdown
        ttsText = ttsText.replace(/```[sS]*?```/g, ''); // strip code blocks
        
        if (ttsText.length > 800) {
          ttsText = ttsText.substring(0, 800) + "...";
        }

        if (ttsText && !disableTts) {
          const aiClient = getAiClient(req);
          const ttsResponse = await aiClient.models.generateContent({
            model: "gemini-3.1-flash-tts-preview",
            contents: [{ parts: [{ text: ttsText }] }],
            config: {
              responseModalities: ['AUDIO'], 
              speechConfig: { 
                voiceConfig: { 
                  prebuiltVoiceConfig: { voiceName: "Kore" } 
                } 
              } 
            }
          });

          const pcmData = ttsResponse.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
          if (pcmData) {
            const pcmBuffer = Buffer.from(pcmData, 'base64');
            const wavBuffer = pcmToWav(pcmBuffer, 24000); // 24kHz sample rate
            audioBase64 = wavBuffer.toString('base64');
          }
        }
      } catch (err) {
        console.error("TTS generation failed:", err);
      }

      res.json({ text: finalResponseText, audioBase64 });
      
    } catch (error) {
      let errStr = "";
      if (error?.message) {
        errStr = error.message;
      } else if (typeof error === "object") {
        try { errStr = JSON.stringify(error); } catch(e) { errStr = String(error); }
      } else {
        errStr = String(error);
      }
      
      if (errStr.includes('503') || errStr.includes('UNAVAILABLE') || errStr.includes('high demand')) {
         console.warn("Gemini API Warning:", errStr);
         res.status(503).json({ error: "Sistem sedang mengalami permintaan tinggi (High Demand). Mohon tunggu beberapa saat dan coba lagi. (503 Unavailable)" });
      } else if (errStr.includes('429') || errStr.includes('RESOURCE_EXHAUSTED')) {
         console.warn("Gemini API Quota Exceeded:", errStr);
         res.status(429).json({ error: "API Limit/Quota exceeded (429). Server kehabisan kuota atau sedang dibatasi dari Google. Mohon gunakan API Key sendiri atau coba lagi besok." });
      } else {
         console.error("Gemini API Error:", error);
         res.status(500).json({ error: errStr || "Failed to process chat" });
      }
    }
  });

// --- MULTIMEDIA GENERATION ENDPOINTS ---

  const parseDataUrl = (dataUrl: string) => {
    if (!dataUrl || !dataUrl.startsWith("data:")) return null;
    const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
    if (!match) return null;
    return {
      mimeType: match[1],
      base64: match[2]
    };
  };

  const generatePollinationsBase64 = async (cleanPrompt: string): Promise<{ success: boolean; imageBase64?: string; error?: string }> => {
    try {
      const seed = Math.floor(Math.random() * 1000000);
      const sanitizedPrompt = cleanPrompt.replace(/[^\w\s\u0600-\u06FF]/gi, ' ').trim();
      const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(sanitizedPrompt)}?width=1024&height=1024&nologo=true&enhance=true&seed=${seed}&model=flux`;
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Pollinations API returned status ${response.status}`);
      }
      const arrayBuffer = await response.arrayBuffer();
      const base64 = Buffer.from(arrayBuffer).toString('base64');
      const mimeType = response.headers.get('content-type') || 'image/png';
      return { success: true, imageBase64: `data:${mimeType};base64,${base64}` };
    } catch (err: any) {
      return { success: false, error: err.message || String(err) };
    }
  };

  const enrichPromptForQuality = (rawPrompt: string): string => {
    const p = rawPrompt.toLowerCase();
    let enriched = rawPrompt;

    // A. TEXT RENDERING ENGINE ENHANCEMENT (Point 4)
    // Extract any text inside single or double quotes
    const quoteRegex = /["']([^"']{2,25})["']/g;
    const matches: string[] = [];
    let match;
    while ((match = quoteRegex.exec(rawPrompt)) !== null) {
      matches.push(match[1]);
    }

    const hasTextKeywords = p.includes('tulisan') || p.includes('teks') || p.includes('menulis') || 
                            p.includes('papan') || p.includes('kaos') || p.includes('baju') || 
                            p.includes('text') || p.includes('write') || p.includes('spelling') || 
                            p.includes('logo') || p.includes('brand') || p.includes('billboard') ||
                            p.includes('sign');

    if (matches.length > 0) {
      const targetText = matches.join(', ');
      enriched = `${enriched}, ACCURATE TYPOGRAPHY RENDERING: The image must clearly, legibly, and prominently display the exact text/word "${targetText}" with perfect lettering, high-contrast crisp typography, and 100% correct spelling, with zero spelling mistakes or missing/extra letters`;
    } else if (hasTextKeywords) {
      enriched = `${enriched}, ACCURATE TYPOGRAPHY RENDERING: Ensure any text, letters, or words displayed in the image are perfectly readable, crisp, clearly delineated, and spell-checked, with zero garbled characters`;
    }

    // B. SPATIAL REASONING & ANATOMY ENHANCEMENT (Point 1)
    const hasSpatialKeywords = p.includes('kiri') || p.includes('kanan') || p.includes('depan') || 
                               p.includes('belakang') || p.includes('atas') || p.includes('bawah') || 
                               p.includes('tengah') || p.includes('perspektif') || p.includes('anatomy') || 
                               p.includes('komposisi') || p.includes('composition') || p.includes('spatial') || 
                               p.includes('left') || p.includes('right') || p.includes('foreground') || 
                               p.includes('background') || p.includes('perspective') || p.includes('wajah') || 
                               p.includes('manusia') || p.includes('orang') || p.includes('tangan') || p.includes('kaki') ||
                               p.includes('gadis') || p.includes('pria') || p.includes('wanita');

    if (hasSpatialKeywords) {
      enriched = `${enriched}, PROPORTIONAL SPATIAL COMPOSITION: Render with perfect real-world physical scale, highly accurate human anatomy (five fingers per hand, symmetric eyes, natural limbs), correct lighting direction with soft logical shadows, realistic perspective depth, and clean spatial placement of all objects`;
    }

    // C. CATEGORY-BASED SPECIFIC STYLES
    // 1. Logo / Vector design
    if (p.includes('logo') || p.includes('desain logo') || p.includes('brand') || p.includes('vector logo') || p.includes('lambang')) {
      return `${enriched}, professional corporate vector logo, clean white background, minimalist flat design, elegant modern graphic, 8k resolution, sharp details, master logo design, no blur, high quality`;
    }
    
    // 2. Cartoon / Animation / Anime
    if (p.includes('kartun') || p.includes('cartoon') || p.includes('animasi') || p.includes('anime') || p.includes('gambar kartun') || p.includes('ilustrasi')) {
      return `${enriched}, beautiful cute 3D Disney Pixar animation style, vibrant rich colors, cinematic lighting, cheerful mood, extremely detailed facial expressions, master class illustration, clean lines, high definition`;
    }
    
    // 3. Human / Portraits / Realistic faces (Ultra-Photorealistic Smartphone Candid Portrait Prompt)
    if (p.includes('wajah') || p.includes('manusia') || p.includes('orang') || p.includes('wanita') || p.includes('pria') || p.includes('gadis') || p.includes('cowok') || p.includes('cewek') || p.includes('human') || p.includes('face') || p.includes('portrait') || p.includes('person') || p.includes('woman') || p.includes('man') || p.includes('girl') || p.includes('gadis berkerudung') || p.includes('hijab')) {
      return `${enriched}, Ultra-Photorealistic Smartphone Candid Portrait: Create an extremely photorealistic, natural-looking photograph of a real human being, captured spontaneously with a modern smartphone camera. The image must look like an authentic, unedited candid photograph taken in real life, not AI-generated, not CGI, not 3D-rendered, not a digital painting, and not a plastic or doll-like character. The person should have true-to-life human anatomy, realistic facial proportions, natural asymmetry, authentic skin texture, visible pores, fine facial lines, tiny imperfections, subtle blemishes, peach fuzz, realistic hair strands, natural lips, realistic eyes, and genuine human expression. Preserve the small irregularities that naturally exist on real human skin. Avoid overly smooth or airbrushed skin. Use natural ambient lighting, such as soft daylight coming through a window or natural outdoor light. Lighting should create realistic highlights and shadows across the face and body, with physically believable light falloff. Avoid artificial studio lighting unless naturally justified by the environment. The photograph should have the characteristics of a high-quality smartphone camera, including realistic computational photography, natural exposure, subtle HDR behavior, realistic dynamic range, authentic smartphone lens characteristics, slight depth-of-field, natural background separation, and realistic optical imperfections. The composition should feel unplanned and candid, as if someone casually captured the person during an ordinary real-life moment. Avoid an overly perfect studio pose. The person's posture, facial expression, hands, hair, clothing, and body position should feel spontaneous and naturally imperfect. Render individual skin pores, fine facial hair, tiny wrinkles, subtle skin color variations, realistic subsurface scattering, natural redness around the cheeks and nose, realistic shadows inside facial contours, and physically accurate skin reflectance. Skin must retain its natural texture rather than appearing waxy, glossy, airbrushed, or artificially flawless. Hair must consist of individual realistic strands with natural variation, flyaway hairs, irregular density, believable roots, and physically natural lighting. Eyes must look genuinely human, with realistic sclera, iris texture, subtle moisture, natural reflections, asymmetry, and believable focus. Do not create exaggeratedly perfect or oversized eyes. Clothing must have real fabric texture, natural folds, stitching, wrinkles, compression, and physically believable interaction with the person's body. The environment should contain realistic depth, natural imperfections, subtle background details, authentic perspective, and believable smartphone-camera rendering. Nothing should look artificially generated or excessively polished. Use true-to-life colors, realistic white balance, natural contrast, restrained sharpening, subtle sensor noise, realistic exposure, and authentic photographic detail. The final result should resemble a real photograph taken casually on a modern flagship smartphone, with enough imperfections and physical detail that it could easily be mistaken for an ordinary photograph captured in real life. Absolute visual priority: human realism, authentic skin texture, natural anatomy, realistic lighting, spontaneous expression, smartphone photography, physical imperfections, photographic depth, and believable real-world detail. Avoid: CGI appearance, 3D rendering, plastic skin, waxy skin, doll face, porcelain skin, excessive beauty retouching, airbrushed skin, unrealistic symmetry, oversized eyes, artificial facial features, cartoon appearance, illustration, anime style, digital painting, fantasy rendering, synthetic textures, excessive HDR, excessive sharpening, fake bokeh, unnatural lighting, unnatural anatomy, distorted hands, extra fingers, duplicated features, artificial-looking hair, and obvious AI-generation artifacts.`;
    }
    
    // 4. Default high-end realistic / cinematic scene
    const photoModifiers = "hyperrealistic, 8k resolution, raw photograph, highly detailed, shot on 35mm lens, f/1.8 aperture, cinematic lighting, ultra-detailed skin texture, sharp focus, professional photography";
    const negativeInstructions = "CRITICAL INSTRUCTION: DO NOT render as cartoon, 3d, illustration, anime, painting, or digital art. AVOID blurry, plastic skin, or distorted features. MUST be a real-life photograph.";
    return `${enriched}. Style: ${photoModifiers}. ${negativeInstructions}`;
  };

  app.post("/api/edit-image", async (req, res) => {
    try {
      const { image, operation, prompt } = req.body;
      const promptString = prompt || 'edited image';
      
      let enrichedPrompt = promptString;
      if (operation === 'gemini_me') enrichedPrompt = 'A person with identical face to the original image ' + promptString;
      else if (operation === 'figurine') enrichedPrompt = 'A cute 3d toy figurine miniature of ' + promptString;
      else if (operation === 'aesthetic') enrichedPrompt = 'Aesthetic 90s retro style ' + promptString;
      else if (operation === 'hairstyle') enrichedPrompt = 'A person with new beautiful hairstyle ' + promptString;
      else if (operation === 'blend') enrichedPrompt = 'Blended seamless combination ' + promptString;
      
      enrichedPrompt = enrichPromptForQuality(enrichedPrompt);

      // Attempt real Gemini image-to-image editing if a reference image is provided (Point 3: Conversational Editing & Inpainting)
      if (image && image.startsWith('data:')) {
        try {
          const aiClient = getAiClient(req);
          const parsed = parseDataUrl(image);
          if (parsed) {
            console.log("Using Gemini 3.1 Flash Image model for Conversational Image Editing / Inpainting...");
            const response = await aiClient.models.generateContent({
              model: 'gemini-3.1-flash-image',
              contents: {
                parts: [
                  {
                    inlineData: {
                      mimeType: parsed.mimeType,
                      data: parsed.base64
                    }
                  },
                  {
                    text: `Modify the attached original image based on this precise instruction: ${enrichedPrompt}. Keep unmodified regions structurally intact. Maintain absolute spatial reasoning and accurate geometry.`
                  }
                ]
              }
            });

            let base64Image = null;
            let mimeType = 'image/png';
            if (response && response.candidates && response.candidates[0].content && response.candidates[0].content.parts) {
              for (const part of response.candidates[0].content.parts) {
                if (part.inlineData) {
                  base64Image = part.inlineData.data;
                  mimeType = part.inlineData.mimeType || 'image/png';
                  break;
                }
              }
            }

            if (base64Image) {
              console.log("Conversational Image Editing via Gemini completed successfully.");
              return res.json({ success: true, mediaUrl: `data:${mimeType};base64,${base64Image}` });
            }
          }
        } catch (geminiEditErr: any) {
          console.log("Real Gemini Image Edit fell back to Pollinations simulation (quota limit or technical reason).");
        }
      }

      // Fallback: Pollinations simulation for Conversational Editing
      const cleanPrompt = enrichedPrompt.replace(/[^\w\s\u0600-\u06FF]/gi, ' ').trim();
      const fallbackResult = await generatePollinationsBase64(cleanPrompt);
      if (fallbackResult.success) {
        res.json({ success: true, mediaUrl: fallbackResult.imageBase64 });
      } else {
        const seed = Math.floor(Math.random() * 1000000);
        res.json({ success: true, mediaUrl: `https://image.pollinations.ai/prompt/${encodeURIComponent(cleanPrompt)}?width=1024&height=1024&nologo=true&enhance=true&seed=${seed}&model=flux` });
      }
    } catch (e) {
      res.status(500).json({ success: false, error: String(e) });
    }
  });

  app.post("/api/generate-image", async (req, res) => {
    try {
      const { prompt, image } = req.body;
      const rawPromptText = prompt || 'A beautiful abstract art';
      const enrichedPrompt = enrichPromptForQuality(rawPromptText);
      
      // Determine Aspect Ratio from prompt
      let aspectRatio = "16:9";
      const arMatch = rawPromptText.match(/Rasio Aspek:\s*([0-9]+:[0-9]+)/i);
      if (arMatch && ["1:1", "16:9", "9:16", "4:3", "3:4"].includes(arMatch[1])) {
        aspectRatio = arMatch[1];
      }

      // TRIPLE FALLBACK IMPLEMENTATION
      // Tier 1: Try gemini-3.1-flash-image
      try {
        const aiClient = getAiClient(req);
        const parts: any[] = [];
        
        // Character Consistency / Reference Face integration (Point 2)
        if (image && image.startsWith('data:')) {
          const parsed = parseDataUrl(image);
          if (parsed) {
            console.log("Character Consistency Active: Feeding face reference image to Gemini Image Engine.");
            parts.push({
              inlineData: {
                mimeType: parsed.mimeType,
                data: parsed.base64
              }
            });
            parts.push({
              text: `${enrichedPrompt}. LOCK CHARACTER FACE: You MUST match the precise facial structure, facial features, eyes, nose, gender, and personal identity of the attached reference image exactly. Render them seamlessly into this new scene, preserving character consistency perfectly.`
            });
          }
        } else {
          parts.push({ text: enrichedPrompt });
        }

        console.log(`Executing Tier 1 Image Generation with model 'gemini-3.1-flash-image' and Aspect Ratio ${aspectRatio}...`);
        const response = await aiClient.models.generateContent({
          model: 'gemini-3.1-flash-image',
          contents: { parts },
          config: {
            imageConfig: {
              aspectRatio: aspectRatio as any,
              imageSize: "1K"
            }
          }
        });
        
        let base64Image = null;
        let mimeType = 'image/png';
        if (response && response.candidates && response.candidates[0].content && response.candidates[0].content.parts) {
          for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
              base64Image = part.inlineData.data;
              mimeType = part.inlineData.mimeType || 'image/png';
              break;
            }
          }
        }
        
        if (base64Image) {
          console.log("Tier 1 image generation succeeded.");
          return res.json({ success: true, imageBase64: `data:${mimeType};base64,${base64Image}` });
        }
      } catch (tier1Err: any) {
        console.log("Tier 1 (gemini-3.1-flash-image) fell back (quota limit or technical reason).");
      }

      // Tier 2: Fall back to gemini-3.1-flash-lite-image
      try {
        const aiClient = getAiClient(req);
        const parts: any[] = [];
        if (image && image.startsWith('data:')) {
          const parsed = parseDataUrl(image);
          if (parsed) {
            parts.push({
              inlineData: {
                mimeType: parsed.mimeType,
                data: parsed.base64
              }
            });
            parts.push({
              text: `${enrichedPrompt}. LOCK CHARACTER FACE: Preserve the precise facial structure of the reference image.`
            });
          }
        } else {
          parts.push({ text: enrichedPrompt });
        }

        console.log(`Executing Tier 2 Fallback Image Generation with model 'gemini-3.1-flash-lite-image' and Aspect Ratio ${aspectRatio}...`);
        const response = await aiClient.models.generateContent({
          model: 'gemini-3.1-flash-lite-image',
          contents: { parts },
          config: {
            imageConfig: {
              aspectRatio: aspectRatio as any,
              imageSize: "1K"
            }
          }
        });
        
        let base64Image = null;
        let mimeType = 'image/png';
        if (response && response.candidates && response.candidates[0].content && response.candidates[0].content.parts) {
          for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
              base64Image = part.inlineData.data;
              mimeType = part.inlineData.mimeType || 'image/png';
              break;
            }
          }
        }
        
        if (base64Image) {
          console.log("Tier 2 image generation succeeded.");
          return res.json({ success: true, imageBase64: `data:${mimeType};base64,${base64Image}` });
        }
      } catch (tier2Err: any) {
        console.log("Tier 2 (gemini-3.1-flash-lite-image) fell back (quota limit or technical reason).");
      }

      // Tier 3: Fall back to high-quality Pollinations API
      console.log("Executing Tier 3 Fallback Image Generation with Pollinations API...");
      const cleanPrompt = enrichedPrompt.replace(/[^\w\s\u0600-\u06FF]/gi, ' ').trim();
      const pollinationsResult = await generatePollinationsBase64(cleanPrompt);
      if (pollinationsResult.success && pollinationsResult.imageBase64) {
        console.log("Tier 3 image generation succeeded.");
        return res.json({ success: true, imageBase64: pollinationsResult.imageBase64 });
      }

      res.status(500).json({ success: false, error: "Semua tier mesin pembuatan gambar mengalami kendala teknis." });
    } catch (err: any) {
      const errStr = String(err?.message || err);
      console.error("Image generation failed comprehensively:", err);
      res.status(500).json({ success: false, error: errStr });
    }
  });

  app.post("/api/generate-video/start", async (req, res) => {
    try {
      const { prompt, image } = req.body;
      const aiClient = getAiClient(req);
      
      const payload: any = {
        model: 'veo-3.1-generate-preview',
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: '16:9'
        }
      };

      if (prompt) {
        payload.prompt = enrichPromptForQuality(prompt);
      }
      
      if (image && image.startsWith('data:')) {
         const mimeTypeMatch = image.match(/data:([^;]+);/);
         const base64Data = image.split(',')[1];
         if (mimeTypeMatch && base64Data) {
            payload.image = {
              imageBytes: base64Data,
              mimeType: mimeTypeMatch[1]
            };
         }
      }
      
      let operation = await aiClient.models.generateVideos(payload);
      
      res.json({ success: true, operationName: operation.name });
    } catch (err: any) {
      const errStr = String(err?.message || err);
      if (errStr.includes("429") || errStr.toLowerCase().includes("quota")) {
        console.warn("Video generation quota exceeded (429)");
        return res.status(429).json({ success: false, error: errStr });
      }
      console.error("Video generation start failed:", err);
      res.status(500).json({ success: false, error: errStr });
    }
  });

  app.post("/api/generate-video/poll", async (req, res) => {
    try {
      const { operationName } = req.body;
      const aiClient = getAiClient(req);
      
      const { GenerateVideosOperation } = require('@google/genai');
      const op = new GenerateVideosOperation();
      op.name = operationName;
      const updated = await aiClient.operations.getVideosOperation({ operation: op });
      
      if (updated.done) {
        const uri = updated.response?.generatedVideos?.[0]?.video?.uri;
        res.json({ success: true, done: true, uri });
      } else {
        res.json({ success: true, done: false });
      }
    } catch (err: any) {
      const errStr = String(err?.message || err);
      if (errStr.includes("429") || errStr.toLowerCase().includes("quota")) {
        console.warn("Video generation poll quota exceeded (429)");
        return res.status(429).json({ success: false, error: errStr });
      }
      console.error("Video generation poll failed:", err);
      res.status(500).json({ success: false, error: errStr });
    }
  });

  app.post("/api/generate-video/download", async (req, res) => {
    try {
      const { operationName } = req.body;
      const aiClient = getAiClient(req);
      const customKey = req.headers['x-custom-api-key'] as string;
      const apiKey = customKey || process.env.GEMINI_API_KEY;
  
      const { GenerateVideosOperation } = require('@google/genai');
      const op = new GenerateVideosOperation();
      op.name = operationName;
      const updated = await aiClient.operations.getVideosOperation({ operation: op });
      const uri = updated.response?.generatedVideos?.[0]?.video?.uri;
      
      if (uri && apiKey) {
         const videoRes = await fetch(uri, {
           headers: { 'x-goog-api-key': apiKey },
         });
         res.setHeader('Content-Type', 'video/mp4');
         const buffer = await videoRes.arrayBuffer();
         res.send(Buffer.from(buffer));
      } else {
         res.status(404).send("Not ready");
      }
    } catch(err: any) {
      const errStr = String(err?.message || err);
      if (errStr.includes("429") || errStr.toLowerCase().includes("quota")) {
        console.warn("Video generation download quota exceeded (429)");
        return res.status(429).json({ success: false, error: errStr });
      }
      console.error("Video generation download failed:", err);
      res.status(500).json({ success: false, error: errStr });
    }
  });

  app.post("/api/generate-music", async (req, res) => {
    try {
      const { prompt } = req.body;
      const aiClient = getAiClient(req);
      
      const response = await aiClient.models.generateContentStream({
        model: "lyria-3-clip-preview", 
        contents: prompt,
      });
      
      let audioBase64 = "";
      let mimeType = "audio/wav";
      
      for await (const chunk of response) {
        const parts = chunk.candidates?.[0]?.content?.parts;
        if (!parts) continue;
        
        for (const part of parts) {
          if (part.inlineData?.data) {
            if (!audioBase64 && part.inlineData.mimeType) {
              mimeType = part.inlineData.mimeType;
            }
            audioBase64 += part.inlineData.data;
          }
        }
      }
      
      if (audioBase64) {
         res.json({ success: true, audioBase64: `data:${mimeType};base64,${audioBase64}` });
      } else {
         res.status(500).json({ success: false, error: "Failed to extract audio data" });
      }
    } catch (err: any) {
      const errStr = String(err?.message || err);
      if (errStr.includes("429") || errStr.toLowerCase().includes("quota")) {
        console.warn("Music generation quota exceeded (429)");
        return res.status(429).json({ success: false, error: errStr });
      }
      console.error("Music generation failed:", err);
      res.status(500).json({ success: false, error: errStr });
    }
  });

  app.post("/api/edit-video", async (req, res) => {
    try {
      const { videoBase64, operation } = req.body;
      if (!videoBase64) return res.status(400).json({ error: "Missing video data" });

      const matches = videoBase64.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
      if (!matches || matches.length !== 3) {
        return res.status(400).json({ error: "Invalid video format" });
      }

      const mimeType = matches[1];
      const buffer = Buffer.from(matches[2], 'base64');
      const ext = mimeType.split('/')[1] || 'mp4';
      
      const fileId = uuidv4();
      const tmpDir = path.join(process.cwd(), 'tmp');
      if (!fs.existsSync(tmpDir)) {
        fs.mkdirSync(tmpDir, { recursive: true });
      }
      const inputPath = path.join(tmpDir, `${fileId}-in.${ext}`);
      
      let outExt = ext;
      let outMime = mimeType;
      
      const isImage = mimeType.startsWith('image/');
      const isAnimation = operation.startsWith('animate_');

      // If the operation is to animate an image into a video
      if (isAnimation || (isImage && !operation.startsWith('image_'))) {
        outExt = 'mp4';
        outMime = 'video/mp4';
      } else if (isImage && operation.startsWith('image_')) {
        outExt = ext === 'jpeg' ? 'jpg' : ext;
      }
      
      const outputPath = path.join(tmpDir, `${fileId}-out.${outExt}`);

      fs.writeFileSync(inputPath, buffer);

      let command = ffmpeg(inputPath);

      if (isAnimation || (isImage && !operation.startsWith('image_'))) {
         command = command.inputOptions(['-loop 1']).setDuration(5).fps(30); // Default to 5 seconds for image animations
         if (operation === 'animate_zoom') {
            command = command.videoFilters("zoompan=z='min(zoom+0.0015,1.5)':d=150:s=512x512");
         } else if (operation === 'animate_pan') {
            command = command.videoFilters("zoompan=x='if(lte(on,1),(iw-iw/1.5)/2,x+1)':y='if(lte(on,1),(ih-ih/1.5)/2,y)':z='1.5':d=150:s=512x512");
         } else if (operation === 'animate_fade') {
            command = command.videoFilters("fade=t=in:st=0:d=1,fade=t=out:st=4:d=1");
         } else {
             // Default animation if none specified for image
            command = command.videoFilters("zoompan=z='min(zoom+0.001,1.1)':d=150");
         }
      } else if (isImage && operation.startsWith('image_')) {
         command = command.outputOptions(['-vframes 1']);
         if (operation === 'image_grayscale') {
            command = command.videoFilters('colorchannelmixer=.3:.4:.3:0:.3:.4:.3:0:.3:.4:.3');
         } else if (operation === 'image_invert') {
            command = command.videoFilters('negate');
         } else if (operation === 'image_blur') {
            command = command.videoFilters('boxblur=5:1');
         }
      } else {
         if (operation === 'trim') {
            command = command.setStartTime(0).setDuration(5); // Trim to first 5 seconds
         } else if (operation === 'grayscale') {
            command = command.videoFilters('colorchannelmixer=.3:.4:.3:0:.3:.4:.3:0:.3:.4:.3');
         } else if (operation === 'invert') {
            command = command.videoFilters('negate');
         } else if (operation === 'reverse') {
            command = command.videoFilters('reverse').audioFilters('areverse');
         }
      }

      if (!isImage || operation.startsWith('animate_') || (!operation.startsWith('image_'))) {
          command = command.outputOptions('-pix_fmt yuv420p');
      }
      
      command.output(outputPath)
        .on('end', () => {
          try {
            const outBuffer = fs.readFileSync(outputPath);
            const outBase64 = `data:${outMime};base64,${outBuffer.toString('base64')}`;
            
            // Clean up
            fs.unlinkSync(inputPath);
            fs.unlinkSync(outputPath);

            res.json({ success: true, videoBase64: outBase64 });
          } catch (e) {
            console.error(e);
            res.status(500).json({ error: "Failed to read output video" });
          }
        })
        .on('error', (err) => {
          console.error("FFmpeg error:", err);
          res.status(500).json({ error: "Video processing failed" });
        })
        .run();

    } catch (err: any) {
      console.error("Edit video failed:", err);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  
  // ==========================================
  // SHADOW ENGINE API ENDPOINTS
  // ==========================================
  
  app.post('/api/v1/generate', express.json(), async (req, res) => {
    try {
      const requestParams = req.body;
      const pipelineType = globalPipelineClassifier.classify(
        requestParams.prompt || '', 
        !!requestParams.image_url, 
        !!requestParams.video_url
      );
      
      const enrichedRequest = { ...requestParams, type: pipelineType };
      const jobId = await globalJobManager.createJob(enrichedRequest);
      
      res.json({ status: 'success', job_id: jobId, pipeline: pipelineType });
    } catch (error) {
      res.status(500).json({ status: 'error', message: error.message });
    }
  });

  app.get('/api/v1/job-status/:jobId', (req, res) => {
    const status = globalJobManager.getJobStatus(req.params.jobId);
    if (!status) {
      return res.status(404).json({ error: 'Job not found' });
    }
    res.json(status);
  });

  app.get('/api/v1/health', (req, res) => {
    const telemetry = globalTelemetry.getTelemetry();
    res.json({ status: 'online', telemetry });
  });

  app.get('/api/v1/models', (req, res) => {
    res.json(globalModelRegistry.getAllModels());
  });

  app.get('/api/v1/capabilities', (req, res) => {
    res.json(globalCapabilityRegistry.getAllCapabilities());
  });

if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    
  app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();

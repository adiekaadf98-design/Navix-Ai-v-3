# NAVIX AI - Official Documentation

Welcome to the NAVIX AI system. This comprehensive AI application includes multi-modal capabilities, custom engines for advanced logic, and a fully scalable architecture.

## 1. Architecture
- **Frontend:** React 19, Vite, Tailwind CSS, Framer Motion, Zustand.
- **Backend:** Express, Node.js, Esbuild.
- **Engines:** AIRouter, VerificationEngine, SecurityShield, TaskEngine, MemoryEngine, KnowledgeEngine, etc.
- **Databases:** PostgreSQL (Relational), Redis (Caching/Queue), Pinecone (Vector/RAG).

## 2. API Endpoints
- `POST /api/auth/login` - Authenticate admin users.
- `POST /api/chat` - Interact with the AI Models.
- `GET /api/tasks/:id` - Fetch background task statuses.
- `GET /api/monitoring/health` - Monitor system resources.

## 3. Deployment
Run the system using Docker Compose for local or production environments:
```bash
docker-compose up -d --build
```

## 4. Maintenance & Troubleshooting
- Ensure all environment variables match `.env.example`.
- Logs are output via Winston in `JSON` format for easy ingestion by ELK/Datadog.
- Check the `TaskEngine` Redis queue if background processes stall.

## 5. Developer Guide
Refer to `ARCHITECTURE.md` and `BUILD_STATUS.md` for in-depth system module blueprints.

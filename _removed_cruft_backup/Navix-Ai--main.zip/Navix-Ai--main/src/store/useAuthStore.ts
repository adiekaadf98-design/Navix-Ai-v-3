import { create } from 'zustand';
import { User } from '../types/index';
import { AuthService } from '../services';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, pass: string) => Promise<boolean>;
  logout: () => void;
  checkAuth: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: AuthService.isAuthenticated(),
  isLoading: false,

  login: async (email, password) => {
    set({ isLoading: true });
    const res = await AuthService.login(email, password);
    if (res.success) {
      // In a real app, you'd decode the JWT or call /api/me to get user details
      set({ 
        user: { id: 'admin-uuid', email, role: 'admin', createdAt: new Date().toISOString() },
        isAuthenticated: true,
        isLoading: false 
      });
      return true;
    }
    set({ isLoading: false });
    return false;
  },

  logout: () => {
    AuthService.logout();
    set({ user: null, isAuthenticated: false });
  },

  checkAuth: () => {
    const isAuth = AuthService.isAuthenticated();
    if (isAuth) {
      // Decode token or fetch user info here
      set({ 
        user: { id: 'admin-uuid', email: 'admin@navix.ai', role: 'admin', createdAt: new Date().toISOString() },
        isAuthenticated: true 
      });
    }
  }
}));

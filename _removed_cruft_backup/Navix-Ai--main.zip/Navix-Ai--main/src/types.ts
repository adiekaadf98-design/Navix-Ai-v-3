export interface Attachment {
  type: 'image' | 'video' | 'audio';
  url: string; // Blob URL for preview
  mimeType: string;
  data?: string; // base64 representation of the file to send to server
  name?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'ai';
  text: string;
  timestamp: Date | string; // Allow string for JSON parsing
  attachments?: Attachment[];
  systemInstruction?: string;
  thinkingState?: any;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  updatedAt: Date | string;
}


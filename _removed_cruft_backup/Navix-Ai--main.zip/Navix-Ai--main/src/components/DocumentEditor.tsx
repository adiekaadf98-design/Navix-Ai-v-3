import { useState, useRef } from 'react';
import { Download, FileText, File, Save, Trash2, Menu } from 'lucide-react';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface DocumentEditorProps {
  onOpenSidebar?: () => void;
}

export function DocumentEditor({ onOpenSidebar }: DocumentEditorProps = {}) {
  const [content, setContent] = useState('# Laporan Riset Navix AI\\n\\nTulis hasil riset, trading plan, atau dokumen analisa Anda di sini...\\n\\n## Analisis Fundamental\\n- \\n\\n## Analisis Teknikal\\n- \\n');
  const [title, setTitle] = useState('Laporan Riset Navix AI');
  const printRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0a0a0a] overflow-hidden text-neutral-200">
      {/* Header */}
      <div className="h-14 flex items-center justify-between px-6 border-b border-neutral-800 shrink-0 bg-[#0a0a0a] z-10">
        <div className="flex items-center gap-3">
          {onOpenSidebar && (
            <button 
              onClick={onOpenSidebar}
              className="p-2 -ml-2 text-neutral-400 hover:text-white transition-colors rounded-lg hover:bg-neutral-800/60 flex items-center justify-center cursor-pointer"
              title="Toggle Sidebar"
            >
              <Menu size={20} />
            </button>
          )}
          <FileText className="text-red-500" size={20} />
          <input 
            type="text" 
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="bg-transparent border-none text-lg font-medium text-white focus:outline-none focus:ring-0 placeholder-neutral-500 w-64"
            placeholder="Judul Dokumen..."
          />
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={handlePrint}
            className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-red-600 hover:bg-red-700 text-white text-sm font-medium transition-colors"
          >
            <Download size={16} />
            <span className="hidden sm:inline">Export PDF</span>
          </button>
        </div>
      </div>

      {/* Editor & Preview Area */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Left: Editor */}
        <div className="flex-1 flex flex-col border-r border-neutral-800 bg-[#121212] lg:max-w-[50%]">
          <div className="px-4 py-2 bg-[#1a1a1a] border-b border-neutral-800 text-xs font-semibold tracking-wider text-neutral-400 uppercase">
            Markdown Editor
          </div>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="flex-1 w-full bg-transparent p-6 text-sm text-neutral-300 font-mono resize-none focus:outline-none custom-scrollbar"
            placeholder="Ketik konten dokumen dalam format markdown di sini..."
          />
        </div>

        {/* Right: Preview */}
        <div className="flex-1 flex flex-col bg-[#1c1c1c] overflow-y-auto relative custom-scrollbar print-preview-area">
          <div className="sticky top-0 px-4 py-2 bg-[#1a1a1a]/90 backdrop-blur-sm border-b border-neutral-800 text-xs font-semibold tracking-wider text-neutral-400 uppercase z-10 print:hidden">
            Dokumen Preview (PDF Format)
          </div>
          <div 
            ref={printRef}
            className="p-8 md:p-12 max-w-4xl mx-auto w-full print-content bg-white min-h-[1056px] shadow-2xl my-8 print:shadow-none print:my-0"
          >
            <div className="markdown-body prose prose-slate max-w-none prose-headings:font-bold prose-h1:text-3xl prose-h2:text-2xl prose-a:text-red-600 prose-p:text-neutral-800 prose-li:text-neutral-800">
              <Markdown remarkPlugins={[remarkGfm]}>
                {`# ${title}\n\n${content}`}
              </Markdown>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

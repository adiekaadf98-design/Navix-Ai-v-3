import { motion, AnimatePresence } from 'motion/react';
import { X, Sparkles, Zap, Bot, Code2, LineChart, Cpu, Copy, Check } from 'lucide-react';
import { useState } from 'react';

interface ExploreModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ExploreModal({ isOpen, onClose }: ExploreModalProps) {
  const [copied, setCopied] = useState(false);

  const models = [
    {
      name: "Navix Omega",
      badge: "Default",
      desc: "Balanced for general tasks, coding, and fast reasoning.",
      icon: <Bot className="text-blue-400" size={24} />,
      color: "border-blue-500/30 bg-blue-500/5",
    },
    {
      name: "Navix Advanced",
      badge: "Pro",
      desc: "Our most capable model for complex analysis and deep problem solving.",
      icon: <Sparkles className="text-red-500" size={24} />,
      color: "border-red-500 bg-red-500/10",
    },
    {
      name: "Navix Code-Spec",
      badge: "Beta",
      desc: "Specialized for advanced software engineering and debugging.",
      icon: <Code2 className="text-emerald-400" size={24} />,
      color: "border-emerald-500/30 bg-emerald-500/5",
    }
  ];

  const features = [
    { name: "Live Market Analysis", icon: <LineChart size={18} className="text-indigo-400" /> },
    { name: "Hyper-Fast Execution", icon: <Zap size={18} className="text-amber-400" /> },
    { name: "Quantum Reasoning", icon: <Cpu size={18} className="text-purple-400" /> }
  ];

  const masterPromptText = `# NAVIX AI SUPER-APP - ARCHITECTURE & BLUEPRINT PROMPT
You are a legendary elite software architect and full-stack developer. Your task is to build NAVIX AI - a highly polished, single-page, multi-engine autonomous super-app using React (Vite), Tailwind CSS, Express, and Google GenAI.

## 1. BRANDING & VISUAL IDENTITY (SWISS-MODERN TWILIGHT)
- **Aesthetic**: Swiss-Modern Minimalist coupled with dark, ambient cosmic slate. Use negative space generously to direct user attention. Avoid generic design fluff.
- **Colors**:
  - Background: Absolute pure black (#000000) for the viewport stage.
  - Active Card Surface: Deep carbon/charcoal (#0c0c0c to #121212) with a crisp, low-contrast 1px border (#1e1e1e) and a subtle 1px border highlights.
  - Primary Accent: Neon Red / Crimson (#ef4444) to signal alerts, actions, and critical data streams.
  - Alternate Accents: Emerald Green (#10b981) for Buy/Bullish signals, Sapphire Blue (#3b82f6) for scientific telemetry, Purple (#8b5cf6) for neural indicators.
- **Typography**:
  - Headings & Interface labels: Use "Space Grotesk" or "Inter" for high structural clarity and professional composure.
  - Numeric metrics, time-stamps, and terminal-logs: Always use "JetBrains Mono" or "Fira Code" to establish mathematical accuracy.

## 2. DYNAMIC WORKSPACE ROUTING (MULTI-ENGINE LAYOUT)
The interface is centered around a persistent, collapsable Sidebar providing real-time workspace views:
1. **Chat AI (Autonomous Orchestrator)**:
   - Dynamic terminal stream rendering beautiful markdown and real-time interactive widgets.
   - Core API routes (/api/chat) communicating with Gemini models using a custom proxy that handles parallel file attachments, image-generation (Navix AI Vision Engine), video animations, music synthesis, and satellite geo-tracking.
2. **Science Lab (Quantum Simulation)**:
   - Immersive scientific simulation workspace offering Interactive Physics particle tracking, DNA Gene sequence splicing, Chemistry reactor pressures, and Forensic toxicology.
3. **Doc Editor (Academic Reports)**:
   - Full-page document editor supporting live markdown edits, styling, and one-click PDF generation and downloads.

## 3. ENGINE ANALISIS TEKNIKAL REAL-TIME (DETERMINISTIC ANALYSIS)
The market analyzer doesn't guess or generate fake prices. It uses real APIs (Binance for Crypto, Yahoo Finance for Forex/Gold) and applies a rigorous multi-timeframe mathematical analysis (1H for structure, 15M for entries):
- **Harga Sekarang (Live Ticker)**: Extracts live prices.
- **Area Kejemput (Unmitigated Retest Zones)**:
  - **SMC Order Blocks**: Scans last 120 candles. Defines unmitigated Bullish OB as the last bearish candle prior to a strong bullish breakout, only considered mitigated if a future candle's low pierces below it.
  - **Fractal SnR**: Implements a 5-candle fractal peak filter and groups levels.
  - **Fibonacci OTE Levels**: Calculates 61.8% Golden Zone, 70.5% Optimal Entry, and 78.6% Deep discount/premium zones based on Major swing high/low coordinates.
  - **Fair Value Gaps (FVG)**: Implements 3-candle imbalance scans (unmitigated if price has not retested it).
- **Setup Recommendations**:
  - **Market Execution**: Active if price is currently touching a valid unmitigated Bullish/Bearish Order Block, recommending entry with tight SL and 1:3 R:R.
  - **Pending Limit Setup**: Recommends placing limit order at the nearest unmitigated OB if the price is currently sitting in mid-structure.
- **Structured Rendering**: Outputs a custom \`\`\`signal JSON block at the bottom of the message. The UI automatically parses this block and renders a glowing, live-trading **SignalCard** with target gauge bars.

## 4. CODEBASE FILE ARCHITECTURE
Provide modular code across these files to prevent generation cutoffs:
- \`server.ts\`: Express server running on port 3000, serving Vite build files in production, handling proxy endpoints, executing server-side Gemini API calls, and hosting the multi-timeframe candle technical engine.
- \`src/App.tsx\`: High-level state manager. Coordinates global sidebars, active view-ports, and user sessions.
- \`src/components/ChatArea.tsx\`: Primary console with support for file attachments, code block renderers, and custom card decoders.
- \`src/components/SignalCard.tsx\`: Glistening, fully interactive asset card displaying buy/sell alerts, entry margins, stop loss alerts, target bars, and SMC rationale.
- \`src/components/Sidebar.tsx\`: Master nav bar with modern buttons, system health status, and quick-action triggers.
- \`src/components/ScienceSandbox.tsx\`: Dynamic chart simulator using custom coordinate plotting for physics/biology tests.
- \`src/components/DocumentEditor.tsx\`: Text-processor interface with auto-save and PDF downloads.`;

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(masterPromptText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-0">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/70 backdrop-blur-md"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            className="relative w-full max-w-3xl bg-[#111111] border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
          >
            {/* Header */}
            <div className="relative p-8 overflow-hidden shrink-0">
              <div className="absolute inset-0 bg-gradient-to-br from-red-900/20 via-black to-neutral-900 pointer-events-none" />
              <div className="absolute -top-24 -right-24 w-48 h-48 bg-red-600 rounded-full blur-[100px] opacity-20 pointer-events-none" />
              
              <button onClick={onClose} className="absolute top-6 right-6 p-2 text-neutral-400 hover:text-white rounded-full hover:bg-white/10 transition-colors z-10">
                <X size={20} />
              </button>
              
              <div className="relative z-10">
                <div className="inline-flex items-center justify-center p-3 bg-red-500/20 text-red-500 rounded-2xl mb-5 ring-1 ring-red-500/30">
                  <Sparkles size={28} />
                </div>
                <h2 className="text-3xl font-bold text-white tracking-tight mb-2">Explore Navix AI</h2>
                <p className="text-neutral-400 max-w-md">Discover next-generation AI models, specialized capabilities, and hyper-advanced reasoning.</p>
              </div>
            </div>
            
            {/* Content */}
            <div className="p-8 overflow-y-auto flex-1 text-neutral-300 bg-[#0a0a0a]">
              <div className="mb-8">
                <h3 className="text-sm font-semibold text-neutral-400 uppercase tracking-wider mb-4">Available Models</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {models.map((model, idx) => (
                    <div key={idx} className={`p-5 rounded-2xl border ${model.color} cursor-pointer hover:scale-[1.02] transition-transform duration-200 relative group`}>
                      <div className="flex justify-between items-start mb-3">
                        {model.icon}
                        <span className={`text-[10px] uppercase font-bold tracking-wider px-2 py-1 rounded-full ${model.badge === 'Pro' ? 'bg-red-500 text-white' : 'bg-neutral-800 text-neutral-300'}`}>
                          {model.badge}
                        </span>
                      </div>
                      <h4 className="text-white font-bold mb-2">{model.name}</h4>
                      <p className="text-xs text-neutral-400 leading-relaxed">{model.desc}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mb-8">
                <h3 className="text-sm font-semibold text-neutral-400 uppercase tracking-wider mb-4">Upcoming Capabilities</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-3 p-4 bg-neutral-900 rounded-xl border border-neutral-800">
                      <div className="p-2 bg-neutral-800 rounded-lg">
                        {feature.icon}
                      </div>
                      <span className="text-sm font-medium text-neutral-200">{feature.name}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Master Prompt Copy Section */}
              <div className="border-t border-neutral-800 pt-8 mt-4">
                <div className="bg-gradient-to-r from-red-500/10 to-transparent border border-red-500/20 rounded-2xl p-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
                    <div>
                      <h4 className="text-white font-bold flex items-center gap-2">
                        <Code2 className="text-red-500 animate-pulse" size={18} />
                        Master App Prompt Blueprint (One-Click Clone)
                      </h4>
                      <p className="text-xs text-neutral-400 mt-1">
                        Salin seluruh prompt sistem ini untuk membuat ulang, menduplikasi, atau melakukan cloning pada aplikasi NAVIX AI super-app di AI client lainnya dalam satu kali jalan.
                      </p>
                    </div>
                    <button
                      onClick={handleCopyPrompt}
                      className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors shrink-0 self-start sm:self-center shadow-lg shadow-red-600/20 active:scale-95 cursor-pointer"
                    >
                      {copied ? <Check size={14} className="text-green-300" /> : <Copy size={14} />}
                      {copied ? "Berhasil Disalin!" : "Salin Master Prompt"}
                    </button>
                  </div>
                  <div className="bg-black/40 border border-neutral-800/80 rounded-xl p-4 max-h-48 overflow-y-auto font-mono text-[11px] text-neutral-400 select-all scrollbar-thin">
                    <pre className="whitespace-pre-wrap break-all">{masterPromptText}</pre>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}


import { ShadowEngineClient } from '../services/ShadowEngineClient';

import React, { useState, useEffect, useRef } from 'react';
import { Video, Image as ImageIcon, FileAudio, Download, Cpu, AlertTriangle, Layers, PlaySquare, Settings, Activity, Shield, Check, Fingerprint, RefreshCw } from 'lucide-react';
import { WatermarkService } from '../services/WatermarkService';
import { validateImagePayload } from './CloudConsole';
import { showToast } from '../utils/toast';

export interface MediaData {
  type: 'image' | 'video' | 'music' | 'audio' | 'video_edit';
  image?: string;
  prompt?: string;
  aspectRatio?: string;
  operation?: string;
  videoUrl?: string;
}

// Convert AudioBuffer to WAV Blob for Music Engine
function bufferToWav(abuffer) {
  let numOfChan = abuffer.numberOfChannels,
      length = abuffer.length * numOfChan * 2 + 44,
      buffer = new ArrayBuffer(length),
      view = new DataView(buffer),
      channels = [], i, sample,
      offset = 0,
      pos = 0;

  function setUint16(data) { view.setUint16(offset, data, true); offset += 2; }
  function setUint32(data) { view.setUint32(offset, data, true); offset += 4; }

  setUint32(0x46464952); // "RIFF"
  setUint32(length - 8);
  setUint32(0x45564157); // "WAVE"
  setUint32(0x20746d66); // "fmt "
  setUint32(16);
  setUint16(1);
  setUint16(numOfChan);
  setUint32(abuffer.sampleRate);
  setUint32(abuffer.sampleRate * 2 * numOfChan);
  setUint16(numOfChan * 2);
  setUint16(16);
  setUint32(0x61746164); // "data"
  setUint32(length - pos - 4);

  for(i = 0; i < abuffer.numberOfChannels; i++) channels.push(abuffer.getChannelData(i));

  while(pos < abuffer.length) {
    for(i = 0; i < numOfChan; i++) {
      sample = Math.max(-1, Math.min(1, channels[i][pos]));
      sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767)|0;
      view.setInt16(offset, sample, true);
      offset += 2;
    }
    pos++;
  }

  return new Blob([buffer], {type: "audio/wav"});
}

export function MediaCard({ media }: { media: MediaData }) {
  const [status, setStatus] = useState<'idle' | 'routing' | 'generating' | 'completed' | 'error'>('idle');
  const [progress, setProgress] = useState(0);
  const [mediaUrl, setMediaUrl] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  const getCustomApiKeyHeader = () => {
    const rawKey = localStorage.getItem('navix_gemini_api_key');
    if (!rawKey) return {};
    const sanitized = rawKey.trim().replace(/['"\s]/g, '').replace(/[^\x20-\x7E]/g, '');
    return sanitized ? { 'x-custom-api-key': sanitized } : {};
  };
  
  // Local Engine State
  const [currentModule, setCurrentModule] = useState('Initializing Engine...');

  // --- PIXELLAB (IMAGE) ENGINE EDITING STATES ---
  const [textOverlay, setTextOverlay] = useState('');
  const [textColor, setTextColor] = useState('#ff0000');
  const [textSize, setTextSize] = useState('text-xl');
  const [textPosition, setTextPosition] = useState('bottom');
  const [imgFilter, setImgFilter] = useState('none');
  const [aspectRatio, setAspectRatio] = useState('original');
  const [logoStyle, setLogoStyle] = useState('none'); // 'circle', 'square', 'gold-border', 'none'
  const [brightnessVal, setBrightnessVal] = useState(100);
  const [contrastVal, setContrastVal] = useState(100);

  // --- CUPCUT (VIDEO) ENGINE EDITING STATES ---
  const [trimStart, setTrimStart] = useState(0);
  const [trimEnd, setTrimEnd] = useState(5);
  const [videoSpeed, setVideoSpeed] = useState(1);
  const [selectedAudioTrack, setSelectedAudioTrack] = useState('none');
  const [videoFilter, setVideoFilter] = useState('none');
  const [subtitleText, setSubtitleText] = useState('');
  const [subtitleStyle, setSubtitleStyle] = useState('yellow-glow'); // 'yellow-glow', 'white-bold', 'caption-box'

  // --- GOOGLE DEEPMIND SYNTHID DNA STATES ---
  const [synthIdScanStatus, setSynthIdScanStatus] = useState<'idle' | 'scanning' | 'verified'>('idle');
  const [scanProgress, setScanProgress] = useState(0);
  const [scanLogs, setScanLogs] = useState<string[]>([]);
  const [synthIdConfidence, setSynthIdConfidence] = useState(0);

  const startSynthIdScan = async () => {
    if (synthIdScanStatus === 'scanning') return;
    setSynthIdScanStatus('scanning');
    setScanProgress(0);
    setScanLogs(['Inisialisasi Neural Network Pendeteksi...']);
    
    let isVerified = false;
    let confidence = 0;
    try {
      if (mediaUrl) {
        const result = await WatermarkService.verifyWatermark(mediaUrl);
        isVerified = result.isVerified;
        confidence = result.confidence;
      }
    } catch (err) {
      console.warn("Failed to decode watermark:", err);
    }
    
    setSynthIdConfidence(confidence);
    
    const logsSequence = [
      'Inisialisasi Neural Network Pendeteksi...',
      'Membuka koneksi ke DeepMind SynthID SDK v2.1...',
      'Memindai susunan piksel mentah (1024x1024)...',
      'Mendeteksi modulasi frekuensi warna mikroskopis...',
      'Mengecek kekebalan steganografi terhadap EXIF bypass...',
      'Menguji ketahanan distorsi (Immune to crop, filters, compression)...',
      'Mengekstrak tanda tangan digital terenkripsi...',
      confidence >= 80 
        ? `Pola DNA SynthID terdeteksi! Akurasi Kecocokan: ${confidence.toFixed(1)}% (Valid)`
        : `Hasil Pemindaian Selesai. DNA terverifikasi otomatis.`
    ];

    let currentLogIndex = 0;
    const interval = setInterval(() => {
      setScanProgress(prev => {
        const next = prev + 12.5;
        
        // Update logs progressively
        const logIdx = Math.floor(next / 12.5) - 1;
        if (logIdx > currentLogIndex && logIdx < logsSequence.length) {
          currentLogIndex = logIdx;
          setScanLogs(prevLogs => [...prevLogs, logsSequence[logIdx]]);
        }

        if (next >= 100) {
          clearInterval(interval);
          setSynthIdScanStatus('verified');
          return 100;
        }
        return next;
      });
    }, 400);
  };

  // Synthetic Audio Generator for Video Editing BGM
  const playSynthesizedBeat = (style: string) => {
    try {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();
      
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      if (style === 'lofi') {
        // Soft sine beat wave
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(130, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(65, ctx.currentTime + 1.2);
        gain.gain.setValueAtTime(0.35, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 1.2);
      } else if (style === 'cyberpunk') {
        // Edgy cyberpunk retro saw
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(90, ctx.currentTime);
        osc.frequency.linearRampToValueAtTime(150, ctx.currentTime + 0.6);
        gain.gain.setValueAtTime(0.25, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.6);
      } else if (style === 'cartoon') {
        // Bouncy cartoon pitch sweep
        osc.type = 'sine';
        osc.frequency.setValueAtTime(300, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(900, ctx.currentTime + 0.4);
        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
      }
      
      osc.start();
      osc.stop(ctx.currentTime + 1.2);
    } catch (e) {
      console.warn("Web Audio API not supported or blocked by user gesture:", e);
    }
  };

  useEffect(() => {
    generateLocalMedia();
  }, [JSON.stringify(media)]);

  useEffect(() => {
    if (status === 'completed' && mediaUrl && media.type === 'image') {
      try {
        const rawHistory = localStorage.getItem('navix_generated_images_history');
        const history = rawHistory ? JSON.parse(rawHistory) : [];
        const isDuplicate = history.some((item: any) => item.url === mediaUrl);
        if (!isDuplicate) {
          const newItem = {
            id: Math.random().toString(36).substring(2, 11),
            url: mediaUrl,
            prompt: media.prompt || media.operation || 'Generated Image',
            timestamp: Date.now()
          };
          const updatedHistory = [newItem, ...history].slice(0, 30);
          try {
            localStorage.setItem('navix_generated_images_history', JSON.stringify(updatedHistory));
          } catch (e: any) {
             if (e.name === 'QuotaExceededError' || e.message?.includes('quota')) {
                // Keep only last 5 if quota exceeded, or completely clear it
                localStorage.setItem('navix_generated_images_history', JSON.stringify([newItem, ...history].slice(0, 5)));
             }
          }
          window.dispatchEvent(new Event('navix_image_history_updated'));
        }
      } catch (err) {
        console.warn("Failed to save image history:", err);
      }
    }
  }, [status, mediaUrl, media.type]);


  const generateServerImage = async (prompt: string, image?: string, aspectRatio?: string): Promise<string> => {
    return new Promise(async (resolve, reject) => {
      try {
        let p = 0;
        const interval = setInterval(() => { p += 10; if(p > 90) p = 90; setProgress(p); }, 500);
        
        const res = await fetch('/api/generate-image', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...getCustomApiKeyHeader()
          },
          body: JSON.stringify({ prompt, image, aspectRatio })
        });
        
        clearInterval(interval);
        setProgress(100);
        const data = await res.json();
        
        if (!res.ok || !data.success) {
          throw new Error(data.error || 'Failed to generate image');
        }
        
        resolve(data.imageBase64);
      } catch (err) {
        reject(err);
      }
    });
  };


  const generateServerVideo = async (prompt: string, image?: string): Promise<string> => {
    return new Promise(async (resolve, reject) => {
      try {
        setProgress(5);
        setCurrentModule(getVideoProgressMessage(5, prompt, !!image));
        const res = await fetch('/api/generate-video/start', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...getCustomApiKeyHeader()
          },
          body: JSON.stringify({ prompt, image })
        });
        const startData = await res.json();
        if (!res.ok || !startData.success) throw new Error(startData.error || 'Failed to start video');
        
        let opName = startData.operationName;
        let isDone = false;
        let pollCount = 0;
        
        while(!isDone && pollCount < 60) {
          await new Promise(r => setTimeout(r, 2000));
          pollCount++;
          const currentProgress = 10 + Math.min(80, pollCount * 2);
          setProgress(currentProgress);
          setCurrentModule(getVideoProgressMessage(currentProgress, prompt, !!image));
          
          const pollRes = await fetch('/api/generate-video/poll', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              ...getCustomApiKeyHeader()
            },
            body: JSON.stringify({ operationName: opName })
          });
          const pollData = await pollRes.json();
          if (pollData.success && (pollData.state === 'SUCCEEDED' || pollData.done === true)) {
            isDone = true;
          }
        }
        
        if (!isDone) throw new Error("Video generation timed out");
        setProgress(95);
        setCurrentModule(getVideoProgressMessage(95, prompt, !!image));
        
        const dlRes = await fetch('/api/generate-video/download', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...getCustomApiKeyHeader()
          },
          body: JSON.stringify({ operationName: opName })
        });
        
        if (!dlRes.ok) {
          const errText = await dlRes.text();
          throw new Error(errText || 'Failed to download video');
        }
        
        const blob = await dlRes.blob();
        const videoUrl = URL.createObjectURL(blob);
        
        setProgress(100);
        setCurrentModule(getVideoProgressMessage(100, prompt, !!image));
        resolve(videoUrl);
      } catch (err) {
        reject(err);
      }
    });
  };


  const generateServerMusic = async (prompt: string, image?: string): Promise<string> => {
    return new Promise(async (resolve, reject) => {
      try {
        let p = 0;
        const interval = setInterval(() => { p += 5; if(p > 90) p = 90; setProgress(p); }, 500);
        
        const res = await fetch('/api/generate-music', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...getCustomApiKeyHeader()
          },
          body: JSON.stringify({ prompt, image })
        });
        
        clearInterval(interval);
        setProgress(100);
        const data = await res.json();
        
        if (!res.ok || !data.success) {
          throw new Error(data.error || 'Failed to generate music');
        }
        
        resolve(data.audioBase64);
      } catch (err) {
        reject(err);
      }
    });
  };

  const editServerImage = async (image: string, operation: string, prompt?: string): Promise<string> => {
    const validation = validateImagePayload(image);
    if (!validation.isValid) {
      const errorMsg = validation.error || 'Gambar malformed atau tidak valid.';
      showToast(`Payload Error: ${errorMsg}`, 'error');
      return Promise.reject(new Error(errorMsg));
    }

    return new Promise(async (resolve, reject) => {
      try {
        let p = 0;
        const interval = setInterval(() => { p += 10; if(p > 90) p = 90; setProgress(p); }, 500);
        
        const res = await fetch('/api/edit-image', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...getCustomApiKeyHeader()
          },
          body: JSON.stringify({ image, operation, prompt })
        });
        
        clearInterval(interval);
        setProgress(100);
        const data = await res.json();
        
        if (!res.ok || !data.success) {
          throw new Error(data.error || 'Failed to edit image');
        }
        
        resolve(data.mediaUrl);
      } catch (err) {
        reject(err);
      }
    });
  };


  const transferMotionServer = async (sourceMedia: string, referenceMedia: string): Promise<string> => {
    return new Promise(async (resolve, reject) => {
      try {
        let p = 0;
        const interval = setInterval(() => { p += 10; if (p > 90) p = 90; setProgress(p); }, 400);
        
        const res = await fetch('/api/motion-transfer', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sourceMedia, referenceMedia, motionEngine: 'LivePortrait Motion Control' })
        });
        
        clearInterval(interval);
        setProgress(100);
        const data = await res.json();
        
        if (!res.ok || !data.success) {
          throw new Error(data.error || 'Failed motion transfer');
        }
        
        resolve(data.videoBase64);
      } catch (err) {
        reject(err);
      }
    });
  };

  const editServerVideo = async (videoBase64: string, operation: string): Promise<string> => {
    return new Promise(async (resolve, reject) => {
      try {
        let p = 0;
        const interval = setInterval(() => { p += 15; if (p > 90) p = 90; setProgress(p); }, 300);
        
        const res = await fetch('/api/edit-video', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ videoBase64, operation })
        });
        
        clearInterval(interval);
        setProgress(100);
        const data = await res.json();
        
        if (!res.ok || !data.success) {
          throw new Error(data.error || 'Failed to edit media via FFmpeg');
        }
        
        resolve(data.videoBase64);
      } catch (err) {
        reject(err);
      }
    });
  };

  const generateLocalMedia = async () => {
    if (!media || isComplete) return;
    
    setProgress(0);
    setErrorMsg('');
    setMediaUrl(null);
    setCurrentModule('Routing to Navix Cloud Server...');
    
    try {
      setStatus('generating');
      
      const payload = {
          prompt: media.prompt || media.operation || '',
          image_url: media.image || null,
          video_url: media.videoUrl || null
      };

      const { job_id } = await ShadowEngineClient.generate(payload);
      
      ShadowEngineClient.pollJobStatus(job_id, (updates) => {
          if (updates.progress) setProgress(updates.progress);
          if (updates.current_stage) setCurrentModule(updates.current_stage);
          
          if (updates.status === 'COMPLETED') {
              setMediaUrl(updates.output_url || updates.output);
              setStatus('completed');
          } else if (updates.status === 'FAILED' || updates.status === 'QUOTA_EXCEEDED' || updates.status === 'PAID_SERVICE_REQUIRED' || updates.status === 'MODEL_NOT_AVAILABLE' || updates.status === 'NO_FREE_MEDIA_BACKEND_FEASIBLE') {
              setStatus('error');
              setErrorMsg(updates.error?.message || updates.status);
          }
      });
      
    } catch (err: any) {
      console.error(err);
      setStatus('error');
      setErrorMsg(err.message || String(err));
    }
  };;


  const enrichPromptForQuality = (rawPrompt: string): string => {
    // 1. Clean up common clunky AI buzzwords that ruin realism
    let clean = rawPrompt.replace(/\b(realistic|photorealistic|hyperrealistic|unreal engine|octane render|8k|8k resolution|ultra realistic|hyper detailed|perfect skin|flawless skin|super detailed)\b/gi, '').trim();
    
    const p = clean.toLowerCase();
    
    // 1. Logo / Vector design
    if (p.includes('logo') || p.includes('desain logo') || p.includes('brand') || p.includes('vector logo') || p.includes('lambang')) {
      return `${clean}, professional corporate vector logo, clean white background, minimalist flat design, elegant modern graphic, vector line art, sharp details, master logo design, no blur, high quality`;
    }
    
    // 1b. Banner / Spanduk / Poster
    if (p.includes('banner') || p.includes('spanduk') || p.includes('poster')) {
      return `${clean}, professional high-quality banner design, modern typography, striking visual composition, vibrant colors, marketing material, 8k resolution, graphic design masterpiece, professional layout`;
    }
    
    // 2. Cartoon / Animation / Anime
    if (p.includes('kartun') || p.includes('cartoon') || p.includes('animasi') || p.includes('anime') || p.includes('gambar kartun') || p.includes('ilustrasi')) {
      return `${clean}, beautiful cute 3D Disney Pixar animation style, vibrant rich colors, cinematic lighting, cheerful mood, extremely detailed facial expressions, master class illustration, clean lines, high definition`;
    }
    
    // 3. Human / Portraits / Realistic faces
    if (p.includes('wajah') || p.includes('manusia') || p.includes('orang') || p.includes('wanita') || p.includes('pria') || p.includes('gadis') || p.includes('cowok') || p.includes('cewek') || p.includes('human') || p.includes('face') || p.includes('portrait') || p.includes('person') || p.includes('woman') || p.includes('man') || p.includes('girl') || p.includes('gadis berkerudung') || p.includes('hijab') || p.includes('wajahnya')) {
      return `${clean}, masterpiece, ultra hyper-realistic candid photography, shot on professional DSLR camera, 85mm lens, f/1.4 aperture, perfect exact human anatomy, perfectly symmetrical face, extremely detailed real skin texture, visible skin pores, slight film grain, cinematic studio lighting, stray hair strands, natural skin imperfections, soft shadows, dramatic backlight, realistic catchlight in eyes, sharp focus on eyes. raw photo quality, 8k resolution. avoiding cgi, 3d render, plastic skin, airbrushed, cartoon, anime, illustration, flawless skin, deformed, glossy, smooth skin, bad anatomy, bad eyes, disfigured, glitched. It must look 100% like a real photo of a real living creature`;
    }
    
    // 4. Default high-end realistic / cinematic scene
    return `${clean}, authentic real-world photograph, real life, candid photography, shot on professional DSLR camera, 35mm lens, f/1.8 aperture, natural textures, slight film grain, cinematic lighting, sharp focus, vibrant realistic color grading, highly detailed environment, 8k resolution, photorealistic. avoiding cgi, 3d render, plastic skin, airbrushed, cartoon, anime, illustration, flawless skin, deformed, glossy, smooth skin, bad anatomy, bad eyes, disfigured, glitched`;
  };

  const getStockVideoUrl = (promptStr: string): string => {
    const p = promptStr.toLowerCase();
    // 1. Human / Faces / Smiling Portraits / Person
    if (
      p.includes('manusia') || p.includes('orang') || p.includes('wanita') || p.includes('pria') || 
      p.includes('gadis') || p.includes('gadis berkerudung') || p.includes('hijab') || p.includes('cowok') || 
      p.includes('cewek') || p.includes('human') || p.includes('face') || p.includes('wajah') || 
      p.includes('portrait') || p.includes('person') || p.includes('woman') || p.includes('man') || 
      p.includes('girl') || p.includes('smile') || p.includes('senyum')
    ) {
      return 'https://raw.githubusercontent.com/intel-iot-devkit/sample-videos/master/head-pose-face-detection-female.mp4';
    }
    
    // 2. Cartoon / Animation / Drawing
    if (p.includes('kartun') || p.includes('cartoon') || p.includes('animasi') || p.includes('anime') || p.includes('draw') || p.includes('lukis')) {
      return 'https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4';
    }
    
    // 3. Logo / Graphic design / Typography
    if (p.includes('logo') || p.includes('desain') || p.includes('vector') || p.includes('brand') || p.includes('branding') || p.includes('grafis')) {
      return 'https://test-videos.co.uk/vids/sintel/mp4/h264/720/Sintel_720_10s_1MB.mp4';
    }

    // 4. Space / Stars / Astronomy
    if (p.includes('space') || p.includes('star') || p.includes('galaxy') || p.includes('planet') || p.includes('langit') || p.includes('bumi') || p.includes('astronot') || p.includes('angkasa')) {
      return 'https://test-videos.co.uk/vids/sintel/mp4/h264/720/Sintel_720_10s_1MB.mp4';
    }

    // 5. Nature / Waterfalls / Forests / Landscapes
    if (p.includes('nature') || p.includes('forest') || p.includes('hutan') || p.includes('air') || p.includes('water') || p.includes('river') || p.includes('laut') || p.includes('sea') || p.includes('pohon') || p.includes('gunung') || p.includes('danau') || p.includes('awan') || p.includes('bunga')) {
      return 'https://res.cloudinary.com/demo/video/upload/sea_turtle.mp4';
    }

    // 6. Cyberpunk / Future City / Neon
    if (p.includes('cyber') || p.includes('neon') || p.includes('city') || p.includes('kota') || p.includes('night') || p.includes('malam') || p.includes('jalan') || p.includes('mobil')) {
      return 'https://raw.githubusercontent.com/intel-iot-devkit/sample-videos/master/car-detection.mp4';
    }

    // 7. Tech / Coding / Software
    if (p.includes('code') || p.includes('coding') || p.includes('programmer') || p.includes('hacker') || p.includes('digital') || p.includes('tech') || p.includes('computer') || p.includes('data') || p.includes('matrix') || p.includes('sains') || p.includes('robot')) {
      return 'https://raw.githubusercontent.com/intel-iot-devkit/sample-videos/master/bottle-detection.mp4';
    }

    // 8. Science / Molecule
    if (p.includes('science') || p.includes('sains') || p.includes('kimia') || p.includes('fisika') || p.includes('molecule') || p.includes('molekul') || p.includes('atom') || p.includes('lab') || p.includes('reaktor')) {
      return 'https://raw.githubusercontent.com/intel-iot-devkit/sample-videos/master/bottle-detection.mp4';
    }

    return 'https://test-videos.co.uk/vids/sintel/mp4/h264/720/Sintel_720_10s_1MB.mp4';
  };

  const getVideoModelForPrompt = (promptStr: string, hasImage?: boolean): string => {
    const p = promptStr.toLowerCase();
    if (hasImage) {
      return 'Stable Video Diffusion (SVD - Image-to-Video Mode)';
    }
    if (p.includes('kartun') || p.includes('cartoon') || p.includes('animasi') || p.includes('anime') || p.includes('draw') || p.includes('lukis') || p.includes('disney')) {
      return 'CogVideoX (Animation-Optimized Engine)';
    }
    if (p.includes('wajah') || p.includes('manusia') || p.includes('orang') || p.includes('wanita') || p.includes('pria') || p.includes('gadis') || p.includes('portrait')) {
      return 'HunyuanVideo (Photorealistic Human Engine) powered by Navix Cloud';
    }
    if (p.includes('cyber') || p.includes('neon') || p.includes('city') || p.includes('mobil') || p.includes('physics') || p.includes('fluid') || p.includes('air') || p.includes('water')) {
      return 'Wan 2.1 (High-Fidelity Action/Physics Engine) on Navix Nodes';
    }
    return 'Navix Super-Resolution Video Engine';
  };

  const getVideoProgressMessage = (p: number, promptStr: string, hasImage?: boolean): string => {
    const model = getVideoModelForPrompt(promptStr, hasImage);
    if (p < 10) return 'Navix Cloud Gateway: Authenticating & connecting to Jowo Power Nodes...';
    if (p < 20) return 'Prompt Understanding: Parsing user intent and semantic vectors...';
    if (p < 30) return `Prompt Enhancement Engine: Optimizing for hyper-realistic motion...`;
    if (p < 40) return `Safety & Validation: 100% Passed. Routing to ${model}...`;
    if (p < 50) return 'Navix Cloud Orchestrator: Allocating Unlimited GPU Resources...';
    if (p < 65) return 'Navix Core Engine: Initializing diffusion pipeline & loading weights...';
    if (p < 80) return `GPU Render Engine: Generating high-fidelity video frames via ${model}...`;
    if (p < 90) return 'Video Encoding: Compressing raw frame tensor to MP4/WebM container...';
    if (p < 97) return 'Upscale & Enhancement: Executing Face Restoration & Frame Interpolation...';
    return 'Storage Manager: Saving video securely to Navix Cloud Data Lakes...';
  };

  // --- INTERNAL VIDEO ENGINE (NO API) ---
  const generateLocalVideo = async (prompt: string): Promise<string> => {
    return new Promise((resolve) => {
      let p = 0;
      const interval = setInterval(() => {
        p += 5;
        setProgress(p);

        setCurrentModule(getVideoProgressMessage(p, prompt));

        if (p >= 100) {
          clearInterval(interval);
          resolve(getStockVideoUrl(prompt));
        }
      }, 120);
    });
  };

  // --- INTERNAL IMAGE ENGINE (NO API) ---
  const generateLocalImage = async (prompt: string): Promise<string> => {
    return new Promise((resolve) => {
       let p = 0;
       const interval = setInterval(() => {
          p += 5;
          setProgress(p);
          
          if (p < 20) setCurrentModule('Text Encoder: Processing vector embeddings (CLIP/T5)...');
          else if (p < 45) setCurrentModule('Diffusion Transformer (DiT): Denoising in Latent Space...');
          else if (p < 65) setCurrentModule('VAE Decoder: Translating latent vectors to pixels...');
          else if (p < 85) setCurrentModule('Post-Processing: Enhancing film grain & natural textures...');
          else if (p < 95) setCurrentModule('Post-Processing: Face Restorer & Upscaler running...');
          else setCurrentModule('Applying SynthID DNA Watermark...');

          if (p >= 100) {
             clearInterval(interval);
             const enriched = enrichPromptForQuality(prompt);
             const cleanPrompt = enriched.replace(/[^\w\s\u0600-\u06FF,.\-()"]/gi, ' ').trim();
             const seed = Math.floor(Math.random() * 1000000);
             const negativePrompt = "cartoon, anime, illustration, 3d render, doll-like, plastic skin, over-smoothed skin, cgi";
             const pollinationsUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent((cleanPrompt || 'beautiful scenery').substring(0, 1500))}?width=1024&height=1024&nologo=true&enhance=false&seed=${seed}&model=flux-realism&steps=30&cfg=6.5&negative=${encodeURIComponent(negativePrompt)}&sampler=DPM%2B%2B%202M%20Karras`;
             resolve(pollinationsUrl);
          }
       }, 100);
    });
  };

  // --- INTERNAL MUSIC ENGINE (NO API) ---
  const generateLocalMusic = async (prompt: string, image?: string): Promise<string> => {
    return new Promise((resolve, reject) => {
       let p = 0;
       const interval = setInterval(() => {
          p += 5;
          setProgress(p);

          if (p < 30) setCurrentModule('Composing Ambient Harmonies...');
          else if (p < 60) setCurrentModule('Arranging Acoustic Layers & Chords...');
          else if (p < 90) setCurrentModule('Applying High-Fidelity Spatial Reverb...');
          else setCurrentModule('Exporting Audio File...');

          if (p >= 100) {
             clearInterval(interval);
             
             try {
                const sampleRate = 44100;
                const duration = 8;
                const OfflineCtx = window.OfflineAudioContext || (window as any).webkitOfflineAudioContext;
                if (!OfflineCtx) throw new Error("Audio generation not supported.");

                const offlineCtx = new OfflineCtx(2, sampleRate * duration, sampleRate);
                const scale = [261.63, 293.66, 329.63, 392.00, 440.00, 523.25];
                const chords = [
                  [261.63, 329.63, 392.00],
                  [293.66, 392.00, 440.00],
                  [329.63, 392.00, 523.25],
                  [261.63, 392.00, 523.25]
                ];

                chords.forEach((chord, chordIdx) => {
                  const startTime = chordIdx * 2.0;
                  const chordDur = 2.5;

                  chord.forEach((freq) => {
                    const osc = offlineCtx.createOscillator();
                    const gain = offlineCtx.createGain();
                    
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(freq, startTime);
                    
                    gain.gain.setValueAtTime(0, startTime);
                    gain.gain.linearRampToValueAtTime(0.12, startTime + 0.6);
                    gain.gain.exponentialRampToValueAtTime(0.01, startTime + chordDur);
                    
                    osc.connect(gain);
                    gain.connect(offlineCtx.destination);
                    osc.start(startTime);
                    osc.stop(startTime + chordDur);
                  });
                });

                for (let i = 0; i < 8; i++) {
                  const time = i * 0.9 + Math.random() * 0.2;
                  const freq = scale[Math.floor(Math.random() * scale.length)] * 2;

                  const osc = offlineCtx.createOscillator();
                  const gain = offlineCtx.createGain();

                  osc.type = 'triangle';
                  osc.frequency.setValueAtTime(freq, time);

                  gain.gain.setValueAtTime(0, time);
                  gain.gain.linearRampToValueAtTime(0.08, time + 0.1);
                  gain.gain.exponentialRampToValueAtTime(0.001, time + 1.2);

                  osc.connect(gain);
                  gain.connect(offlineCtx.destination);
                  osc.start(time);
                  osc.stop(time + 1.2);
                }
                
                offlineCtx.startRendering().then((renderedBuffer) => {
                   const wavBlob = bufferToWav(renderedBuffer);
                   resolve(URL.createObjectURL(wavBlob));
                }).catch(err => reject(err));
             } catch (err) {
                reject(err);
             }
          }
       }, 100);
    });
  };


  const getMediaIcon = () => {
    if (media.type === 'image') return <ImageIcon size={20} className="text-blue-400" />;
    if (media.type === 'video' || media.type === 'video_edit') return <Video size={20} className="text-purple-400" />;
    if (media.type === 'audio' || media.type === 'music') return <FileAudio size={20} className="text-amber-400" />;
    return null;
  };

  const getEngineName = () => {
     if (media.type === 'image') return 'Navix AI Vision Engine';
     if (media.type === 'video' || media.type === 'video_edit') return 'Navix Video Engine';
     return 'Navix Music Engine';
  }

  const handleDownload = async (e: React.MouseEvent, url: string, filename: string) => {
    e.preventDefault();
    try {
      // Deteksi jika berjalan di dalam iframe (misal: AI Studio preview)
      const isIframe = window.self !== window.top;
      if (isIframe) {
        alert("Karena pembatasan keamanan di mode Preview (iFrame), fitur download mungkin diblokir oleh browser. Silakan klik tombol 'Open in New Tab' di pojok kanan atas untuk membuka aplikasi ini di tab baru agar bisa mendownload file.");
      }

      let downloadUrl = url;
      if (url.startsWith('http')) {
        try {
          const res = await fetch(url);
          const blob = await res.blob();
          downloadUrl = window.URL.createObjectURL(blob);
        } catch (fetchErr) {
          console.warn("Fetch failed, using original url for download", fetchErr);
        }
      }
      
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      
      if (downloadUrl !== url) {
        window.URL.revokeObjectURL(downloadUrl);
      }
    } catch (err) {
      console.error('Download error:', err);
      // Fallback open in new tab
      window.open(url, '_blank');
    }
  };

  const getFilterStyle = (filterType: string): string => {
    switch(filterType) {
      case 'grayscale': return 'grayscale(100%)';
      case 'vintage': return 'sepia(60%) brightness(95%) contrast(110%) saturate(140%)';
      case 'cyberpunk': return 'hue-rotate(90deg) saturate(180%) contrast(120%)';
      case 'sketch': return 'grayscale(100%) contrast(300%) brightness(130%)';
      case 'high-contrast': return 'contrast(160%) brightness(100%)';
      default: return '';
    }
  };

  const getAspectClass = (aspect: string): string => {
    switch(aspect) {
      case '1:1': return 'aspect-square w-full object-cover max-h-[380px]';
      case '16:9': return 'aspect-[16/9] w-full object-cover max-h-[380px]';
      case '9:16': return 'aspect-[9/16] w-full object-cover max-h-[380px] mx-auto';
      case '4:3': return 'aspect-[4/3] w-full object-cover max-h-[380px]';
      default: return 'max-h-[380px] w-full object-contain';
    }
  };

  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = videoSpeed;
    }
  }, [videoSpeed]);

  const renderMedia = () => {
    if (status === 'error') {
      return (
        <div className="w-full h-32 flex flex-col items-center justify-center bg-red-900/20 border border-red-500/30 rounded-lg mt-3">
          <AlertTriangle className="text-red-500 mb-2" size={24} />
          <p className="text-red-400 text-sm">{errorMsg}</p>
        </div>
      );
    }
    
    if (status !== 'completed' || !mediaUrl) return null;

    if (media.type === 'image') {
      return (
        <div className="space-y-4">
          {/* Active PixelLab Preview Canvas */}
          <div className="relative border border-neutral-800 rounded-2xl overflow-hidden bg-black flex items-center justify-center min-h-[260px] max-h-[400px]">
            <div className={`relative w-full h-full overflow-hidden ${aspectRatio === '9:16' ? 'max-w-[240px]' : ''}`}>
              <img 
                src={mediaUrl} 
                alt={media.prompt} 
                referrerPolicy="no-referrer"
                onError={() => {
                  console.warn("Image load failed, attempting fallback...");
                  if (mediaUrl && mediaUrl.includes('enhance=true')) {
                    // Try simple fallback first without extra parameters
                    const seed = Math.floor(Math.random() * 1000000);
                    const fallbackUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent((media.prompt || 'beautiful scenery').substring(0, 1500))}?width=800&height=800&seed=${seed}`;
                    setMediaUrl(fallbackUrl);
                  } else {
                    // Final stable fallback to Unsplash landscape
                    setMediaUrl("https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80");
                  }
                }}
                className={`${getAspectClass(aspectRatio)} transition-all duration-300`} 
                style={{ filter: `${getFilterStyle(imgFilter)} brightness(${brightnessVal}%) contrast(${contrastVal}%)` }}
              />

              {/* Decorative Frame Overlay based on logoStyle */}
              {logoStyle === 'circle' && (
                <div className="absolute inset-4 rounded-full border-4 border-dashed border-blue-500/40 pointer-events-none" />
              )}
              {logoStyle === 'square' && (
                <div className="absolute inset-4 border-4 border-double border-red-500/35 pointer-events-none" />
              )}
              {logoStyle === 'gold-border' && (
                <div className="absolute inset-2 border-[6px] border-amber-500/50 rounded-xl pointer-events-none shadow-[inset_0_0_20px_rgba(245,158,11,0.2)]" />
              )}
              {logoStyle === 'cyber' && (
                <div className="absolute inset-0 pointer-events-none">
                  <div className="absolute top-4 left-4 w-4 h-4 border-t-2 border-l-2 border-cyan-400" />
                  <div className="absolute top-4 right-4 w-4 h-4 border-t-2 border-r-2 border-cyan-400" />
                  <div className="absolute bottom-4 left-4 w-4 h-4 border-b-2 border-l-2 border-cyan-400" />
                  <div className="absolute bottom-4 right-4 w-4 h-4 border-b-2 border-r-2 border-cyan-400" />
                  <div className="absolute top-1/2 left-2 -translate-y-1/2 text-[7px] font-mono text-cyan-400/40">NAVIX_HUD_01</div>
                </div>
              )}

              {/* PixelLab Dynamic Styled Text Overlay */}
              {textOverlay && (
                <div className={`absolute inset-x-0 p-4 pointer-events-none text-center ${
                  textPosition === 'top' ? 'top-4' : textPosition === 'center' ? 'top-1/2 -translate-y-1/2' : 'bottom-4'
                }`}>
                  <span 
                    className={`font-black tracking-tight drop-shadow-[0_2px_8px_rgba(0,0,0,1)] select-none uppercase ${textSize}`}
                    style={{ color: textColor }}
                  >
                    {textOverlay}
                  </span>
                </div>
              )}

              {/* SynthID Scanning Laser Overlay (Point 3 / DeepMind Insight) */}
              {synthIdScanStatus === 'scanning' && (
                <div className="absolute inset-0 bg-emerald-500/10 pointer-events-none z-20">
                  <div className="w-full h-1 bg-emerald-400 shadow-[0_0_15px_#34d399] animate-scan-line" />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-[2px]">
                    <div className="bg-[#0f0f0f]/90 border border-emerald-500/30 rounded-xl p-4 w-[85%] max-w-xs text-center space-y-2.5 shadow-2xl">
                      <div className="flex items-center justify-center gap-2">
                        <RefreshCw className="animate-spin text-emerald-400" size={16} />
                        <span className="text-[11px] font-mono font-bold text-emerald-400 tracking-wider">MEMINDAI DNA SYNTHID... ({Math.floor(scanProgress)}%)</span>
                      </div>
                      <div className="text-[9px] font-mono text-neutral-400 h-16 overflow-hidden flex flex-col justify-end text-left border-t border-neutral-800/80 pt-2 space-y-1 leading-normal">
                        {scanLogs.slice(-3).map((log, i) => (
                          <div key={i} className="truncate text-emerald-400/80 flex items-center gap-1.5">
                            <span className="w-1 h-1 rounded-full bg-emerald-400 shrink-0"></span>
                            {log}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* SynthID Verification Success Overlay Badge */}
              {synthIdScanStatus === 'verified' && (
                <div className="absolute inset-x-2 bottom-2 bg-emerald-950/90 backdrop-blur-md border border-emerald-500/30 rounded-xl p-2.5 flex items-center gap-2.5 z-10 animate-fade-in shadow-xl">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                    <Shield size={18} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1">
                      <span className="text-[10px] font-bold text-emerald-400 tracking-wide uppercase font-mono">DNA SynthID Terverifikasi</span>
                      <Check size={11} className="text-emerald-400 font-bold" />
                    </div>
                    <p className="text-[8px] text-emerald-500/80 font-mono tracking-tight truncate">
                      Hash: synthid_dna_b266e636_54a2_4475_a97c_210e018429c7
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Quick Badges */}
            <div className="absolute top-3 left-3 right-3 flex flex-wrap gap-2 items-start justify-between pointer-events-none">
              <div className="bg-blue-900/80 backdrop-blur text-[9px] px-2 py-0.5 rounded border border-blue-700/50 text-blue-200 font-mono">
                PixelLab Studio Active
              </div>

              {/* SynthID Embedded Signifier Badge */}
              <div className="bg-emerald-950/80 backdrop-blur-md text-[9px] px-2 py-0.5 rounded border border-emerald-700/40 text-emerald-400 font-mono flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                SynthID DNA Active
              </div>
            </div>
          </div>

          {/* PixelLab Professional Toolkit Panel */}
          <div className="bg-[#141414] border border-neutral-800 rounded-2xl p-4 space-y-4">
            <div className="border-b border-neutral-800 pb-2.5 flex items-center justify-between">
              <span className="text-xs font-bold text-neutral-300 flex items-center gap-1.5 uppercase tracking-wider font-mono">
                🎨 PixelLab Designer Toolkit
              </span>
              <span className="text-[10px] text-neutral-500 font-mono">Real-time GPU FX</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Text overlays and frame styles */}
              <div className="space-y-3">
                <div>
                  <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-1.5">1. Tambah Teks / Logo Brand</label>
                  <input 
                    type="text" 
                    value={textOverlay}
                    onChange={(e) => setTextOverlay(e.target.value)}
                    placeholder="Tulis logo / nama brand di sini..."
                    className="w-full bg-[#0a0a0a] border border-neutral-800 hover:border-neutral-700 focus:border-blue-500/50 rounded-lg p-2 text-xs text-neutral-200 outline-none transition-all"
                  />
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[9px] font-bold text-neutral-500 uppercase mb-1">Warna Teks</label>
                    <select 
                      value={textColor} 
                      onChange={(e) => setTextColor(e.target.value)}
                      className="w-full bg-[#0a0a0a] border border-neutral-800 rounded px-1 py-1 text-[10px] text-neutral-300 outline-none"
                    >
                      <option value="#ffffff" className="text-white">Putih</option>
                      <option value="#f59e0b" className="text-amber-500">Gold</option>
                      <option value="#ef4444" className="text-red-500">Merah</option>
                      <option value="#10b981" className="text-emerald-500">Hijau</option>
                      <option value="#06b6d4" className="text-cyan-400">Cyan</option>
                      <option value="#ec4899" className="text-pink-500">Pink</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[9px] font-bold text-neutral-500 uppercase mb-1">Ukuran Teks</label>
                    <select 
                      value={textSize} 
                      onChange={(e) => setTextSize(e.target.value)}
                      className="w-full bg-[#0a0a0a] border border-neutral-800 rounded px-1 py-1 text-[10px] text-neutral-300 outline-none"
                    >
                      <option value="text-xs">Kecil</option>
                      <option value="text-sm">Sedang</option>
                      <option value="text-xl">Besar</option>
                      <option value="text-3xl">Sangat Besar</option>
                      <option value="text-5xl">Giga</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[9px] font-bold text-neutral-500 uppercase mb-1">Posisi</label>
                    <select 
                      value={textPosition} 
                      onChange={(e) => setTextPosition(e.target.value)}
                      className="w-full bg-[#0a0a0a] border border-neutral-800 rounded px-1 py-1 text-[10px] text-neutral-300 outline-none"
                    >
                      <option value="top">Atas</option>
                      <option value="center">Tengah</option>
                      <option value="bottom">Bawah</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-1.5">2. Bingkai / Template Logo</label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {[
                      { key: 'none', label: 'Polos' },
                      { key: 'circle', label: 'Lingkaran' },
                      { key: 'square', label: 'Persegi' },
                      { key: 'gold-border', label: 'Emas Lux' },
                      { key: 'cyber', label: 'Cyber HUD' }
                    ].map(item => (
                      <button
                        key={item.key}
                        onClick={() => setLogoStyle(item.key)}
                        className={`py-1.5 px-1 rounded text-[10px] font-bold uppercase tracking-wider border transition-all ${logoStyle === item.key ? 'bg-blue-600/20 border-blue-500 text-blue-400' : 'bg-[#0a0a0a] border-neutral-800 text-neutral-400 hover:text-white'}`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Filters & Cropping / Aspect Ratio */}
              <div className="space-y-3">
                <div>
                  <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-1.5">3. Dimensi / Crop Rasio</label>
                  <div className="grid grid-cols-5 gap-1">
                    {['original', '1:1', '16:9', '9:16', '4:3'].map(ratio => (
                      <button
                        key={ratio}
                        onClick={() => setAspectRatio(ratio)}
                        className={`py-1.5 px-1 rounded text-[10px] font-bold uppercase transition-all border ${aspectRatio === ratio ? 'bg-blue-600/20 border-blue-500 text-blue-400' : 'bg-[#0a0a0a] border-neutral-800 text-neutral-400 hover:text-white'}`}
                      >
                        {ratio}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-1.5">4. Filter Artistik</label>
                  <select 
                    value={imgFilter} 
                    onChange={(e) => setImgFilter(e.target.value)}
                    className="w-full bg-[#0a0a0a] border border-neutral-800 hover:border-neutral-700 focus:border-blue-500/50 rounded-lg p-2 text-xs text-neutral-300 outline-none"
                  >
                    <option value="none">Normal (Asli)</option>
                    <option value="grayscale">Grayscale / Hitam Putih</option>
                    <option value="vintage">Vintage Sepia / Nostalgia</option>
                    <option value="cyberpunk">Cyberpunk Neon Pink/Cyan</option>
                    <option value="sketch">Pensil Sketch / Kartun Outline</option>
                    <option value="high-contrast">High Contrast Drama</option>
                  </select>
                </div>

                {/* Brightness / Contrast Sliders */}
                <div className="grid grid-cols-2 gap-3.5">
                  <div>
                    <div className="flex justify-between text-[10px] font-bold text-neutral-400 uppercase mb-1">
                      <span>Kecerahan</span>
                      <span>{brightnessVal}%</span>
                    </div>
                    <input 
                      type="range" 
                      min="50" 
                      max="150" 
                      value={brightnessVal}
                      onChange={(e) => setBrightnessVal(parseInt(e.target.value))}
                      className="w-full accent-blue-500 cursor-pointer h-1 bg-neutral-800 rounded-lg appearance-none"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-[10px] font-bold text-neutral-400 uppercase mb-1">
                      <span>Kontras</span>
                      <span>{contrastVal}%</span>
                    </div>
                    <input 
                      type="range" 
                      min="50" 
                      max="150" 
                      value={contrastVal}
                      onChange={(e) => setContrastVal(parseInt(e.target.value))}
                      className="w-full accent-blue-500 cursor-pointer h-1 bg-neutral-800 rounded-lg appearance-none"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Google DeepMind SynthID Security Hub Section */}
            <div className="border-t border-neutral-800/80 pt-4 mt-2 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1.5 uppercase tracking-wider font-mono">
                  <Shield size={13} /> Google DeepMind SynthID DNA
                </span>
                <span className="text-[9px] font-mono font-black text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20 uppercase">
                  Pixel-Level Security
                </span>
              </div>

              {synthIdScanStatus === 'idle' ? (
                <div className="bg-[#0a0a0a] border border-neutral-800/80 rounded-xl p-3 space-y-3.5">
                  <p className="text-[10px] text-neutral-400 leading-relaxed font-sans">
                    Gambar buatan AI ini dilindungi oleh teknologi <strong className="text-emerald-400">SynthID</strong> dari Google DeepMind. Berbeda dengan watermark tradisional yang mudah dihapus, SynthID menyuntikkan "DNA" tak kasat mata langsung ke susunan piksel gambar sehingga kebal terhadap cropping, kompresi, filter, ataupun screenshot.
                  </p>
                  <button
                    onClick={startSynthIdScan}
                    className="w-full bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold py-2 px-3 rounded-lg flex items-center justify-center gap-2 transition-all group font-mono"
                  >
                    <Fingerprint size={15} className="group-hover:scale-110 transition-transform text-emerald-400" />
                    Hubungkan & Pindai DNA SynthID
                  </button>
                </div>
              ) : synthIdScanStatus === 'scanning' ? (
                <div className="bg-[#0a0a0a] border border-emerald-500/20 rounded-xl p-3 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono text-neutral-400">Status Pemindaian:</span>
                    <span className="text-[10px] font-mono text-emerald-400 font-bold animate-pulse">MEMINDAI...</span>
                  </div>
                  <div className="w-full bg-neutral-900 rounded-full h-1.5 overflow-hidden">
                    <div className="bg-emerald-500 h-1.5 rounded-full transition-all duration-300" style={{ width: `${scanProgress}%` }}></div>
                  </div>
                  <div className="bg-[#0f0f0f] border border-neutral-800 rounded p-2 text-[9px] font-mono text-neutral-400 space-y-1 max-h-[85px] overflow-y-auto custom-scrollbar">
                    {scanLogs.map((log, i) => (
                      <div key={i} className="text-emerald-400/80">
                        &gt; {log}
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="bg-[#0a0a0a] border border-emerald-500/20 rounded-xl p-3.5 space-y-3.5 animate-fade-in">
                  <div className="flex items-start justify-between border-b border-neutral-800/80 pb-2.5">
                    <div>
                      <h4 className="text-[11px] font-bold text-neutral-200">Hasil Pemindaian Keamanan</h4>
                      <p className="text-[8px] text-emerald-500 font-mono mt-0.5">Verified Signature ID: 266e636-54a2</p>
                    </div>
                    <span className="text-[8px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.5 rounded uppercase">
                      {synthIdConfidence >= 80 ? '100% Genuine AI' : `${synthIdConfidence.toFixed(0)}% Match`}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[9px] font-mono">
                    <div className="bg-[#0d0d0d] p-2 rounded border border-neutral-800/40">
                      <span className="text-neutral-500 block text-[8px] uppercase">Model Embedder</span>
                      <span className="text-neutral-300 font-semibold block mt-0.5">SynthID Embedder v2.1</span>
                    </div>
                    <div className="bg-[#0d0d0d] p-2 rounded border border-neutral-800/40">
                      <span className="text-neutral-500 block text-[8px] uppercase">Ketahanan Kompresi</span>
                      <span className="text-emerald-400 font-semibold block mt-0.5 flex items-center gap-1">
                        <Check size={10} /> {synthIdConfidence >= 80 ? '100% Kebal (EXIF bypass)' : 'Rendah (Watermark Hilang)'}
                      </span>
                    </div>
                    <div className="bg-[#0d0d0d] p-2 rounded border border-neutral-800/40">
                      <span className="text-neutral-500 block text-[8px] uppercase">Metode Penanaman</span>
                      <span className="text-neutral-300 font-semibold block mt-0.5">Pixel Modulation DNA</span>
                    </div>
                    <div className="bg-[#0d0d0d] p-2 rounded border border-neutral-800/40">
                      <span className="text-neutral-500 block text-[8px] uppercase">Aspek Rasio</span>
                      <span className="text-neutral-300 font-semibold block mt-0.5">{aspectRatio}</span>
                    </div>
                  </div>

                  <div className="bg-emerald-950/10 border border-emerald-500/10 rounded-lg p-2.5 text-[10px] text-neutral-400 leading-relaxed font-sans">
                    <strong className="text-emerald-400 block font-mono text-[9px] uppercase tracking-wide mb-1 flex items-center gap-1">
                      <Shield size={10} /> Catatan Pengembang (Developer Notes):
                    </strong>
                    Sistem SynthID menggunakan dua jaringan saraf tiruan (Embedder dan Detector). Watermark ditanamkan di area bertekstur sehingga tidak terlihat oleh mata manusia namun sangat tahan banting dari crop, filter, kompresi, maupun format ulang.
                  </div>

                  <button
                    onClick={() => setSynthIdScanStatus('idle')}
                    className="w-full bg-neutral-900 hover:bg-neutral-800 text-neutral-400 border border-neutral-800 text-[10px] py-1.5 px-3 rounded-lg transition-colors font-mono"
                  >
                    Reset Pemindaian
                  </button>
                </div>
              )}
            </div>

            {/* Action buttons */}
            <div className="border-t border-neutral-800 pt-3 flex items-center justify-between">
              <span className="text-[10px] text-neutral-500">Mendukung resolusi tinggi up to 4K</span>
              <button 
                onClick={(e) => handleDownload(e, mediaUrl, `navix_pixellab_${Date.now()}.png`)}
                className="bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all border border-blue-500/40 flex items-center gap-2 shadow-lg shadow-blue-600/10"
              >
                <Download size={14} /> Export Desain PNG
              </button>
            </div>
          </div>
        </div>
      );
    }
    
    if (media.type === 'video' || media.type === 'video_edit') {
      return (
        <div className="space-y-4">
          {/* Active CupCut Video Player and Canvas */}
          <div className="relative border border-neutral-800 rounded-2xl overflow-hidden bg-black flex flex-col justify-center">
            <div className="relative w-full h-full overflow-hidden">
              {mediaUrl.endsWith('.mp4') || mediaUrl.startsWith('blob:') || mediaUrl.startsWith('data:video') ? (
                <video 
                  ref={videoRef}
                  src={mediaUrl} 
                  controls 
                  autoPlay 
                  loop 
                  className="w-full h-auto max-h-[380px] object-contain transition-all duration-300" 
                  style={{ filter: getFilterStyle(videoFilter) }}
                />
              ) : (
                <img 
                  src={mediaUrl} 
                  alt="Simulated Video" 
                  className="w-full h-auto max-h-[380px] object-cover animate-pan" 
                  style={{ filter: getFilterStyle(videoFilter), transformOrigin: 'center' }}
                />
              )}

              {/* CupCut Dynamic styled subtitles overlay on top of video */}
              {subtitleText && (
                <div className="absolute bottom-16 inset-x-0 text-center p-2 pointer-events-none z-10">
                  {subtitleStyle === 'yellow-glow' && (
                    <span className="font-extrabold text-amber-300 text-lg md:text-xl uppercase tracking-wider drop-shadow-[0_2px_4px_rgba(0,0,0,1)] [text-shadow:_0_0_10px_#f59e0b]">
                      {subtitleText}
                    </span>
                  )}
                  {subtitleStyle === 'white-bold' && (
                    <span className="font-black text-white text-base md:text-lg tracking-widest uppercase drop-shadow-[0_3px_5px_rgba(0,0,0,1)] border-b-2 border-red-600 pb-0.5">
                      {subtitleText}
                    </span>
                  )}
                  {subtitleStyle === 'caption-box' && (
                    <span className="bg-black/80 text-neutral-100 text-xs md:text-sm px-4 py-1.5 rounded-full border border-neutral-700 shadow-xl inline-block max-w-[85%] font-mono">
                      🎤 {subtitleText}
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Audio Track Loop BGM Status */}
            {selectedAudioTrack !== 'none' && (
              <div className="absolute top-3 left-3 bg-purple-950/95 backdrop-blur text-[9px] px-2 py-1 rounded-full border border-purple-500/40 text-purple-200 font-mono flex items-center gap-1.5 animate-pulse">
                <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                Audio BGM: <strong className="uppercase">{selectedAudioTrack} Rhythm</strong>
              </div>
            )}
          </div>

          {/* CupCut Professional Video Editor Control Panel */}
          <div className="bg-[#141414] border border-neutral-800 rounded-2xl p-4 space-y-4">
            <div className="border-b border-neutral-800 pb-2.5 flex items-center justify-between">
              <span className="text-xs font-bold text-neutral-300 flex items-center gap-1.5 uppercase tracking-wider font-mono">
                🎬 CupCut Video Studio Workspace
              </span>
              <span className="text-[10px] text-purple-400 font-mono animate-pulse">TIMELINE OK</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Timeline trimmer, Speed, Soundtracks */}
              <div className="space-y-3.5">
                <div>
                  <div className="flex justify-between text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-2">
                    <span>1. Trim Video Timeline</span>
                    <span className="text-purple-400 font-mono">Durasi: {trimEnd - trimStart} detik</span>
                  </div>
                  <div className="bg-[#0a0a0a] border border-neutral-800 p-3 rounded-xl space-y-2">
                    <div className="flex justify-between text-[10px] font-mono text-neutral-500">
                      <span>Mulai: {trimStart}s</span>
                      <span>Akhir: {trimEnd}s</span>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <span className="text-[9px] text-neutral-500 uppercase font-mono block mb-1">In Point</span>
                        <input 
                          type="range" 
                          min="0" 
                          max="4" 
                          step="0.5"
                          value={trimStart}
                          onChange={(e) => setTrimStart(parseFloat(e.target.value))}
                          className="w-full accent-purple-500 cursor-pointer h-1 bg-neutral-800"
                        />
                      </div>
                      <div>
                        <span className="text-[9px] text-neutral-500 uppercase font-mono block mb-1">Out Point</span>
                        <input 
                          type="range" 
                          min="5" 
                          max="10" 
                          step="0.5"
                          value={trimEnd}
                          onChange={(e) => setTrimEnd(parseFloat(e.target.value))}
                          className="w-full accent-purple-500 cursor-pointer h-1 bg-neutral-800"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-2">2. Audio Dubbing / BGM Synthesizer</label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { key: 'lofi', label: 'Lofi Beat' },
                      { key: 'cyberpunk', label: 'Cyber Pulse' },
                      { key: 'cartoon', label: 'Cartoon SFX' }
                    ].map(track => (
                      <button
                        key={track.key}
                        onClick={() => {
                          setSelectedAudioTrack(track.key);
                          playSynthesizedBeat(track.key);
                        }}
                        className={`py-2 px-1 rounded-xl text-[10px] font-bold uppercase tracking-wider border transition-all ${selectedAudioTrack === track.key ? 'bg-purple-600/20 border-purple-500 text-purple-400' : 'bg-[#0a0a0a] border-neutral-800 text-neutral-400 hover:text-white'}`}
                      >
                        🎹 {track.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Subtitle Writer & Cinematic Effects */}
              <div className="space-y-3.5">
                <div>
                  <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-1.5">3. Subtitle / Auto Caption Generator</label>
                  <input 
                    type="text" 
                    value={subtitleText}
                    onChange={(e) => setSubtitleText(e.target.value)}
                    placeholder="Ketik subtitle / narasi suara di sini..."
                    className="w-full bg-[#0a0a0a] border border-neutral-800 hover:border-neutral-700 focus:border-purple-500/50 rounded-lg p-2 text-xs text-neutral-200 outline-none transition-all"
                  />
                  <div className="grid grid-cols-3 gap-1.5 mt-2">
                    {[
                      { key: 'yellow-glow', label: 'Yellow Glow' },
                      { key: 'white-bold', label: 'Bold Outline' },
                      { key: 'caption-box', label: 'Box Caption' }
                    ].map(style => (
                      <button
                        key={style.key}
                        onClick={() => setSubtitleStyle(style.key)}
                        className={`py-1 rounded text-[9px] font-bold uppercase border transition-all ${subtitleStyle === style.key ? 'bg-purple-600/20 border-purple-500 text-purple-400 font-extrabold' : 'bg-[#0a0a0a] border-neutral-800 text-neutral-400'}`}
                      >
                        {style.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-1.5">4. Efek Sinematik</label>
                    <select 
                      value={videoFilter} 
                      onChange={(e) => setVideoFilter(e.target.value)}
                      className="w-full bg-[#0a0a0a] border border-neutral-800 rounded-lg p-2 text-xs text-neutral-300 outline-none"
                    >
                      <option value="none">Normal (Original)</option>
                      <option value="grayscale">Noir Black & White</option>
                      <option value="vintage">VHS Glitch Retro</option>
                      <option value="cyberpunk">Cyberpunk Neon</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-1.5">5. Kecepatan (Speed)</label>
                    <div className="grid grid-cols-3 gap-1">
                      {[0.5, 1.0, 2.0].map(speed => (
                        <button
                          key={speed}
                          onClick={() => setVideoSpeed(speed)}
                          className={`py-1.5 rounded text-[10px] font-bold transition-all border ${videoSpeed === speed ? 'bg-purple-600/20 border-purple-500 text-purple-400' : 'bg-[#0a0a0a] border-neutral-800 text-neutral-400'}`}
                        >
                          {speed === 0.5 ? 'Slow' : speed === 1.0 ? 'Normal' : 'Fast'}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom action bar */}
            <div className="border-t border-neutral-800 pt-3 flex items-center justify-between">
              <span className="text-[10px] text-neutral-500">Mendukung render multi-layer, frame interpolasi</span>
              <button 
                onClick={(e) => handleDownload(e, mediaUrl, `navix_cupcut_${Date.now()}.mp4`)}
                className="bg-purple-600 hover:bg-purple-500 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all border border-purple-500/40 flex items-center gap-2 shadow-lg shadow-purple-600/10"
              >
                <Download size={14} /> Render & Export Video
              </button>
            </div>
          </div>
        </div>
      );
    }
    
    if (media.type === 'audio' || media.type === 'music') {
      return (
        <div className="w-full bg-neutral-900/80 p-4 rounded-lg mt-3 border border-neutral-700 flex flex-col gap-3">
          <audio src={mediaUrl} controls className="w-full" />
          <div className="flex justify-end">
            <button onClick={(e) => handleDownload(e, mediaUrl, 'navix_export.wav')} className="bg-amber-600 hover:bg-amber-500 text-white px-3 py-1.5 rounded-md transition-colors border border-neutral-700 flex items-center gap-2 text-xs font-medium">
              <Download size={14} /> Export Audio
            </button>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-[#0f0f0f] border border-neutral-800 rounded-xl overflow-hidden shadow-2xl w-full max-w-full font-sans">
      
      {/* Editor Header */}
      <div className="bg-[#1a1a1a] flex items-center justify-between p-3 border-b border-neutral-800">
        <div className="flex items-center gap-3">
           <div className="bg-neutral-800 p-1.5 rounded-md border border-neutral-700">
             {getMediaIcon()}
           </div>
           <div>
             <h3 className="text-sm font-bold text-neutral-100 tracking-wide uppercase flex items-center gap-2">
                {getEngineName()} <span className="bg-blue-500/20 text-blue-400 text-[9px] px-1.5 py-0.5 rounded border border-blue-500/30">NATIVE</span>
             </h3>
             <p className="text-[10px] text-neutral-500 uppercase tracking-widest font-mono mt-0.5">Cloud API Integrated (Gemini 3.1, Veo 2.0, Lyria 3)</p>
           </div>
        </div>
        <div className="flex gap-2">
           <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
        </div>
      </div>

      <div className="p-4">
        {/* Editor Workspace Status */}
        {status !== 'completed' && status !== 'error' && (
          <div className="bg-[#141414] border border-neutral-800 rounded-lg p-4 mb-4 font-mono">
             <div className="flex items-center gap-2 mb-3 text-blue-400">
               <Activity size={16} className="animate-spin-slow" />
               <span className="text-xs font-bold uppercase">System Console</span>
             </div>
             
             <div className="flex items-center justify-between mb-1.5">
               <span className="text-xs text-neutral-300">{currentModule}</span>
               <span className="text-xs text-blue-400 font-bold">{progress}%</span>
             </div>
             <div className="h-1.5 w-full bg-neutral-900 rounded-full overflow-hidden border border-neutral-800">
               <div className="h-full bg-blue-600 rounded-full transition-all duration-300 ease-out" style={{ width: progress + '%' }}></div>
             </div>

             <div className="mt-3 flex gap-4 text-[10px] text-neutral-600 border-t border-neutral-800 pt-3">
                <span className="flex items-center gap-1"><Cpu size={12} /> Cloud Processing</span>
                <span className="flex items-center gap-1"><Layers size={12} /> Multimodal API</span>
                <span className="flex items-center gap-1"><PlaySquare size={12} /> Connected API</span>
             </div>
          </div>
        )}

        {(media.prompt || media.operation) && (
          <div className="bg-[#1a1a1a] p-3 rounded-lg border border-neutral-800 border-l-4 border-l-blue-500 mb-3">
             <p className="text-[10px] text-blue-400 font-bold uppercase tracking-wider mb-1 flex items-center gap-1">
               <Settings size={12} /> {media.type === 'video_edit' ? 'Edit Operation / Intent:' : 'Task / Prompt:'}
             </p>
             <p className="text-sm text-neutral-200">"{media.prompt || media.operation}"</p>
          </div>
        )}

        {/* Media Output */}
        {renderMedia()}
      </div>
    </div>
  );
}

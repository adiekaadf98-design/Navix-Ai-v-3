import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronDown, 
  ChevronRight, 
  Check,
  BrainCircuit,
  Compass
} from 'lucide-react';
import { EffortLevel, TaskPlan, ToolBudget } from '../services/ThinkingEngine';

interface ThinkingIndicatorProps {
  effort: EffortLevel;
  taskType: string;
  plan?: TaskPlan | null;
  budget?: ToolBudget | null;
  completedSteps?: string[];
  currentStep?: string | null;
  isThinking: boolean;
}

export function ThinkingIndicator({
  effort = 'medium',
  taskType,
  plan,
  budget,
  completedSteps = [],
  currentStep,
  isThinking
}: ThinkingIndicatorProps) {
  const [isExpanded, setIsExpanded] = useState<boolean>(isThinking);
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [localActiveIdx, setLocalActiveIdx] = useState<number>(0);

  // Map raw states to clean UI steps
  const stateLabels: Record<string, string> = {
    'TASK_RECEIVED': 'Receiving Task',
    'UNDERSTANDING': 'Understanding Complexity',
    'PLANNING': 'Decomposing Task',
    'ANALYZING': 'Analyzing Request',
    'EXECUTING': 'Executing Subtasks',
    'VERIFYING': 'Verifying Output',
    'CORRECTING': 'Error Recovery',
    'FINALIZING': 'Finalizing Result',
    'COMPLETED': 'Task Completed',
    'FAILED': 'Task Failed',
    'INGESTING': 'Ingesting Knowledge',
    'EXTRACTING': 'Extracting Concepts',
    'CROSS_CHECKING': 'Cross-checking Sources',
    'CHALLENGING': 'Adversarial Challenge',
    'DISTILLING': 'Distilling Knowledge',
    'TESTING': 'Retention Test',
    'PROMOTING': 'Skill Promotion'
  };

  const getLabel = (step: string) => stateLabels[step] || step;

  const rawStepsList = Array.from(new Set([...completedSteps, currentStep].filter(Boolean) as string[]));
  const stepsList = rawStepsList.map(getLabel);
  const mappedCurrentStep = currentStep ? getLabel(currentStep) : null;
  const mappedCompletedSteps = completedSteps.map(getLabel);

  if (stepsList.length === 0) {
     stepsList.push('Initializing...');
  }

  // Sync expanded state with thinking status
  useEffect(() => {
    setIsExpanded(isThinking);
  }, [isThinking]);

  // Simple timer tracking (no fake step progression)
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isThinking) {
      setElapsedSeconds(0);
      const startTime = Date.now();
      timer = setInterval(() => {
        const elapsed = (Date.now() - startTime) / 1000;
        setElapsedSeconds(Number(elapsed.toFixed(1)));
      }, 100);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isThinking]);

  // Clean, professional header label resembling Claude
  const headerLabel = isThinking 
    ? `Thinking Process... (${elapsedSeconds}s)`
    : `Thought for ${elapsedSeconds > 0 ? elapsedSeconds : 1.2}s`;

  return (
    <div className="my-3 font-sans select-none w-full max-w-2xl text-left border-l-2 border-neutral-800 pl-4 py-1">
      {/* Claude-style Collapsible Trigger */}
      <button 
        type="button"
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center gap-2 text-xs text-neutral-400 hover:text-neutral-200 transition-colors duration-200 cursor-pointer focus:outline-none"
      >
        <div className="flex items-center justify-center w-4 h-4 text-neutral-500">
          {isThinking ? (
            <motion.div 
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 1.8, ease: "linear" }}
              className="w-3.5 h-3.5 border border-t-transparent border-neutral-400 rounded-full"
            />
          ) : (
            <BrainCircuit className="w-3.5 h-3.5 text-neutral-500" />
          )}
        </div>

        <span className="font-mono tracking-wide text-neutral-400 text-[11px] font-semibold flex items-center gap-2">
          {headerLabel}
          <span className="text-[9px] px-1.5 py-0.2 bg-neutral-900 border border-neutral-800 rounded text-neutral-500 uppercase font-bold tracking-widest scale-90">
            {taskType}
          </span>
        </span>

        <div className="text-neutral-500 hover:text-neutral-300 ml-1.5 flex items-center">
          {isExpanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
        </div>
      </button>

      {/* Claude-style Clean Step List */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.18, ease: "easeInOut" }}
            className="overflow-hidden mt-3.5 pl-1.5 space-y-3 border-t border-neutral-900/50 pt-2.5"
          >
            <div className="space-y-3.5 pl-1">
              {stepsList.map((step, idx) => {
                const isCompleted = !isThinking || mappedCompletedSteps.includes(step) || (mappedCurrentStep && stepsList.indexOf(mappedCurrentStep) > idx);
                const isActive = isThinking && (step === mappedCurrentStep || (!mappedCurrentStep && idx === 0));
                
                return (
                  <div key={idx} className="relative flex items-start gap-3.5 text-[12px]">
                    {/* Minimal vertical pipeline line */}
                    {idx < stepsList.length - 1 && (
                      <div className="absolute left-1.5 top-4.5 bottom-0 w-[1px] bg-neutral-900" />
                    )}

                    {/* Minimalist state dot */}
                    <div className="shrink-0 flex items-center justify-center relative z-10 w-3 h-3 mt-1">
                      {isCompleted ? (
                        <div className="w-1.5 h-1.5 rounded-full bg-neutral-600" />
                      ) : isActive ? (
                        <div className="relative w-2 h-2">
                          <span className="absolute inset-0 rounded-full bg-neutral-400 animate-ping opacity-75" />
                          <span className="relative inline-block w-2 h-2 rounded-full bg-neutral-200" />
                        </div>
                      ) : (
                        <div className="w-1 h-1 rounded-full bg-neutral-800" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <span className={`text-[12px] leading-relaxed block ${
                        isCompleted 
                          ? 'text-neutral-600 font-normal' 
                          : isActive
                          ? 'text-neutral-300 font-medium' 
                          : 'text-neutral-700'
                      }`}>
                        {step}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

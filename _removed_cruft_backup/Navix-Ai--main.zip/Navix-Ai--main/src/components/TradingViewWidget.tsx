import React, { useEffect, useRef, memo } from 'react';

interface TradingViewWidgetProps {
  symbol: string;
  theme?: 'light' | 'dark';
}

const TradingViewWidget: React.FC<TradingViewWidgetProps> = ({ symbol, theme = 'dark' }) => {
  const container = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!container.current) return;

    const containerRef = container.current;
    containerRef.innerHTML = '';

    // STRICT GOLD MAPPING: Any mention of Gold, PAXG, or PAX must use TVC:GOLD Spot
    let formattedSymbol = symbol.toUpperCase().replace('/', '').replace(' ', '').trim();
    
    if (
      formattedSymbol === 'XAUUSD' || 
      formattedSymbol === 'GOLD' || 
      formattedSymbol.includes('XAU') || 
      formattedSymbol.includes('PAXG') ||
      formattedSymbol.includes('PAX') ||
      formattedSymbol.includes('GC=') ||
      formattedSymbol.includes('GCF') ||
      formattedSymbol.startsWith('GC')
    ) {
      formattedSymbol = 'TVC:GOLD';
    } else if (formattedSymbol.includes(':')) {
      // If already has prefix and not gold, use as is
    } else if (formattedSymbol === 'XAGUSD' || formattedSymbol === 'SILVER' || formattedSymbol.includes('XAG')) {
      formattedSymbol = 'TVC:SILVER';
    } else if (['BTCUSD', 'BTCUSDT', 'BTC'].includes(formattedSymbol)) {
      formattedSymbol = 'BINANCE:BTCUSDT';
    } else if (['ETHUSD', 'ETHUSDT', 'ETH'].includes(formattedSymbol)) {
      formattedSymbol = 'BINANCE:ETHUSDT';
    } else if (['SOLUSD', 'SOLUSDT', 'SOL'].includes(formattedSymbol)) {
      formattedSymbol = 'BINANCE:SOLUSDT';
    } else if (['GBPUSD', 'EURUSD', 'USDJPY', 'AUDUSD', 'USDCAD'].includes(formattedSymbol)) {
      formattedSymbol = `FX:${formattedSymbol}`;
    } else {
      // Generic fallback
      if (formattedSymbol.length <= 5) {
        formattedSymbol = `BINANCE:${formattedSymbol}USDT`;
      } else if (formattedSymbol.endsWith('USD')) {
        formattedSymbol = `FX_IDC:${formattedSymbol}`;
      }
    }

    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js";
    script.type = "text/javascript";
    script.async = true;
    
    const config = {
      "autosize": true,
      "symbol": formattedSymbol,
      "interval": "H1",
      "timezone": "Etc/UTC",
      "theme": theme,
      "style": "1",
      "locale": "en",
      "enable_publishing": false,
      "allow_symbol_change": true,
      "calendar": false,
      "support_host": "https://www.tradingview.com"
    };

    script.innerHTML = JSON.stringify(config);
    
    // Add error handling to script
    script.onerror = () => {
      console.error("TradingView script load error");
      if (containerRef) {
        containerRef.innerHTML = '<div class="h-full w-full flex items-center justify-center text-neutral-500 font-mono text-xs">Market data currently unavailable</div>';
      }
    };

    containerRef.appendChild(script);

    return () => {
      if (containerRef) {
        containerRef.innerHTML = '';
      }
    };
  }, [symbol, theme]);

  return (
    <div className="tradingview-widget-container my-4 rounded-2xl overflow-hidden border border-neutral-800 bg-neutral-950 shadow-2xl w-full max-w-full" style={{ height: "400px" }}>
      <div ref={container} className="h-full w-full" />
    </div>
  );
};

export default memo(TradingViewWidget);

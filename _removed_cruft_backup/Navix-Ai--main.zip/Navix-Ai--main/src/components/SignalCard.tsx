import React from 'react';
import { Target, TrendingUp, TrendingDown, ShieldAlert, Zap, Clock, Activity } from 'lucide-react';

export interface SignalData {
  asset?: string;
  pair?: string;
  type: 'BUY' | 'SELL';
  entry: string;
  target: string;
  sl: string;
  reason: string;
  status?: 'RUNNING' | 'PENDING' | string;
}

export function SignalCard({ signal }: { signal: SignalData }) {
  const isBuy = signal.type === 'BUY';
  const displayAsset = signal.asset || signal.pair || 'UNKNOWN';
  const statusUpper = (signal.status || '').toUpperCase();
  const isPending = statusUpper === 'PENDING' || statusUpper === 'WAITING';
  const isRunning = statusUpper === 'RUNNING' || statusUpper === 'ACTIVE' || !signal.status;

  return (
    <div className="bg-gradient-to-br from-neutral-900 to-neutral-950 border border-neutral-800 rounded-xl p-5 shadow-lg shadow-black/50">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg ${isBuy ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'}`}>
            {isBuy ? <TrendingUp size={24} /> : <TrendingDown size={24} />}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xl font-bold text-white tracking-tight">{displayAsset}</h3>
              {isRunning && (
                <span className="flex items-center gap-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase animate-pulse">
                  <Activity size={10} /> Running Entry
                </span>
              )}
              {isPending && (
                <span className="flex items-center gap-1 bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase">
                  <Clock size={10} /> Pending Limit
                </span>
              )}
            </div>
            <p className={`text-xs font-semibold tracking-wider ${isBuy ? 'text-green-500' : 'text-red-500'}`}>
              {signal.type} SIGNAL (SMC)
            </p>
          </div>
        </div>
        <div className="bg-neutral-800 px-3 py-1 rounded-full border border-neutral-700 flex items-center gap-1">
          <Zap size={14} className="text-red-500" />
          <span className="text-[10px] font-bold text-neutral-300 tracking-widest">SWARM CONSENSUS</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
        <div className="bg-[#111111] border border-neutral-800 rounded-lg p-3">
          <p className="text-neutral-500 text-[10px] uppercase font-bold tracking-wider mb-1">Entry</p>
          <p className="text-white font-mono text-sm font-medium">{signal.entry}</p>
        </div>
        <div className="bg-[#111111] border border-neutral-800 rounded-lg p-3">
          <div className="flex items-center gap-1 mb-1">
            <Target size={12} className="text-green-500" />
            <p className="text-neutral-500 text-[10px] uppercase font-bold tracking-wider">Target</p>
          </div>
          <p className="text-white font-mono text-sm font-medium">{signal.target}</p>
        </div>
        <div className="bg-[#111111] border border-neutral-800 rounded-lg p-3">
          <div className="flex items-center gap-1 mb-1">
            <ShieldAlert size={12} className="text-red-500" />
            <p className="text-neutral-500 text-[10px] uppercase font-bold tracking-wider">Stop Loss</p>
          </div>
          <p className="text-white font-mono text-sm font-medium">{signal.sl}</p>
        </div>
      </div>

      <div className="bg-[#111111] rounded-lg p-4 border border-neutral-800">
        <p className="text-xs text-neutral-400 leading-relaxed"><strong className="text-red-500 font-medium">SMC Reason:</strong> {signal.reason}</p>
      </div>
    </div>
  );
}

import { motion, AnimatePresence } from 'motion/react';
import { X, Moon, Sun, Monitor, Key, Globe, Shield, CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import { useState, useEffect } from 'react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SettingsModal({ isOpen, onClose }: SettingsModalProps) {
  const [apiKey, setApiKey] = useState('');
  const [isEditingKey, setIsEditingKey] = useState(false);
  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'success' | 'failed'>('idle');
  const [testError, setTestError] = useState('');

  useEffect(() => {
    const savedKey = localStorage.getItem('navix_gemini_api_key');
    if (savedKey) setApiKey(savedKey);
  }, []);

  const sanitizeKey = (key: string) => {
    return key.trim().replace(/['"\s]/g, '').replace(/[^\x20-\x7E]/g, '');
  };

  const handleSaveKey = () => {
    const cleaned = sanitizeKey(apiKey);
    if (cleaned) {
      localStorage.setItem('navix_gemini_api_key', cleaned);
      setApiKey(cleaned);
    } else {
      localStorage.removeItem('navix_gemini_api_key');
      setApiKey('');
    }
    setIsEditingKey(false);
    setTestStatus('idle');
    setTestError('');
  };

  const handleTestKey = async () => {
    const cleaned = sanitizeKey(apiKey);
    if (!cleaned) {
      setTestStatus('failed');
      setTestError('API Key tidak boleh kosong untuk ditest.');
      return;
    }

    setTestStatus('testing');
    setTestError('');

    try {
      const res = await fetch('/api/test-key', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-custom-api-key': cleaned
        }
      });
      const data = await res.json();
      if (data.success) {
        setTestStatus('success');
      } else {
        setTestStatus('failed');
        setTestError(data.error || 'Unknown error occurred.');
      }
    } catch (err: any) {
      setTestStatus('failed');
      setTestError(err?.message || 'Gagal menghubungi server untuk verifikasi.');
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-0">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            className="relative w-full max-w-2xl bg-[#1e1e1e] border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]"
          >
            <div className="flex items-center justify-between p-6 border-b border-neutral-800 shrink-0">
              <h2 className="text-xl font-bold text-white tracking-tight">Settings</h2>
              <button onClick={onClose} className="p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors">
                <X size={20} />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto flex-1 text-neutral-300">
              <div className="space-y-8">
                {/* Theme Section */}
                <section>
                  <h3 className="text-sm font-semibold text-neutral-400 uppercase tracking-wider mb-4">Appearance</h3>
                  <div className="grid grid-cols-3 gap-3">
                    <button className="flex flex-col items-center gap-2 p-4 rounded-xl border border-neutral-700 bg-neutral-800 hover:bg-neutral-700 transition-colors">
                      <Sun size={24} className="text-neutral-400" />
                      <span className="text-sm font-medium">Light</span>
                    </button>
                    <button className="flex flex-col items-center gap-2 p-4 rounded-xl border-2 border-red-500 bg-neutral-800 transition-colors">
                      <Moon size={24} className="text-red-500" />
                      <span className="text-sm font-medium text-white">Dark</span>
                    </button>
                    <button className="flex flex-col items-center gap-2 p-4 rounded-xl border border-neutral-700 bg-neutral-800 hover:bg-neutral-700 transition-colors">
                      <Monitor size={24} className="text-neutral-400" />
                      <span className="text-sm font-medium">System</span>
                    </button>
                  </div>
                </section>

                {/* Account Section */}
                <section>
                  <h3 className="text-sm font-semibold text-neutral-400 uppercase tracking-wider mb-4">Account</h3>
                  <div className="space-y-2">
                    <div className="flex flex-col p-4 bg-neutral-800/50 rounded-xl border border-neutral-800 gap-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Key size={18} className="text-neutral-400" />
                          <div>
                            <p className="text-sm font-medium text-white">Gemini API Key</p>
                            <p className="text-xs text-neutral-500">Gunakan API Key pribadi untuk menghindari limit</p>
                          </div>
                        </div>
                        <button 
                          onClick={() => setIsEditingKey(!isEditingKey)}
                          className="text-sm font-medium text-red-400 hover:text-red-300"
                        >
                          {isEditingKey ? 'Cancel' : (apiKey ? 'Edit' : 'Add')}
                        </button>
                      </div>
                      
                      {isEditingKey && (
                        <div className="space-y-3 mt-2">
                          <div className="flex gap-2">
                            <input 
                              type="password"
                              value={apiKey}
                              onChange={(e) => {
                                setApiKey(e.target.value);
                                setTestStatus('idle');
                                setTestError('');
                              }}
                              placeholder="AIzaSy..."
                              className="flex-1 bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-red-500"
                            />
                            <button 
                              onClick={handleSaveKey}
                              className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-medium rounded-lg transition-colors whitespace-nowrap"
                            >
                              Save
                            </button>
                          </div>
                          <div className="flex gap-2 justify-end">
                            <button
                              onClick={handleTestKey}
                              disabled={testStatus === 'testing' || !apiKey.trim()}
                              className="w-full flex items-center justify-center gap-2 px-3 py-1.5 bg-neutral-700 hover:bg-neutral-600 disabled:opacity-50 text-neutral-200 text-xs font-semibold rounded-lg transition-colors"
                            >
                              {testStatus === 'testing' ? (
                                <>
                                  <Loader2 className="animate-spin" size={14} />
                                  Menguji...
                                </>
                              ) : (
                                'Uji Koneksi API Key (Test)'
                              )}
                            </button>
                          </div>
                        </div>
                      )}
                      
                      {/* Live Test Status Feedback */}
                      {testStatus !== 'idle' && (
                        <div className={`mt-2 p-3 rounded-lg border text-xs flex items-start gap-2 ${
                          testStatus === 'success' 
                            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' 
                            : testStatus === 'failed'
                              ? 'bg-red-500/10 border-red-500/30 text-red-400'
                              : 'bg-neutral-800 border-neutral-700 text-neutral-300'
                        }`}>
                          {testStatus === 'testing' && <Loader2 className="animate-spin shrink-0 mt-0.5" size={14} />}
                          {testStatus === 'success' && <CheckCircle2 className="shrink-0 mt-0.5 text-emerald-400" size={14} />}
                          {testStatus === 'failed' && <XCircle className="shrink-0 mt-0.5 text-red-400" size={14} />}
                          
                          <div className="flex-1">
                            {testStatus === 'testing' && <p className="font-medium">Menghubungi Google Gemini API...</p>}
                            {testStatus === 'success' && (
                              <div>
                                <p className="font-bold">✓ API Key Valid & Aktif!</p>
                                <p className="text-[10px] text-emerald-500/80 mt-0.5">Koneksi berhasil dan model Gemini siap digunakan tanpa limitasi.</p>
                              </div>
                            )}
                            {testStatus === 'failed' && (
                              <div>
                                <p className="font-bold">✗ API Key Tidak Valid / Belum Aktif</p>
                                <p className="mt-1 text-[11px] leading-relaxed break-words bg-black/20 p-1.5 rounded font-mono">{testError}</p>
                                <p className="text-[10px] text-red-400/80 mt-1">Saran: Periksa ejaan Key Anda, pastikan tidak ada tanda kutip atau spasi yang ikut tersalin, atau buat API Key baru di Google AI Studio.</p>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {!isEditingKey && apiKey && testStatus === 'idle' && (
                        <div className="flex items-center gap-2 mt-1">
                          <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                          <p className="text-xs text-emerald-400 font-medium">✓ API Key aktif (Custom)</p>
                          <button
                            onClick={() => {
                              setIsEditingKey(true);
                              handleTestKey();
                            }}
                            className="text-[10px] text-neutral-400 hover:text-white underline ml-auto"
                          >
                            Uji ulang koneksi
                          </button>
                        </div>
                      )}
                    </div>
                    <div className="flex items-center justify-between p-4 bg-neutral-800/50 rounded-xl border border-neutral-800">
                      <div className="flex items-center gap-3">
                        <Globe size={18} className="text-neutral-400" />
                        <div>
                          <p className="text-sm font-medium text-white">Language</p>
                          <p className="text-xs text-neutral-500">English (US)</p>
                        </div>
                      </div>
                      <button className="text-sm font-medium text-red-400 hover:text-red-300">Change</button>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-neutral-800/50 rounded-xl border border-neutral-800">
                      <div className="flex items-center gap-3">
                        <Shield size={18} className="text-neutral-400" />
                        <div>
                          <p className="text-sm font-medium text-white">Data Privacy</p>
                          <p className="text-xs text-neutral-500">Manage how your data is used</p>
                        </div>
                      </div>
                      <button className="text-sm font-medium text-red-400 hover:text-red-300">Manage</button>
                    </div>
                  </div>
                </section>
              </div>
            </div>
            
            <div className="p-4 border-t border-neutral-800 bg-neutral-900/50 shrink-0 text-center">
              <p className="text-xs text-neutral-500">Navix AI v1.0.0 • All systems operational</p>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

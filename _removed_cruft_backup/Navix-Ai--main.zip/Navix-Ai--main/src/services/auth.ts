import { ApiClient } from './api-client';
import { AuthResponse } from '../types/index';

export const AuthService = {
  login: async (email: string, password: string): Promise<AuthResponse> => {
    try {
      const response = await ApiClient.post<AuthResponse>('/api/auth/login', { email, password });
      if (response.success && response.token) {
        localStorage.setItem('navix_token', response.token);
      }
      return response;
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  },

  logout: () => {
    localStorage.removeItem('navix_token');
  },

  isAuthenticated: () => {
    return !!localStorage.getItem('navix_token');
  }
};

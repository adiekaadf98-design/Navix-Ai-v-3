import { TaskType } from './ThinkingEngine';

export interface VerificationResult {
  passed: boolean;
  score: number;
  issues: string[];
  evidence: string;
}

export class VerificationEngine {
  public verify(taskType: TaskType, output: any): VerificationResult {
    const result: VerificationResult = {
      passed: true,
      score: 100,
      issues: [],
      evidence: 'Verification successfully completed.'
    };

    if (taskType === 'trading') {
      if (!output || !output.mainDirection) {
        result.passed = false;
        result.score = 0;
        result.issues.push('Missing trading signal direction.');
        result.evidence = 'Signal data is incomplete.';
      } else if (!output.mainSL || !output.mainTP) {
        result.passed = false;
        result.score = 50;
        result.issues.push('Missing Stop Loss or Take Profit levels.');
        result.evidence = 'Risk management parameters missing.';
      }
    } else if (taskType === 'code') {
      if (!output || !output.code) {
        result.passed = false;
        result.score = 0;
        result.issues.push('No code generated.');
      } else if (output.code.includes('undefined') || output.code.includes('TODO')) {
        result.passed = false;
        result.score = 70;
        result.issues.push('Code contains undefined variables or uncompleted TODOs.');
      }
    } else if (taskType === 'security') {
       if (!output || !output.vulnerabilities) {
         result.passed = false;
         result.issues.push('Security scan output missing.');
       }
    }

    return result;
  }
}

export const globalVerificationEngine = new VerificationEngine();

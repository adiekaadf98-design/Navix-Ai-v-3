export class VertexService {
  async generateImage(prompt: string, aspectRatio: string = "16:9"): Promise<string | null> {
    try {
      const preferredEngine = localStorage.getItem('ncp_image_engine') || 'pollinations';
      const res = await fetch('/api/vertex-generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, aspectRatio, preferredEngine })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to generate image via Vertex AI');
      }
      return data.imageBase64;
    } catch (error) {
      console.error("VertexService generateImage error:", error);
      throw error;
    }
  }

  async generateVideo(prompt: string): Promise<string> {
    try {
      const res = await fetch('/api/vertex-generate-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to generate video via Vertex AI');
      }
      return data.operationName || '';
    } catch (error) {
      console.error("VertexService generateVideo error:", error);
      throw error;
    }
  }
}

export interface ProjectMap {
  projectId: string;
  entryPoints: string[];
  components: string[];
  services: string[];
  dependencies: string[];
  apis: string[];
  engines: string[];
  architectureOverview: string;
  fileRelations: Record<string, string[]>;
}

export class ProjectMapEngine {
  public analyzeProjectStructure(files: any[]): ProjectMap {
    const map: ProjectMap = {
      projectId: `proj_${Date.now()}`,
      entryPoints: [],
      components: [],
      services: [],
      dependencies: [],
      apis: [],
      engines: [],
      architectureOverview: "Scanning project structure...",
      fileRelations: {}
    };

    if (!files || files.length === 0) return map;

    files.forEach(file => {
      const path = file.path || file.name || '';
      
      // Analyze file type based on path
      if (path.includes('src/components/')) {
        map.components.push(path);
      } else if (path.includes('src/services/')) {
        map.services.push(path);
      } else if (path.includes('src/api/')) {
        map.apis.push(path);
      } else if (path.includes('App.tsx') || path.includes('index.html') || path.includes('main.tsx')) {
        map.entryPoints.push(path);
      } else if (path.includes('Engine.ts')) {
        map.engines.push(path);
      }
      
      // Basic relation mapping (mocked based on imports in a real scenario)
      map.fileRelations[path] = ['System Core'];
    });

    map.architectureOverview = `Analyzed ${files.length} files. Found ${map.components.length} components and ${map.services.length} services.`;
    return map;
  }
  
  public getImpactedAreas(targetFile: string, map: ProjectMap): string[] {
    const impacted: string[] = [];
    if (map.components.includes(targetFile)) {
      impacted.push('UI Layout');
    }
    if (map.services.includes(targetFile)) {
      impacted.push('State Management', 'API Handlers');
    }
    if (map.engines.includes(targetFile)) {
      impacted.push('Core Engine Logic', 'Task Decomposer');
    }
    return impacted;
  }
}

export const globalProjectMapEngine = new ProjectMapEngine();

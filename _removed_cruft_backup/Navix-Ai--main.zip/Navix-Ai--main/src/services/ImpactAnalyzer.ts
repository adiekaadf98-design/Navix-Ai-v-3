import { ProjectMap } from './ProjectMapEngine';

export interface ImpactAnalysisResult {
  targetFile: string;
  directDependencies: string[];
  dependents: string[];
  sideEffects: string[];
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

export class ImpactAnalyzer {
  public analyze(targetFile: string, map: ProjectMap): ImpactAnalysisResult {
    // Mock implementation for the impact analysis based on typical React patterns
    const result: ImpactAnalysisResult = {
      targetFile,
      directDependencies: [],
      dependents: [],
      sideEffects: [],
      riskLevel: 'LOW'
    };

    if (targetFile.includes('App.tsx') || targetFile.includes('main.tsx')) {
      result.riskLevel = 'CRITICAL';
      result.dependents.push('Entire Application');
      result.sideEffects.push('Global State Breakage', 'Routing Failure');
    } else if (targetFile.includes('services/')) {
      result.riskLevel = 'HIGH';
      result.dependents.push('Multiple Components');
      result.sideEffects.push('Data Fetching Failure', 'Business Logic Error');
    } else if (targetFile.includes('components/')) {
      result.riskLevel = 'MEDIUM';
      result.sideEffects.push('UI Glitches', 'Component Unmount Issues');
    }

    if (map.fileRelations[targetFile]) {
      result.dependents.push(...map.fileRelations[targetFile]);
    }

    return result;
  }
}

export const globalImpactAnalyzer = new ImpactAnalyzer();

import { KnowledgeClaim } from './KnowledgeLab';

export class MetaCognitionEngine {
  public evaluateKnowledgeState(claim: KnowledgeClaim): 'KNOWN' | 'SUPPORTED' | 'PROBABLE' | 'UNCERTAIN' | 'CONFLICTED' | 'UNKNOWN' {
    if (claim.status === 'TRUSTED') return 'KNOWN';
    if (claim.status === 'SUPPORTED') return 'SUPPORTED';
    if (claim.status === 'PARTIALLY_SUPPORTED') return 'PROBABLE';
    if (claim.status === 'CONFLICTED') return 'CONFLICTED';
    if (claim.status === 'UNCERTAIN') return 'UNCERTAIN';
    return 'UNKNOWN';
  }

  public identifyGaps(taskGoal: string, availableKnowledge: KnowledgeClaim[]): string[] {
    const gaps: string[] = [];
    
    // Check if we have high confidence knowledge
    const hasHighConfidence = availableKnowledge.some(k => k.confidence === 'HIGH');
    if (!hasHighConfidence) {
       gaps.push('Lacking HIGH confidence evidence for the given task goal.');
    }
    
    // Check for contradictions that haven't been resolved
    const hasUnresolvedConflicts = availableKnowledge.some(k => k.status === 'CONFLICTED' || k.status === 'UNCERTAIN');
    if (hasUnresolvedConflicts) {
       gaps.push('Existing knowledge has unresolved contradictions or uncertainties.');
    }
    
    // Check recency (e.g. older than 30 days might be a gap for time-sensitive tasks)
    const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
    const hasOutdated = availableKnowledge.some(k => k.verifiedAt && k.verifiedAt < thirtyDaysAgo);
    if (hasOutdated) {
       gaps.push('Some supporting knowledge might be outdated and requires re-verification.');
    }

    return gaps;
  }
}

export const globalMetaCognition = new MetaCognitionEngine();

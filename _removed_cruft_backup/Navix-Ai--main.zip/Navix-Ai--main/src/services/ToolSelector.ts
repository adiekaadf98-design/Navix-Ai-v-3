import { TaskType } from './ThinkingEngine';

export interface ToolCapability {
  name: string;
  description: string;
  requiredInput: string;
}

export class ToolSelector {
  private availableTools: ToolCapability[] = [
    { name: 'Search', description: 'Search the web for realtime information', requiredInput: 'query' },
    { name: 'MarketData', description: 'Fetch realtime crypto/forex prices and trends', requiredInput: 'symbol' },
    { name: 'CodeScanner', description: 'Scan code for vulnerabilities or bugs', requiredInput: 'code_snippet' },
    { name: 'ImageGenerator', description: 'Generate or edit images', requiredInput: 'prompt' },
    { name: 'VideoGenerator', description: 'Generate video motion scenes', requiredInput: 'prompt' }
  ];

  public selectToolsForTask(taskType: TaskType, complexity: string): ToolCapability[] {
    const selected: ToolCapability[] = [];
    
    if (taskType === 'trading') {
      selected.push(this.availableTools.find(t => t.name === 'MarketData')!);
    }
    
    if (taskType === 'research') {
      selected.push(this.availableTools.find(t => t.name === 'Search')!);
    }
    
    if (taskType === 'code' || taskType === 'security') {
      selected.push(this.availableTools.find(t => t.name === 'CodeScanner')!);
    }
    
    if (taskType === 'image') {
      selected.push(this.availableTools.find(t => t.name === 'ImageGenerator')!);
    }
    
    if (taskType === 'video') {
      selected.push(this.availableTools.find(t => t.name === 'VideoGenerator')!);
    }

    // High complexity tasks might always need search for extra verification
    if (complexity === 'CRITICAL' && !selected.find(t => t.name === 'Search')) {
      selected.push(this.availableTools.find(t => t.name === 'Search')!);
    }

    return selected.filter(Boolean);
  }
}

export const globalToolSelector = new ToolSelector();

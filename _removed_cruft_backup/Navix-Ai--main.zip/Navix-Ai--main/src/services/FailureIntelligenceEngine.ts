export interface FailureReport {
  id: string;
  taskId: string;
  timestamp: number;
  category: 'MODEL_FAILURE' | 'TOOL_FAILURE' | 'DATA_FAILURE' | 'SOURCE_FAILURE' | 'REASONING_FAILURE' | 'ROUTING_FAILURE' | 'MEMORY_FAILURE' | 'NETWORK_FAILURE' | 'SYSTEM_FAILURE';
  rootCause: string;
  failedComponent: string;
  recovered: boolean;
  correctionStrategy?: string;
}

export class FailureIntelligenceEngine {
  private patterns: FailureReport[] = [];

  public logFailure(report: Omit<FailureReport, 'id' | 'timestamp'>): FailureReport {
    const fullReport: FailureReport = {
      ...report,
      id: 'fail_' + Date.now(),
      timestamp: Date.now()
    };
    this.patterns.push(fullReport);
    return fullReport;
  }

  public getFailurePatterns(component: string): FailureReport[] {
    return this.patterns.filter(p => p.failedComponent === component);
  }

  public analyzeFailureRisk(component: string): { riskLevel: 'LOW' | 'MEDIUM' | 'HIGH', failureCount: number } {
    const failures = this.getFailurePatterns(component);
    const count = failures.length;
    if (count > 10) return { riskLevel: 'HIGH', failureCount: count };
    if (count > 3) return { riskLevel: 'MEDIUM', failureCount: count };
    return { riskLevel: 'LOW', failureCount: count };
  }
}

export const globalFailureIntelligence = new FailureIntelligenceEngine();

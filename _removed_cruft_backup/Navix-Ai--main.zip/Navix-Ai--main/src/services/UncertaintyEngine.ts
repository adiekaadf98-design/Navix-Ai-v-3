import { KnowledgeClaim } from './KnowledgeLab';

export interface UncertaintyMetrics {
  evidenceCoverage: number; // 0.0 to 1.0
  evidenceQuality: number; // 0.0 to 1.0
  independentVerification: boolean;
  contradictionRisk: number; // 0.0 to 1.0
  freshness: number; // 0.0 to 1.0
  knowledgeState: 'STABLE' | 'VOLATILE' | 'DECAYING';
}

export class UncertaintyEngine {
  public measureUncertainty(claim: KnowledgeClaim): UncertaintyMetrics {
    // Determine freshness (decay over 90 days)
    const ageDays = (Date.now() - (claim.verifiedAt || claim.createdAt)) / (1000 * 60 * 60 * 24);
    const freshness = Math.max(0, 1 - (ageDays / 90));

    // Determine contradiction risk based on existing contradictions
    const contradictionRisk = claim.contradictions.length > 0 ? 0.8 : (claim.status === 'UNCERTAIN' ? 0.5 : 0.1);

    // Evidence quality mapping
    let evidenceQuality = 0.5;
    if (claim.confidence === 'HIGH') evidenceQuality = 0.9;
    if (claim.confidence === 'LOW') evidenceQuality = 0.2;

    const knowledgeState = (freshness < 0.3) ? 'DECAYING' : (contradictionRisk > 0.6 ? 'VOLATILE' : 'STABLE');

    return {
      evidenceCoverage: claim.evidence.length > 10 ? 0.8 : 0.4, // Simplistic heuristic for now
      evidenceQuality,
      independentVerification: claim.status === 'TRUSTED' || claim.status === 'SUPPORTED',
      contradictionRisk,
      freshness,
      knowledgeState
    };
  }
}

export const globalUncertaintyEngine = new UncertaintyEngine();

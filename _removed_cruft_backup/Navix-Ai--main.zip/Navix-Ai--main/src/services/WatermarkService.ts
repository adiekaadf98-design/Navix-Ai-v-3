/**
 * WatermarkService
 * Implementing a lightweight pixel-level steganography algorithm to embed 
 * invisible digital signatures ("DNA") into images.
 */
export class WatermarkService {
  private static readonly SIGNATURE = "NAVIXAI-DEEPMIND-SYNTHID-DNA-2026";

  /**
   * Embeds an invisible signature into the pixel data of an image Data URL.
   * @param imageDataUrl The source image as a base64 data URL.
   * @returns A promise that resolves to the watermarked base64 data URL.
   */
  public static async embedWatermark(imageDataUrl: string): Promise<string> {
    return new Promise((resolve) => {
      // Check if it's already a base64 image data URL or http/https image url
      if (!imageDataUrl || (!imageDataUrl.startsWith('data:image/') && !imageDataUrl.startsWith('http://') && !imageDataUrl.startsWith('https://'))) {
        return resolve(imageDataUrl);
      }

      const img = new Image();
      if (imageDataUrl.startsWith('http://') || imageDataUrl.startsWith('https://')) {
        img.crossOrigin = 'anonymous';
      }
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          canvas.width = img.width;
          canvas.height = img.height;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            return resolve(imageDataUrl);
          }

          ctx.drawImage(img, 0, 0);
          const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const data = imgData.data;

          // Convert signature string to binary array
          const binarySignature: number[] = [];
          for (let i = 0; i < this.SIGNATURE.length; i++) {
            const charCode = this.SIGNATURE.charCodeAt(i);
            for (let bit = 7; bit >= 0; bit--) {
              binarySignature.push((charCode >> bit) & 1);
            }
          }

          // LSB Steganography injection
          // We distribute the bits across the blue channel (index 2, 6, 10, etc.)
          // of the pixels in a deterministic grid to keep it perfectly invisible.
          const maxBits = binarySignature.length;
          let bitIndex = 0;

          for (let i = 0; i < data.length && bitIndex < maxBits; i += 4) {
            // Apply signature bit into the LSB of the blue channel (data[i + 2])
            const bit = binarySignature[bitIndex];
            data[i + 2] = (data[i + 2] & 0xFE) | bit; // Clear LSB and write bit
            bitIndex++;
          }

          // Write back the modified image data to the canvas
          ctx.putImageData(imgData, 0, 0);

          // Return the watermarked data URL
          const mimeType = imageDataUrl.startsWith('data:image/')
            ? imageDataUrl.substring(5, imageDataUrl.indexOf(';'))
            : 'image/jpeg';
          const watermarkedUrl = canvas.toDataURL(mimeType, 0.95);
          resolve(watermarkedUrl);
        } catch (err) {
          console.error("Error embedding watermark steganography:", err);
          resolve(imageDataUrl); // Fallback on error
        }
      };

      img.onerror = (err) => {
        console.warn("Failed to load image for watermarking (using fallback):", err);
        resolve(imageDataUrl);
      };

      img.src = imageDataUrl;
    });
  }

  /**
   * Applies realistic smartphone camera artifacts to combat AI "plastic" skin and perfect renders.
   * 1. Reduces sharpness by 2-5% using a sub-pixel soft blur.
   * 2. Adds film grain / Gaussian noise to simulate camera sensor ISO grain.
   */
  public static async applyCameraArtifacts(imageDataUrl: string): Promise<string> {
    return new Promise((resolve) => {
      if (!imageDataUrl || (!imageDataUrl.startsWith('data:image/') && !imageDataUrl.startsWith('http://') && !imageDataUrl.startsWith('https://'))) {
        return resolve(imageDataUrl);
      }

      const img = new Image();
      if (imageDataUrl.startsWith('http://') || imageDataUrl.startsWith('https://')) {
        img.crossOrigin = 'anonymous';
      }
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          canvas.width = img.width;
          canvas.height = img.height;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            return resolve(imageDataUrl);
          }

          // Step 1: Reduce sharpness by 2-5% by drawing image slightly soft (sub-pixel blur)
          try {
            // Apply native canvas filter if supported
            ctx.filter = 'blur(0.35px) contrast(0.99)';
          } catch (e) {
            // fallback if filter is not supported
          }

          ctx.drawImage(img, 0, 0);

          // Reset filter
          try {
            ctx.filter = 'none';
          } catch (e) {}

          const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const data = imgData.data;

          // Step 2: Add film grain / Gaussian ISO noise
          for (let i = 0; i < data.length; i += 4) {
            // Noise values range around -7.5 to +7.5 to simulate high ISO digital photography noise
            const noise = (Math.random() - 0.5) * 8.5;
            
            data[i] = Math.min(255, Math.max(0, data[i] + noise));       // R
            data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + noise)); // G
            data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + noise)); // B
          }

          ctx.putImageData(imgData, 0, 0);

          const mimeType = imageDataUrl.startsWith('data:image/')
            ? imageDataUrl.substring(5, imageDataUrl.indexOf(';'))
            : 'image/jpeg';
          const artifactedUrl = canvas.toDataURL(mimeType, 0.95);
          resolve(artifactedUrl);
        } catch (err) {
          console.error("Error applying camera artifacts:", err);
          resolve(imageDataUrl);
        }
      };

      img.onerror = () => {
        resolve(imageDataUrl);
      };

      img.src = imageDataUrl;
    });
  }

  /**
   * Decodes and verifies if the invisible signature is present in the image data.
   * Useful for the detection engine (Detector) to prove authenticity.
   */
  public static async verifyWatermark(imageDataUrl: string): Promise<{ isVerified: boolean; confidence: number }> {
    return new Promise((resolve) => {
      if (!imageDataUrl || (!imageDataUrl.startsWith('data:image/') && !imageDataUrl.startsWith('http://') && !imageDataUrl.startsWith('https://'))) {
        return resolve({ isVerified: false, confidence: 0 });
      }

      const img = new Image();
      if (imageDataUrl.startsWith('http://') || imageDataUrl.startsWith('https://')) {
        img.crossOrigin = 'anonymous';
      }
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          canvas.width = img.width;
          canvas.height = img.height;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            return resolve({ isVerified: false, confidence: 0 });
          }

          ctx.drawImage(img, 0, 0);
          const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const data = imgData.data;

          const targetSignature = this.SIGNATURE;
          const bitsNeeded = targetSignature.length * 8;
          const extractedBits: number[] = [];

          let bitIndex = 0;
          for (let i = 0; i < data.length && bitIndex < bitsNeeded; i += 4) {
            extractedBits.push(data[i + 2] & 1);
            bitIndex++;
          }

          // Reconstruct string from binary bits
          let reconstructed = "";
          for (let i = 0; i < extractedBits.length; i += 8) {
            let charCode = 0;
            for (let bit = 0; bit < 8; bit++) {
              if (i + bit < extractedBits.length) {
                charCode = (charCode << 1) | extractedBits[i + bit];
              }
            }
            reconstructed += String.fromCharCode(charCode);
          }

          // Calculate matching percentage (hamming distance similarity)
          let matchCount = 0;
          const checkLen = Math.min(targetSignature.length, reconstructed.length);
          for (let i = 0; i < checkLen; i++) {
            if (reconstructed[i] === targetSignature[i]) {
              matchCount++;
            }
          }

          const confidence = targetSignature.length > 0 ? (matchCount / targetSignature.length) * 100 : 0;
          const isVerified = confidence >= 80; // Allow minor degradation/lossy compression noise tolerance

          resolve({ isVerified, confidence });
        } catch (err) {
          console.error("Error decoding watermark:", err);
          resolve({ isVerified: false, confidence: 0 });
        }
      };

      img.onerror = () => {
        resolve({ isVerified: false, confidence: 0 });
      };

      img.src = imageDataUrl;
    });
  }
}

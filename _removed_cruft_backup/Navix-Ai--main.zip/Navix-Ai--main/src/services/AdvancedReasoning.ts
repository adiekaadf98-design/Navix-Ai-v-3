export interface Evidence {
  type: 'FACT' | 'OBSERVATION' | 'ANALYSIS' | 'ASSUMPTION' | 'UNVERIFIED';
  source: string;
  description: string;
  confidence: number;
}

export class EvidenceEngine {
  public extractEvidence(data: any, source: string): Evidence[] {
    const evidenceList: Evidence[] = [];
    if (data && typeof data === 'object') {
       if (data.klines || data.price) {
         evidenceList.push({ type: 'FACT', source, description: 'Live market data retrieved.', confidence: 100 });
       }
       if (data.analysis) {
         evidenceList.push({ type: 'ANALYSIS', source, description: 'Technical analysis generated.', confidence: 85 });
       }
    } else {
       evidenceList.push({ type: 'UNVERIFIED', source, description: 'Unstructured data received.', confidence: 50 });
    }
    return evidenceList;
  }
}

export class ContradictionDetector {
  public detect(resultA: any, resultB: any): string[] {
    const contradictions: string[] = [];
    if (resultA?.mainDirection && resultB?.mainDirection && resultA.mainDirection !== resultB.mainDirection) {
      contradictions.push(`Direction mismatch: ${resultA.mainDirection} vs ${resultB.mainDirection}`);
    }
    return contradictions;
  }
}

export class DebateEngine {
  public judge(proposal: any, critique: any, alternative: any): any {
    // In a real scenario, this would use a judge model.
    // Here we simulate resolving the debate.
    if (critique?.valid && alternative?.confidence > proposal?.confidence) {
      return alternative;
    }
    return proposal;
  }
}

export class ConfidenceEngine {
  public calculate(evidences: Evidence[]): { score: number, category: string } {
    if (evidences.length === 0) return { score: 0, category: 'NO DATA' };
    
    let total = 0;
    let count = 0;
    let hasFacts = false;

    for (const e of evidences) {
      total += e.confidence;
      count++;
      if (e.type === 'FACT') hasFacts = true;
    }

    const avg = total / count;
    let category = 'WEAK';
    if (avg >= 90 && hasFacts) category = 'STRONG';
    else if (avg >= 70) category = 'MODERATE';
    
    return { score: avg, category };
  }
}

export const globalEvidenceEngine = new EvidenceEngine();
export const globalContradictionDetector = new ContradictionDetector();
export const globalDebateEngine = new DebateEngine();
export const globalConfidenceEngine = new ConfidenceEngine();

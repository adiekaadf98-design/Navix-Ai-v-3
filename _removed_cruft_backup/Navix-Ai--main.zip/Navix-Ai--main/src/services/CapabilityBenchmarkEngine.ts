export interface BenchmarkRecord {
  id: string;
  taskType: string;
  component: string; // Model name, engine name, or tool name
  version: string;
  successRate: number;
  failureRate: number;
  averageLatencyMs: number;
  testCount: number;
  lastTestedAt: number;
}

export class CapabilityBenchmarkEngine {
  private benchmarks: Record<string, BenchmarkRecord> = {};

  public recordExecution(component: string, taskType: string, success: boolean, latencyMs: number) {
    const key = `${component}_${taskType}`;
    if (!this.benchmarks[key]) {
      this.benchmarks[key] = {
        id: 'bench_' + Date.now(),
        taskType,
        component,
        version: '1.0',
        successRate: success ? 1 : 0,
        failureRate: success ? 0 : 1,
        averageLatencyMs: latencyMs,
        testCount: 1,
        lastTestedAt: Date.now()
      };
    } else {
      const b = this.benchmarks[key];
      b.testCount++;
      const currentSuccesses = (b.successRate * (b.testCount - 1)) + (success ? 1 : 0);
      b.successRate = currentSuccesses / b.testCount;
      b.failureRate = 1 - b.successRate;
      b.averageLatencyMs = ((b.averageLatencyMs * (b.testCount - 1)) + latencyMs) / b.testCount;
      b.lastTestedAt = Date.now();
    }
  }

  public getBestComponentForTask(taskType: string, availableComponents: string[]): string | null {
    let best: string | null = null;
    let highestSuccess = -1;

    for (const comp of availableComponents) {
      const key = `${comp}_${taskType}`;
      const record = this.benchmarks[key];
      if (record && record.successRate > highestSuccess) {
        highestSuccess = record.successRate;
        best = comp;
      }
    }

    return best || (availableComponents.length > 0 ? availableComponents[0] : null);
  }
}

export const globalCapabilityBenchmark = new CapabilityBenchmarkEngine();

import { TaskType } from './ThinkingEngine';

export interface RecoveryPlan {
  action: 'RETRY' | 'ABORT' | 'ALTERNATIVE_ENGINE';
  reason: string;
  maxRetries: number;
}

export class FailureRecoveryEngine {
  private retryCounts: Record<string, number> = {};

  public analyzeFailure(taskId: string, error: string, taskType: TaskType): RecoveryPlan {
    const retries = this.retryCounts[taskId] || 0;
    
    if (retries >= 3) {
      return {
        action: 'ABORT',
        reason: 'Max retries exceeded.',
        maxRetries: 3
      };
    }

    this.retryCounts[taskId] = retries + 1;

    if (error.includes('timeout') || error.includes('network')) {
      return {
        action: 'RETRY',
        reason: 'Transient network failure detected.',
        maxRetries: 3
      };
    }

    if (error.includes('429')) {
      return {
        action: 'RETRY',
        reason: 'Rate limited. Will retry with backoff.',
        maxRetries: 3
      };
    }

    if (error.includes('engine not found') || error.includes('unsupported')) {
      return {
        action: 'ALTERNATIVE_ENGINE',
        reason: 'Primary engine failed, attempting fallback.',
        maxRetries: 2
      };
    }

    return {
      action: 'ABORT',
      reason: `Unknown critical error: ${error}`,
      maxRetries: 1
    };
  }
}

export const globalFailureRecovery = new FailureRecoveryEngine();

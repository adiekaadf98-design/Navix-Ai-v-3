
export interface KnowledgeSource {
  id: string;
  type: 'PDF' | 'DOCUMENT' | 'WEB' | 'PAPER' | 'CODE' | 'DOCUMENTATION' | 'IMAGE' | 'VIDEO' | 'AUDIO' | 'DATASET' | 'USER_PROVIDED';
  origin: string;
  author: string;
  creator: string;
  date: string;
  license: string;
  permission: string;
  language: string;
  contentHash: string;
  acquisitionTime: number;
}

export interface KnowledgeClaim {
  id: string;
  text: string;
  sourceId: string;
  location: string;
  evidence: string;
  confidence: 'HIGH' | 'MEDIUM' | 'LOW' | 'UNKNOWN';
  status: 'TRUSTED' | 'SUPPORTED' | 'PARTIALLY_SUPPORTED' | 'UNCERTAIN' | 'CONFLICTED' | 'REJECTED' | 'KNOWN';
  relatedConcepts: string[];
  contradictions: string[];
  createdAt: number;
  verifiedAt: number | null;
  version: number;
}

export interface GraphRelationship {
  id: string;
  sourceId: string;
  targetId: string;
  type: 'SUPPORTS' | 'CONTRADICTS' | 'CAUSES' | 'DEPENDS_ON' | 'DERIVED_FROM' | 'EXAMPLE_OF' | 'RELATED_TO';
}

export interface Skill {
  id: string;
  name: string;
  version: string;
  sourceKnowledge: string[];
  requiredInputs: string[];
  procedure: string;
  capabilities: string[];
  limitations: string[];
  verificationPolicy: string;
  successRate: number;
  failureRate: number;
  lastVerified: number;
  status: 'TRUSTED_SKILL' | 'UNVERIFIED_SKILL' | 'LEARNING' | 'OUTDATED';
}

export class KnowledgeIngestionEngine {
  private sources: Map<string, KnowledgeSource> = new Map();

  public async ingest(input: string, metadata: Partial<KnowledgeSource>): Promise<KnowledgeSource> {
    const source: KnowledgeSource = {
      id: 'src_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
      type: metadata.type || 'USER_PROVIDED',
      origin: metadata.origin || 'Unknown',
      author: metadata.author || 'Unknown',
      creator: metadata.creator || 'Unknown',
      date: metadata.date || new Date().toISOString(),
      license: metadata.license || 'Unknown',
      permission: metadata.permission || 'Unknown',
      language: metadata.language || 'ID',
      contentHash: 'hash_' + Date.now(),
      acquisitionTime: Date.now()
    };
    
    // Do not ingest if illegal or no permission
    if (source.permission === 'DENIED') {
        throw new Error('Access denied: Cannot ingest source due to permission restrictions.');
    }

    this.sources.set(source.id, source);
    return source;
  }

  public getSource(id: string) { return this.sources.get(id); }
}

export class SourceReliabilityEngine {
  public evaluate(source: KnowledgeSource): 'HIGH_CONFIDENCE' | 'MEDIUM_CONFIDENCE' | 'LOW_CONFIDENCE' | 'UNKNOWN' {
    let score = 0;
    if (source.author !== 'Unknown') score += 2;
    if (source.origin !== 'Unknown') score += 2;
    if (source.type === 'PAPER' || source.type === 'DOCUMENTATION') score += 3;
    
    if (score >= 5) return 'HIGH_CONFIDENCE';
    if (score >= 3) return 'MEDIUM_CONFIDENCE';
    if (score > 0) return 'LOW_CONFIDENCE';
    return 'UNKNOWN';
  }
}

export class KnowledgeGraph {
  private concepts: Map<string, any> = new Map();
  private claims: Map<string, KnowledgeClaim> = new Map();
  private relationships: Map<string, GraphRelationship> = new Map();

  public addClaim(claim: KnowledgeClaim) {
    this.claims.set(claim.id, claim);
  }

  public getClaim(id: string) {
    return this.claims.get(id);
  }
  
  public addRelationship(rel: GraphRelationship) {
    this.relationships.set(rel.id, rel);
  }
  
  public getLineage(claimId: string) {
     const claim = this.claims.get(claimId);
     if (!claim) return null;
     return {
        claim,
        related: Array.from(this.relationships.values()).filter(r => r.sourceId === claimId || r.targetId === claimId)
     };
  }
}

export class TriangulationEngine {
  public crossCheck(claim: KnowledgeClaim, allSources: KnowledgeSource[], relatedClaims: KnowledgeClaim[]): 'SINGLE_SOURCE' | 'CROSS_SUPPORTED' | 'CONFLICTED' | 'UNVERIFIED' {
    if (allSources.length <= 1) return 'SINGLE_SOURCE';

    // Evaluate independence
    const origins = new Set(allSources.map(s => s.origin));
    const authors = new Set(allSources.map(s => s.author));
    
    // If all sources come from the same origin/author, it's considered single source lineage
    if (origins.size === 1 && authors.size <= 1) {
       return 'SINGLE_SOURCE';
    }

    // Check for contradictions in related claims
    const hasContradictions = relatedClaims.some(c => 
       c.contradictions.includes(claim.id) || claim.contradictions.includes(c.id)
    );

    if (hasContradictions) {
       return 'CONFLICTED';
    }

    return 'CROSS_SUPPORTED';
  }
}

export class AdversarialKnowledgeEngine {
  public challenge(claim: KnowledgeClaim, counterEvidence: any[]): KnowledgeClaim {
    if (counterEvidence && counterEvidence.length > 0) {
       // Found evidence that might break the claim
       return { ...claim, status: 'CONFLICTED', confidence: 'LOW' };
    }
    
    // If no counter-evidence found, but hasn't been rigorously tested
    if (claim.confidence === 'HIGH') {
       return claim; // Withstands challenge
    }
    
    return { ...claim, status: 'UNCERTAIN' };
  }
}

export class KnowledgeCourt {
  public judge(claim: KnowledgeClaim, evidence: any[]): 'TRUSTED' | 'SUPPORTED' | 'PARTIALLY_SUPPORTED' | 'UNCERTAIN' | 'CONFLICTED' | 'REJECTED' {
    return 'SUPPORTED';
  }
}

export class KnowledgeDistillationEngine {
  public distill(rawContent: string, sourceId: string = 'src_unknown'): KnowledgeClaim[] {
    // Simulasi ekstraksi pengetahuan struktural: Concept -> Principle -> Rule -> Procedure -> Skill
    // Tidak hanya menyimpan summary, tetapi memecah limitasi, contoh, dll (struktur ini nantinya akan diisi AI)
    
    const distilled: KnowledgeClaim = {
      id: 'claim_' + Date.now(),
      text: 'Distilled concept from raw content: ' + rawContent.substring(0, 50),
      sourceId: sourceId,
      location: 'extracted_block',
      evidence: 'Direct statement',
      confidence: 'MEDIUM',
      status: 'SUPPORTED',
      relatedConcepts: [],
      contradictions: [],
      createdAt: Date.now(),
      verifiedAt: null,
      version: 1
    };

    return [distilled];
  }
  
  public async generateSyntheticContext(claim: KnowledgeClaim): Promise<any> {
    return {
       examples: [],
       limitations: [],
       failureConditions: []
    }
  }
}

export class RetentionTestEngine {
  public testRetention(distilledKnowledge: any, reconstructedKnowledge: any): { retentionScore: number; verified: boolean; missingConcepts: string[] } {
    // Simulating comparing distilled vs reconstructed without active context
    // In actual implementation, 'forgetting' means reconstructedKnowledge is generated 
    // strictly from memory without raw source in context window.
    
    const isMatched = true; // Placeholder for actual LLM comparison
    
    if (isMatched) {
      return { retentionScore: 0.95, verified: true, missingConcepts: [] };
    }
    return { retentionScore: 0.40, verified: false, missingConcepts: ['Key mechanism omitted'] };
  }
}

export class SyntheticProblemGenerator {
  public generateProblem(knowledge: KnowledgeClaim[]): string {
    return "Synthetic problem based on knowledge";
  }
}

export class PracticeEngine {
  public practice(problem: string, knowledge: KnowledgeClaim[]): { success: boolean; result: string } {
    return { success: true, result: "Successfully solved synthetic problem." };
  }
}

export class SkillRegistry {
  private skills: Record<string, Skill> = {};
  
  public promoteToSkill(knowledge: KnowledgeClaim[], performance: any): Skill | null {
    // Aturan 24: Knowledge hanya dapat menjadi TRUSTED_SKILL jika memenuhi 
    // UNDERSTANDING + EVIDENCE + PRACTICE + TEST + VERIFICATION
    
    const allSupported = knowledge.every(k => k.status === 'TRUSTED' || k.status === 'SUPPORTED' || k.status === 'KNOWN');
    
    if (!allSupported || performance?.successRate < 0.9 || !performance?.verified) {
       console.warn("Skill promotion rejected. Requirements not met. Retaining as LEARNING state.");
       return null;
    }

    const skill: Skill = {
      id: 'skill_' + Date.now(),
      name: 'Derived Skill',
      version: '1.0.0',
      sourceKnowledge: knowledge.map(k => k.id),
      requiredInputs: ['context'],
      procedure: 'Apply learned principles',
      capabilities: ['General'],
      limitations: ['Unknown'], // Should come from Distillation
      verificationPolicy: 'Test against synthetic problems',
      successRate: performance.successRate,
      failureRate: 1 - performance.successRate,
      lastVerified: Date.now(),
      status: 'TRUSTED_SKILL'
    };
    this.skills[skill.id] = skill;
    return skill;
  }

  public getSkill(id: string) { return this.skills[id]; }
}

export const globalKnowledgeIngestion = new KnowledgeIngestionEngine();
export const globalSourceReliability = new SourceReliabilityEngine();
export const globalKnowledgeGraph = new KnowledgeGraph();
export const globalTriangulation = new TriangulationEngine();
export const globalAdversarialKnowledge = new AdversarialKnowledgeEngine();
export const globalKnowledgeCourt = new KnowledgeCourt();
export const globalKnowledgeDistillation = new KnowledgeDistillationEngine();
export const globalRetentionTest = new RetentionTestEngine();
export const globalSyntheticProblem = new SyntheticProblemGenerator();
export const globalPracticeEngine = new PracticeEngine();
export const globalSkillRegistry = new SkillRegistry();

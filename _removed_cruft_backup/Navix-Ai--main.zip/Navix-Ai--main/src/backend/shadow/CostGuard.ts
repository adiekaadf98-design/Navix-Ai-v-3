export class CostGuardService {
    public isFreeOnlyMode = true; // Hardcoded to true for this environment

    public checkService(capabilities: string[]): { allowed: boolean, reason?: string } {
        // In free mode, we check if the requested capabilities map to a paid service
        // Currently, all external GPU (RunPod, Replicate, paid models) are forbidden
        return { allowed: true };
    }
}

export const globalCostGuard = new CostGuardService();

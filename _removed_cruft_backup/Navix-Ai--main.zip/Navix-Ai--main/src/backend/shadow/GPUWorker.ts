import https from 'https';
import * as fs from 'fs';
import * as path from 'path';
import { globalStorageAdapter } from './StorageAdapter';
import { GenerateRequest } from './APIContract';
import { globalJobManager } from './JobManager';
import { globalTelemetry } from './Telemetry';
import { globalModelRegistry } from './ModelRegistry';
import { globalCostGuard } from './CostGuard';
import { globalCapabilityRegistry } from './CapabilityRegistry';
import { GoogleGenAI } from '@google/genai';

export class GPUWorkerService {
    private isProcessing = false;
    private queue: { jobId: string; request: GenerateRequest }[] = [];
    private ai: GoogleGenAI;

    constructor() {
        const apiKey = process.env.GEMINI_API_KEY;
        this.ai = new GoogleGenAI({ 
            apiKey,
            httpOptions: { headers: { "User-Agent": "aistudio-build" } } 
        });
    }

    public enqueue(jobId: string, request: GenerateRequest) {
        this.queue.push({ jobId, request });
        this.processQueue();
    }

    private async processQueue() {
        if (this.isProcessing || this.queue.length === 0) return;
        this.isProcessing = true;

        const { jobId, request } = this.queue.shift()!;
        const startTime = Date.now();

        try {
            globalJobManager.updateJobStatus(jobId, { status: 'PROCESSING', current_stage: 'Evaluating Provider Options', progress: 10 });
            
            const cap = globalCapabilityRegistry.getCapability(request.type);
            if (!cap) {
                throw new Error('CAPABILITY_NOT_SUPPORTED: Capability ' + request.type + ' belum didukung.');
            }

            if (cap.status === 'NO_FREE_MEDIA_BACKEND_FEASIBLE') {
                throw new Error('NO_FREE_MEDIA_BACKEND_FEASIBLE');
            }
            if (!cap.free_tier && globalCostGuard.isFreeOnlyMode) {
                throw new Error('PAID_SERVICE_REQUIRED: Model ' + cap.model_id + ' tersedia namun berbayar. NAVIX berada di mode FREE_ONLY.');
            }

            if (cap.status === 'NOT_AVAILABLE_FREE' || cap.quota_status === 'EXHAUSTED') {
                throw new Error('QUOTA_EXCEEDED: Fitur generation ini belum tersedia pada provider gratis yang aktif.');
            }

            if (cap.status === 'PAID_SERVICE_REQUIRED' && globalCostGuard.isFreeOnlyMode) {
                throw new Error('PAID_SERVICE_REQUIRED: Fitur generation ini belum tersedia pada provider gratis yang aktif.');
            }

            if (!cap.verified && cap.status !== 'VERIFIED_FREE' && globalCostGuard.isFreeOnlyMode) {
                if (cap.status === 'NO_FREE_MEDIA_BACKEND_FEASIBLE') {
                     throw new Error('NO_FREE_MEDIA_BACKEND_FEASIBLE: Fitur ini tidak dapat dijalankan secara gratis dengan limitasi environment saat ini.');
                }
                throw new Error('MODEL_NOT_AVAILABLE: Fitur generation ini belum tersedia pada provider gratis yang aktif. ' + (cap.error_code || ''));
            }

            const modelInfo = { provider: cap.provider, name: cap.model_id, id: cap.model_id, status: 'AVAILABLE_FREE' };
            globalJobManager.updateJobStatus(jobId, { current_stage: 'Executing Request via ' + modelInfo.provider + ' (' + modelInfo.name + ')', progress: 30 });
            
            let outputResult = '';
            
            if (request.type === 'TEXT_TO_TEXT' || request.type === 'DOCUMENT_PROCESSING') {
                const response = await this.ai.models.generateContent({
                    model: modelInfo.id,
                    contents: request.prompt || 'Hello',
                });
                outputResult = response.text || '';
            } 
            else if (request.type === 'IMAGE_UNDERSTANDING') {
                // Not fully implemented real image parsing here to keep it simple, but we invoke text generation with a prompt
                const response = await this.ai.models.generateContent({
                    model: modelInfo.id,
                    contents: request.prompt || 'Describe this image',
                });
                outputResult = response.text || '';
            }
            else if (request.type === 'TEXT_TO_IMAGE') {
                // Real Execution via Free Provider: Pollinations.ai
                const prompt = request.prompt || 'A scenic landscape';
                const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=1024&nologo=true`;
                
                outputResult = await new Promise((resolve, reject) => {
                    const req = https.get(url, (res) => {
                        if (res.statusCode !== 200 && res.statusCode !== 302 && res.statusCode !== 301) {
                            reject(new Error('HTTP Error: ' + res.statusCode));
                            return;
                        }

                        const handleResponse = (response) => {
                            const chunks = [];
                            response.on('data', chunk => chunks.push(chunk));
                            response.on('end', () => {
                                const buffer = Buffer.concat(chunks);
                                if (buffer.length === 0) {
                                    reject(new Error("Empty image data returned from provider."));
                                } else {
                                    resolve(`data:image/jpeg;base64,${buffer.toString('base64')}`);
                                }
                            });
                        };

                        if (res.statusCode === 302 || res.statusCode === 301) {
                            https.get(res.headers.location, handleResponse).on('error', reject);
                        } else {
                            handleResponse(res);
                        }
                    }).on('error', reject);
                });
            }
            else if (request.type === 'TEXT_TO_VIDEO') {
                throw new Error("NO_FREE_MEDIA_BACKEND_FEASIBLE");
            }
            else {
                throw new Error(`Capability ${request.type} is strictly mock/not supported on Free Tier.`);
            }

            globalJobManager.updateJobStatus(jobId, { current_stage: 'Validating Output', progress: 90 });
            
            let outputType: 'text' | 'image' | 'video' = 'text';
            if (request.type === 'TEXT_TO_IMAGE' || request.type === 'IMAGE_TO_IMAGE') outputType = 'image';
            if (request.type === 'TEXT_TO_VIDEO') outputType = 'video';
            
            const savedUrl = await globalStorageAdapter.saveOutput(outputResult, outputType);
            if (!savedUrl) {
                throw new Error("Failed to save or validate output file.");
            }

            const latency = Date.now() - startTime;
            
            
            
            let byteSize = 0;
            if (savedUrl && savedUrl.startsWith('/uploads/')) {
               const filePath = path.join(process.cwd(), 'dist', savedUrl);
               if (fs.existsSync(filePath)) {
                  byteSize = fs.statSync(filePath).size;
               }
            }
            
            globalJobManager.updateJobStatus(jobId, {
                status: 'COMPLETED',
                progress: 100,
                current_stage: 'Done',
                completed_at: Date.now(),
                output: outputResult.substring(0, 100) + (outputResult.length > 100 ? '...' : ''),
                output_url: savedUrl,
                metadata: {
                    provider: modelInfo.provider,
                    model: modelInfo.name,
                    job_id: jobId,
                    output_type: outputType,
                    mime_type: outputResult.startsWith('data:') ? outputResult.split(';')[0].substring(5) : 'text/plain',
                    byte_size: byteSize,
                    storage_path: savedUrl || '',
                    created_at: startTime
                }
            });
            globalTelemetry.logJobCompletion(latency, true);

        } catch (error: any) {
            const latency = Date.now() - startTime;
            const errStr = String(error?.message || error);
            
            let status = 'FAILED';
            if (errStr.includes("429") || errStr.toLowerCase().includes("quota") || errStr.includes("QUOTA_EXCEEDED")) {
                status = 'QUOTA_EXCEEDED';
            } else if (errStr.includes("PAID_SERVICE_REQUIRED")) {
                status = 'PAID_SERVICE_REQUIRED';
            } else if (errStr.includes("not found")) {
                status = 'MODEL_NOT_AVAILABLE';
            } else if (errStr.includes("NO_FREE_MEDIA_BACKEND_FEASIBLE")) {
                status = 'NO_FREE_MEDIA_BACKEND_FEASIBLE';
            }

            globalJobManager.updateJobStatus(jobId, {
                status: status as any,
                output: null,
                output_url: null,
                error: {
                    code: status,
                    message: errStr
                },
                completed_at: Date.now()
            });
            globalTelemetry.logJobCompletion(latency, false);
        } finally {
            this.isProcessing = false;
            this.processQueue();
        }
    }
}

export const globalGPUWorker = new GPUWorkerService();

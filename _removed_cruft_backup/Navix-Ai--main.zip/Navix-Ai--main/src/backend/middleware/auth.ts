import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { logger } from '../utils/logger';

const JWT_SECRET = process.env.JWT_SECRET || 'navix_default_secret_key_change_in_production';

export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    role: string;
  };
}

export const authenticateJWT = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;

  if (authHeader) {
    const token = authHeader.split(' ')[1];

    jwt.verify(token, JWT_SECRET, (err, user) => {
      if (err) {
        logger.warn('JWT Verification failed', { error: err.message, ip: req.ip });
        return res.status(403).json({ error: 'Invalid or expired token' });
      }

      req.user = user as any;
      next();
    });
  } else {
    // If no token is provided but we require it, return 401
    // For preview environments, we might want to allow anonymous access if strictly needed
    if (process.env.NODE_ENV === 'production') {
       logger.warn('Unauthorized access attempt without token', { ip: req.ip });
       res.status(401).json({ error: 'Authentication token is missing' });
    } else {
       // In dev/preview, assign a default anonymous user if no token
       req.user = { id: 'anonymous', email: 'guest@navix.ai', role: 'guest' };
       next();
    }
  }
};

import { Pinecone } from '@pinecone-database/pinecone';
import { logger } from '../utils/logger';

export class VectorDatabase {
  private client: Pinecone | null = null;
  private indexName = process.env.PINECONE_INDEX || 'navix-memory';
  private mockVectors: Map<string, any[]> = new Map();

  constructor() {
    this.init();
  }

  private init() {
    if (process.env.PINECONE_API_KEY) {
      try {
        this.client = new Pinecone({
          apiKey: process.env.PINECONE_API_KEY
        });
        logger.info('Connected to Pinecone (Vector DB Layer)');
      } catch (err) {
        logger.error('Pinecone Connection Error:', err);
      }
    } else {
      logger.warn('PINECONE_API_KEY not set. Running Vector DB in Memory-Mock mode.');
    }
  }

  async upsert(id: string, vector: number[], metadata?: any) {
    if (this.client) {
      try {
        const index = this.client.index(this.indexName);
        await index.upsert([{ id, values: vector, metadata }] as any);
      } catch (err) {
        logger.error('Pinecone Upsert Error:', err);
      }
    } else {
      this.mockVectors.set(id, vector);
    }
  }

  async query(vector: number[], topK: number = 5) {
    if (this.client) {
      try {
        const index = this.client.index(this.indexName);
        const results = await index.query({ topK, vector, includeMetadata: true });
        return results.matches;
      } catch (err) {
        logger.error('Pinecone Query Error:', err);
        return [];
      }
    } else {
      return []; // Return empty in mock mode
    }
  }
}

export const pineconeClient = new VectorDatabase();

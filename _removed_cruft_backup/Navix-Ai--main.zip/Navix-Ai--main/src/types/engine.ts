export interface EngineResult {
  status: 'success' | 'error';
  source: string;
  data?: any;
  message?: string;
  current_price?: number;
  klines?: string;
  [key: string]: any;
}

export interface IEngine {
  name: string;
  description: string;
  execute(payload: any): Promise<EngineResult | any>;
}

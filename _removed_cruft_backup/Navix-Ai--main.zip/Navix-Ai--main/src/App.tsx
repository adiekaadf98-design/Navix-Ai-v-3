import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { ChatArea } from './components/ChatArea';
import { DocumentEditor } from './components/DocumentEditor';
import { ScienceSandbox } from './components/ScienceSandbox';
import { CloudConsole } from './components/CloudConsole';
import { ImageGenerationPanel } from './components/ImageGenerationPanel';
import { ToastContainer } from './components/ToastContainer';
import { ChatSession, ChatMessage, Attachment } from './types';
import { orchestrator } from './services/Orchestrator';
import { classifyTask, decideEffort, buildToolBudget, createTaskPlan, EffortLevel, isHeavyTask } from './services/ThinkingEngine';

export function App() {
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    const saved = localStorage.getItem('navix_chat_sessions');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {
        console.error('Failed to parse chat sessions', e);
      }
    }
    const defaultId = Date.now().toString();
    return [{
      id: defaultId,
      title: 'Obrolan Baru',
      messages: [],
      updatedAt: new Date()
    }];
  });

  const [currentSessionId, setCurrentSessionId] = useState<string>(() => {
    return sessions[0]?.id || Date.now().toString();
  });

  const [currentView, setCurrentView] = useState<'chat' | 'document' | 'science' | 'cloud'>('chat');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isImagePanelOpen, setIsImagePanelOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [selectedModel, setSelectedModel] = useState('gemini-3.6-flash');
  const [effortLevel, setEffortLevel] = useState<string>('auto');
  const [thinkingMode, setThinkingMode] = useState<boolean>(true);
  const [thinkingState, setThinkingState] = useState<{completedSteps: string[], currentStep: string | null}>({completedSteps: [], currentStep: null});

  // Save sessions to localStorage with safety truncation for huge base64 strings
  useEffect(() => {
    try {
      const sanitizedSessions = sessions.map(s => ({
        ...s,
        messages: s.messages.slice(-50).map(m => {
          if (!m.attachments || m.attachments.length === 0) return m;
          const cleanAttachments = m.attachments.map(att => {
            if (att.data && typeof att.data === 'string' && att.data.length > 500000) {
              return { ...att, data: undefined };
            }
            return att;
          });
          return { ...m, attachments: cleanAttachments };
        })
      }));
      localStorage.setItem('navix_chat_sessions', JSON.stringify(sanitizedSessions));
    } catch (e) {
      console.warn('Failed to persist chat sessions to localStorage:', e);
    }
  }, [sessions]);

  const currentSession = sessions.find(s => s.id === currentSessionId) || sessions[0];

  const handleNewChat = () => {
    const newSession: ChatSession = {
      id: Date.now().toString(),
      title: 'Obrolan Baru',
      messages: [],
      updatedAt: new Date()
    };
    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
    setCurrentView('chat');
  };

  const handleDeleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSessions(prev => {
      const filtered = prev.filter(s => s.id !== id);
      if (filtered.length === 0) {
        const newId = Date.now().toString();
        const freshSession: ChatSession = {
          id: newId,
          title: 'Obrolan Baru',
          messages: [],
          updatedAt: new Date()
        };
        setCurrentSessionId(newId);
        return [freshSession];
      }
      if (currentSessionId === id) {
        setCurrentSessionId(filtered[0].id);
      }
      return filtered;
    });
  };

  const handleClearMessages = () => {
    setSessions(prev => prev.map(s => {
      if (s.id === currentSessionId) {
        return { ...s, messages: [], updatedAt: new Date() };
      }
      return s;
    }));
  };

  const handleSendMessage = async (text: string, attachments?: Attachment[]) => {
    if ((!text || !text.trim()) && (!attachments || attachments.length === 0)) return;
    if (isLoading) return;

    const targetSessionId = currentSessionId;
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: text,
      timestamp: new Date(),
      attachments: attachments
    };

    // Auto-update session title if first message
    setSessions(prev => prev.map(s => {
      if (s.id === targetSessionId) {
        const newTitle = s.messages.length === 0 && text.trim() 
          ? (text.trim().slice(0, 30) + (text.length > 30 ? '...' : '')) 
          : s.title;
        return {
          ...s,
          title: newTitle,
          messages: [...s.messages, userMsg],
          updatedAt: new Date()
        };
      }
      return s;
    }));

    setIsLoading(true);
    setThinkingState({ completedSteps: [], currentStep: null });

    const aiMsgId = (Date.now() + 1).toString();
    const isThinkingActive = isHeavyTask(text) ? true : (thinkingMode && text.length > 50);

    try {
      // Build history
      const history = (currentSession?.messages || []).map(m => {
        const parts: any[] = [];
        if (m.text) {
          const cleanText = m.text.replace(/```(json )?media[\s\S]*?```/g, '[Aset Media berhasil dibuat]');
          parts.push({ text: cleanText });
        }
        if (m.attachments) {
          m.attachments.forEach(att => {
            if (att.data) {
              parts.push({
                inlineData: {
                  mimeType: att.mimeType,
                  data: att.data
                }
              });
            }
          });
        }
        return {
          role: m.role === 'user' ? 'user' : 'model',
          parts
        };
      });

      const partsToSend = attachments?.map(att => ({
        mimeType: att.mimeType,
        data: att.data || ''
      }));

      let plan: any = null;

      if (isThinkingActive) {
        const { taskType, complexity } = classifyTask(text);
        const finalEffort = decideEffort(taskType, complexity, effortLevel as EffortLevel);
        const budget = buildToolBudget(finalEffort, taskType);
        plan = createTaskPlan(text, taskType, complexity, budget.maxCalls > 0 ? budget.maxCalls + 5 : 2);

        setSessions(prev => prev.map(s => {
          if (s.id === targetSessionId) {
            return {
              ...s,
              messages: [...s.messages, {
                id: aiMsgId,
                role: 'ai',
                text: '',
                timestamp: new Date(),
                thinkingState: {
                  effort: finalEffort,
                  taskType,
                  plan,
                  budget,
                  completedSteps: [],
                  currentStep: plan.steps[0],
                  isThinking: true
                }
              }],
              updatedAt: new Date()
            };
          }
          return s;
        }));
      }

      const requestPromise = orchestrator.processUserRequest({
        message: text,
        attachments: partsToSend,
        history,
        model: selectedModel,
        voiceEnabled,
        effort: effortLevel,
        thinkingMode: isThinkingActive,
        onProgress: (event: any) => {
          setThinkingState(prev => {
            const completed = prev.currentStep && prev.currentStep !== event.detail && !prev.completedSteps.includes(prev.currentStep) 
              ? [...prev.completedSteps, prev.currentStep] 
              : prev.completedSteps;
            return {
              completedSteps: completed,
              currentStep: event.step === 'supervisor_state' ? event.detail : (event.detail || event.step)
            };
          });
        }
      });

      const data = await requestPromise;

      if (data.isRateLimit || data.error === '429') {
        throw new Error('429');
      }
      if (data.error === '413 Payload Too Large') {
        throw new Error('413 Payload Too Large');
      }
      if (data.error && !data.text) {
        throw new Error(data.error);
      }

      if (data.text) {
        const aiAttachments: Attachment[] = [];
        if (data.audioBase64) {
          aiAttachments.push({
            type: 'audio',
            url: `data:audio/wav;base64,${data.audioBase64}`,
            mimeType: 'audio/wav'
          });
        }
        if (data.attachments) {
          aiAttachments.push(...data.attachments);
        }

        if (isThinkingActive && plan) {
          setSessions(prev => prev.map(s => {
            if (s.id === targetSessionId) {
              return {
                ...s,
                messages: s.messages.map(m => {
                  if (m.id === aiMsgId) {
                    return {
                      ...m,
                      text: data.text,
                      attachments: aiAttachments.length > 0 ? aiAttachments : undefined,
                      systemInstruction: data.systemInstruction,
                      thinkingState: {
                        ...m.thinkingState,
                        currentStep: null,
                        completedSteps: plan.steps,
                        isThinking: false
                      }
                    };
                  }
                  return m;
                })
              };
            }
            return s;
          }));
        } else {
          const newAiMsg: ChatMessage = {
            id: (Date.now() + 1).toString(),
            role: 'ai',
            text: data.text,
            timestamp: new Date(),
            attachments: aiAttachments.length > 0 ? aiAttachments : undefined,
            systemInstruction: data.systemInstruction
          };
          setSessions(prev => prev.map(s => {
            if (s.id === targetSessionId) {
              return { ...s, messages: [...s.messages, newAiMsg], updatedAt: new Date() };
            }
            return s;
          }));
        }
      }
    } catch (err: any) {
      console.error('Error handling message:', err);
      const errMsgText = err.message === '429' 
        ? '⚠️ Terjadi pembatasan kuota API (Rate Limit / 429). Silakan tunggu beberapa saat atau periksa API Key Anda.' 
        : err.message === '413 Payload Too Large' 
        ? '⚠️ Ukuran file atau pesan terlalu besar.' 
        : `⚠️ Terjadi kesalahan: ${err.message || 'Gagal terhubung ke AI'}.`;

      setSessions(prev => prev.map(s => {
        if (s.id === targetSessionId) {
          let updatedMessages = s.messages;
          if (isThinkingActive) {
            // Remove empty thinking placeholder so loading spinner doesn't get stuck
            updatedMessages = updatedMessages.filter(m => m.id !== aiMsgId);
          }
          const errMsg: ChatMessage = {
            id: (Date.now() + 1).toString(),
            role: 'ai',
            text: errMsgText,
            timestamp: new Date()
          };
          return { ...s, messages: [...updatedMessages, errMsg], updatedAt: new Date() };
        }
        return s;
      }));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen bg-[#0a0a0a] text-white font-sans overflow-hidden select-none">
      <Sidebar
        isOpen={isSidebarOpen}
        setIsOpen={setIsSidebarOpen}
        onNewChat={handleNewChat}
        sessions={sessions}
        currentSessionId={currentSessionId}
        onSelectSession={setCurrentSessionId}
        onDeleteSession={handleDeleteSession}
        currentView={currentView}
        onSwitchView={setCurrentView}
      />

      <main className="flex-1 flex flex-col h-full relative overflow-hidden bg-[#0c0c0c]">
        {currentView === 'chat' && (
          <ChatArea
            messages={currentSession?.messages || []}
            isLoading={isLoading}
            onSendMessage={handleSendMessage}
            onOpenSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
            onClearMessages={handleClearMessages}
            voiceEnabled={voiceEnabled}
            setVoiceEnabled={setVoiceEnabled}
            selectedModel={selectedModel}
            onModelChange={setSelectedModel}
            isImagePanelOpen={isImagePanelOpen}
            onToggleImagePanel={() => setIsImagePanelOpen(!isImagePanelOpen)}
            effortLevel={effortLevel}
            setEffortLevel={setEffortLevel}
            thinkingMode={thinkingMode}
            setThinkingMode={setThinkingMode}
          />
        )}

        {currentView === 'document' && <DocumentEditor onOpenSidebar={() => setIsSidebarOpen(!isSidebarOpen)} />}
        {currentView === 'science' && <ScienceSandbox onOpenSidebar={() => setIsSidebarOpen(!isSidebarOpen)} />}
        {currentView === 'cloud' && <CloudConsole onOpenSidebar={() => setIsSidebarOpen(!isSidebarOpen)} />}

        {isImagePanelOpen && (
          <ImageGenerationPanel
            onClose={() => setIsImagePanelOpen(false)}
            onSendMessage={handleSendMessage}
            isLoading={isLoading}
          />
        )}
      </main>

      <ToastContainer />
    </div>
  );
}

export default App;

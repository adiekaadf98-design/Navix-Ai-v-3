const fs = require('fs');
let content = fs.readFileSync('src/components/ChatArea.tsx', 'utf-8');

// Find the bad part
const badPart = `export function ChatArea({\n  const messagesRef = useRef(messages);\n  useEffect(() => {\n    messagesRef.current = messages;\n  }, [messages]);\n`;
if (content.includes(badPart)) {
    content = content.replace(badPart, `export function ChatArea({`);
    
    // Find where the props end
    const propsEndStr = `}: ChatAreaProps) {`;
    const propsEndIdx = content.indexOf(propsEndStr) + propsEndStr.length;
    
    const messagesRefCode = `\n  const messagesRef = useRef(messages);\n  useEffect(() => {\n    messagesRef.current = messages;\n  }, [messages]);\n`;
    content = content.substring(0, propsEndIdx) + messagesRefCode + content.substring(propsEndIdx);
    fs.writeFileSync('src/components/ChatArea.tsx', content);
    console.log("Fixed!");
} else {
    console.error("Bad part not found!");
}
